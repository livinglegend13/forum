<?php

declare(strict_types=1);

namespace App\Achievements\Badges;

use App\Achievements\Contracts\BadgeType;

class FiftyReputationPoints extends BadgeType
{
    /**
     * Description for badge
     *
     * @var string
     */
    protected $description = 'Rewarded when you earn 50 reputation points.';

    protected $level = 2;

    /**
     * Check is user qualifies for badge
     *
     * @param $user
     * @return bool
     */
    public function qualifier($user): bool
    {
        return $user->getPoints() >= 50;
    }
}
