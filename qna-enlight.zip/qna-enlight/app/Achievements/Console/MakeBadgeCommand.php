<?php

declare(strict_types=1);

namespace App\Achievements\Console;

use Illuminate\Console\GeneratorCommand;

class MakeBadgeCommand extends GeneratorCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:badge {name}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a badge class';

    /**
     * The type of class being generated.
     *
     * @var string
     */
    protected $type = 'Badge';

    /**
     * Get the stub file for the generator.
     *
     * @return string
     */
    protected function getStub()
    {
        return __DIR__ . '/stubs/badge.stub';
    }

    /**
     * Get the default namespace for the class.
     *
     * @param string $rootNamespace The root namespace
     *
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace . '\Achievements\Badges';
    }

    /**
     * Execute the console command.
     *
     * @return bool|null
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function handle(): ?bool
    {
        // clear the cache for badges
        // cache()->forget('achievements.badges.all');

        return parent::handle();
    }
}
