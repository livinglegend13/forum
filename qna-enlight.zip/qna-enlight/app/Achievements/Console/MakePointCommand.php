<?php

declare(strict_types=1);

namespace App\Achievements\Console;

use Illuminate\Console\GeneratorCommand;

class MakePointCommand extends GeneratorCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:point {name}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a point type class.';

    /**
     * The type of class being generated.
     *
     * @var string
     */
    protected $type = 'Point';

    /**
     * Get the stub file for the generator.
     *
     * @return string
     */
    protected function getStub(): string
    {
        return __DIR__ . '/stubs/point.stub';
    }

    /**
     * Get the default namespace for the class.
     *
     * @param string $rootNamespace The root namespace
     *
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace): string
    {
        return $rootNamespace . '\Achievements\Points';
    }
}
