<?php

declare(strict_types=1);

namespace App\Achievements\Exception;

class InvalidPayeeModel extends \Exception
{
    protected $message = 'payee() method must return a model which will get the points.';
}
