<?php

declare(strict_types=1);

namespace App\Achievements\Exception;

use Exception;

class PointSubjectNotSet extends Exception
{
    protected $message = 'Initialize $subject field in constructor.';
}
