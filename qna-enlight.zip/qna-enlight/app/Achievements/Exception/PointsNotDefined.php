<?php

declare(strict_types=1);

namespace App\Achievements\Exception;

use Exception;

class PointsNotDefined extends Exception
{
    protected $message = 'You must define a $points field or a getPoints() method.';
}
