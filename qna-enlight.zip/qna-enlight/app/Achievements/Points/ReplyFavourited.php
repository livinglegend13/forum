<?php

declare(strict_types=1);

namespace App\Achievements\Points;

use App\Achievements\Contracts\PointType;

class ReplyFavourited extends PointType
{
    public function __construct($subject)
    {
        $this->subject = $subject;
    }

    public function payee()
    {
        return $this->getSubject()->owner;
    }

    public function getPoints(): int
    {
        return 4;
    }
}
