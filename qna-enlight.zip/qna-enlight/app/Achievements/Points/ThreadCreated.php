<?php

declare(strict_types=1);

namespace App\Achievements\Points;

use App\Achievements\Contracts\PointType;

class ThreadCreated extends PointType
{
    public function __construct($subject)
    {
        $this->subject = $subject;
    }

    public function payee()
    {
        return $this->getSubject()->creator;
    }

    public function getPoints(): int
    {
        return 3;
    }
}
