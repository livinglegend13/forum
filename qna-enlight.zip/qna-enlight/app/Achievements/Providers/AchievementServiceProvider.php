<?php

declare(strict_types=1);

namespace App\Achievements\Providers;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
use App\Achievements\Listeners\SyncBadges;
use App\Achievements\Console\MakeBadgeCommand;
use App\Achievements\Console\MakePointCommand;
use App\Achievements\Events\ReputationChanged;

class AchievementServiceProvider extends ServiceProvider
{
    /**
     * Perform post-registration booting of services.
     *
     * @return void
     */
    public function boot()
    {
        // register commands
        if ($this->app->runningInConsole()) {
            $this->commands([
                MakePointCommand::class,
                MakeBadgeCommand::class,
            ]);
        }

        // register event listener
        Event::listen(ReputationChanged::class, SyncBadges::class);
    }

    /**
     * Register bindings in the container.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton('badges', function () {
            return cache()->rememberForever('achievements.badges.all', function () {
                return $this->getBadges()->map(function ($badge) {
                    return new $badge;
                });
            });
        });
    }

    /**
     * getBadges
     *
     * @return Collection
     */
    protected function getBadges(): Collection
    {
        $badgeRootNamespace = $this->app->getNamespace() . 'Achievements\Badges';

        $badges = [];

        foreach (glob(app_path('/Achievements/Badges/') . '*.php') as $file) {
            if (is_file($file)) {
                $badges[] = app($badgeRootNamespace . '\\' . pathinfo($file, PATHINFO_FILENAME));
            }
        }

        return collect($badges);
    }
}
