<?php

declare(strict_types=1);

namespace App\Achievements\Traits;

trait HasAchievements
{
    use HasReputations, HasBadges;
}
