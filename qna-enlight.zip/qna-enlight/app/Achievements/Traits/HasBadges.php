<?php

declare(strict_types=1);

namespace App\Achievements\Traits;

use App\Achievements\Badge;

trait HasBadges
{
    /**
     * Badges user relation
     *
     * @return mixed
     */
    public function badges()
    {
        return $this->belongsToMany(Badge::class, 'user_badges')
            ->withTimestamps();
    }

    /**
     * Sync badges for qiven user
     *
     * @param $user
     */
    public function syncBadges($user = null)
    {
        $user = is_null($user) ? $this : $user;

        $badgeIds = app('badges')->filter
        ->qualifier($user)
        ->map->getBadgeId();

        $user->badges()->sync($badgeIds);
    }
}
