<?php declare(strict_types=1);

namespace App\Filters;

use App\Models\User;

class ThreadFilters extends Filters
{
    protected $filters = ['by', 'popular', 'unanswered', 'q', 'solved', 'unsolved'];

    protected function by($username)
    {
        $user = User::where('username', $username)->firstOrFail();

        return $this->builder->where('user_id', $user->id);
    }

    protected function popular()
    {
        $this->builder->getQuery()->orders = [];

        return $this->builder->orderBy('replies_count', 'desc');
    }

    protected function unanswered()
    {
        return $this->builder->where('replies_count', 0);
    }

    protected function q($search)
    {
        return $this->builder
                ->where('body', 'LIKE', '%' . $search . '%')
                ->orWhere('title', 'LIKE', '%' . $search . '%');
    }

    protected function solved($search)
    {
        return $this->builder
                ->whereNotNull('best_reply_id');
    }

    protected function unsolved($search)
    {
        return $this->builder
                ->whereNull('best_reply_id');
    }
}
