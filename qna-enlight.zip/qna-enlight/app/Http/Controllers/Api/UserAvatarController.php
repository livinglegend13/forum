<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Request;

class UserAvatarController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function store(User $user, Request $request)
    {
        $this->authorize('update', $user);

        $request->validate([
            'avatar' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        $avatar = $request->file('avatar');

        $path = 'avatars/' . $avatar->hashName();

        $this->cropAndStoreImage($avatar, $path);

        $user->update([
            'avatar_path' => $path,
        ]);
    }
}
