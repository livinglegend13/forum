<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    public function index()
    {
        $search = request('username');

        $users = User::where('username', 'LIKE', "$search%")
                ->take(5)->get();

        $mapedUsers = $users->map(function ($user) {
            $data['key'] = $user->name;
            $data['value'] = $user->username;
            $data['avatar'] = $user->avatar;

            return $data;
        });

        return response()->json(['data' => $mapedUsers]);
    }
}
