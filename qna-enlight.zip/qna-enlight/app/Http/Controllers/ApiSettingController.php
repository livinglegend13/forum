<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class ApiSettingController extends Controller
{
    public function index()
    {
        return view('settings.api.index');
    }

    public function postRecaptchaKeys(Request $request)
    {
        $validatedData = $request->validate([
            'recaptcha_key' => 'required',
            'recaptcha_secret' => 'required',
        ]);

        Setting::updateOrCreate(
            ['key' => 'recaptcha_key'],
            [
                'value' => $validatedData['recaptcha_key'],
            ]
        );

        Setting::updateOrCreate(
            ['key' => 'recaptcha_secret'],
            [
                'value' => $validatedData['recaptcha_secret'],
            ]
        );

        return back()->with('flash', 'Recaptcha Settings Updated Successfully');
    }

    public function postAnalyticsKey(Request $request)
    {
        $validatedData = $request->validate([
            'analytics_key' => 'required',
        ]);

        Setting::updateOrCreate(
            ['key' => 'analytics_key'],
            [
                'value' => $validatedData['analytics_key'],
            ]
        );

        return back()->with('flash', 'Google Analytics Settings Updated Successfully');
    }

    public function postOneSignalKey(Request $request)
    {
        $validatedData = $request->validate([
            'onesignal_key' => 'required',
        ]);

        Setting::updateOrCreate(
            ['key' => 'onesignal_key'],
            [
                'value' => $validatedData['onesignal_key'],
            ]
        );

        return back()->with('flash', 'OneSignal Settings Updated Successfully');
    }
}
