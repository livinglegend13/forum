<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Channel;
use Illuminate\Support\Str;
use Illuminate\Http\Request;

class ChannelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $channels = Channel::all();

        return view('channels.index', compact('channels'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('channels.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:channels',
            'font_awesome_classes' => 'required',
        ]);

        Channel::create([
            'name' => $request->name,
            'font_awesome_classes' => $request->font_awesome_classes,
            'slug' => Str::slug($request->name),
        ]);

        return back()->with('flash', 'Channel Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Channel $channel
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Channel $channel)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Channel $channel
     *
     * @return \Illuminate\Http\Response
     */
    public function edit(Channel $channel)
    {
        return view('channels.edit', compact('channel'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Channel             $channel
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Channel $channel)
    {
        $request->validate([
            'name' => 'required|unique:channels,name,' . $channel->id,
            'font_awesome_classes' => 'required',
        ]);

        $channel->update([
            'name' => $request->name,
            'font_awesome_classes' => $request->font_awesome_classes,
            'slug' => Str::slug($request->name),
        ]);

        return redirect()->route('admin.channels.index')->with('flash', 'Channel Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Channel $channel
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy(Channel $channel)
    {
        $channel->delete();

        return redirect()->route('admin.channels.index')->with('flash', 'Channel Deleted Successfully');
    }
}
