<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Ticket;
use Illuminate\Http\Request;
use App\Mailers\TicketMailer;

class CommentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Ticket $ticket
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Ticket $ticket, Request $request, TicketMailer $mailer)
    {
        $request->validate(['body' => 'required']);

        $comment = $ticket->addComment([
            'body' => request('body'),
            'user_id' => auth()->id(),
        ]);

        $mailer->sendTicketComments($comment->ticket->user, auth()->user(), $comment->ticket, $comment);

        return back()->with('flash', 'Your comment saved successfully');
    }
}
