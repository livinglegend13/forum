<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FileUploadController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function store(Request $request)
    {
        $request->validate([
            'key' => 'required',
            'file' => 'required|image|mimes:jpeg,png,jpg',
        ]);

        $file = $request->file('file');

        $path = $request->key;

        $this->cropAndStoreImage($file, $path, 600);

        return response('File Uploaded Successfully', 204);
    }
}
