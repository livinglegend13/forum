<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class GoogleAdsenseController extends Controller
{
    public function index()
    {
        return view('google-adsense.index');
    }

    public function postGoogleAdsenseSquare(Request $request)
    {
        $validatedData = $request->validate(['square' => 'required']);

        Setting::updateOrCreate(
            ['key' => 'square-ads'],
            [
                'value' => $validatedData['square'],
            ]
        );

        return back()->with('flash', 'Square ads Updated Successfully');
    }

    public function postGoogleAdsenseHorizontal(Request $request)
    {
        $validatedData = $request->validate(['horizontal' => 'required']);

        Setting::updateOrCreate(
            ['key' => 'horizontal-ads'],
            [
                'value' => $validatedData['horizontal'],
            ]
        );

        return back()->with('flash', 'Horizontal ads Updated Successfully');
    }

    public function postGoogleAdsenseVertical(Request $request)
    {
        $validatedData = $request->validate(['vertical' => 'required']);

        Setting::updateOrCreate(
            ['key' => 'vertical-ads'],
            [
                'value' => $validatedData['vertical'],
            ]
        );

        return back()->with('flash', 'Vertical ads Updated Successfully');
    }
}
