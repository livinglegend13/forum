<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Thread;

class LockThreadController extends Controller
{
    public function store(Thread $thread)
    {
        $thread->lock();
    }

    public function destroy(Thread $thread)
    {
        $thread->unlock();
    }
}
