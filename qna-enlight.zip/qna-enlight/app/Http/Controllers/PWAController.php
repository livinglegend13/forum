<?php

declare(strict_types=1);

namespace App\Http\Controllers;

class PWAController extends Controller
{
    public function manifest()
    {
        return response()->view('service-worker.manifest', [], 200)->header('Content-Type', 'text/json');
    }

    public function register()
    {
        return response()->view('service-worker.sw-register', [], 200)->header('Content-Type', 'text/javascript');
    }

    public function serviceWorker()
    {
        return response()->view('service-worker.sw', [], 200)->header('Content-Type', 'text/javascript');
    }
}
