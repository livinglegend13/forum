<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Activity;
use App\Models\Trending;
use App\Achievements\Badge;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Trending $trendings
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index(Trending $trendings)
    {
        $users = User::orderBy('reputation', 'desc')->take(50)->get();

        return view('profiles.index', [
            'users' => $users,
            'badges' => Badge::orderBy('level')->get(),
            'trendings' => $trendings->get(),
        ]);
    }

    /**
     * Shows the user profile
     *
     * @param User $user
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show(User $user)
    {
        return view('profiles.show', [
            'profileUser' => $user,
            'badges' => Badge::orderBy('level')->get(),
            'activities' => Activity::feed($user),
        ]);
    }

    /**
     * Updates username, name, email
     *
     * @param User $user
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(User $user, Request $request)
    {
        $this->authorize('update', $user);

        $validatedData = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,' . $user->id],
        ]);

        if ($validatedData['email'] !== $user->email) {
            $user->unverify();
        }

        $user->update($validatedData);

        return redirect(route('profiles.show', $user))->with('flash', 'User Profile Updated Successfully');
    }

    /**
     * Updates current password with new
     *
     * @param User $user
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function password(User $user, Request $request)
    {
        $this->authorize('update', $user);

        $validatedData = $request->validate([
            'current_password' => [
                'required', 'string', 'min:8',
                function ($attribute, $value, $fail) use ($user) {
                    if (! \Hash::check($value, $user->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                },
            ],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $user->update(['password' => bcrypt($validatedData['password'])]);

        return redirect(route('profiles.show', $user))->with('flash', 'Password Updated Successfully');
    }
}
