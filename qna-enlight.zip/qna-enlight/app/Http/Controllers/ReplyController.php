<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Reply;
use App\Models\Thread;
use Illuminate\Http\Request;
use App\Http\Requests\CreateReplyRequest;

class ReplyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except('index');
    }

    public function index($channelId, Thread $thread)
    {
        return $thread->replies()->orderBy('id', 'asc')->paginate(10);
    }

    public function store($channelId, Thread $thread, CreateReplyRequest $createReplyRequest)
    {
        if ($thread->locked) {
            return response('Thread is locked', 403);
        }

        return $thread->addReply([
            'body' => request('body'),
            'user_id' => auth()->id(),
        ])
            ->load('owner');
    }

    public function update(Reply $reply, Request $request)
    {
        $this->authorize('update', $reply);

        $validatedData = $request->validate([
            'body' => 'required',
        ]);

        $reply->update(['body' => $validatedData['body']]);

        return response(['status' => 'Your reply has been updated !']);
    }

    public function destroy(Reply $reply)
    {
        $this->authorize('update', $reply);

        $reply->delete();

        return response(['status' => 'Your reply has been deleted !']);
    }
}
