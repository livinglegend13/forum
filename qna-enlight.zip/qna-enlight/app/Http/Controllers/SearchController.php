<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Thread;
use App\Models\Trending;
use App\Filters\ThreadFilters;

class SearchController extends Controller
{
    public function index(ThreadFilters $filters, Trending $trendings)
    {
        $threads = Thread::latest()->filter($filters);

        if (request()->wantsJson()) {
            return $threads->get();
        }

        return view('threads.index', [
            'threads' => $threads->paginate(10),
            'trendings' => $trendings->get(),
        ]);
    }
}
