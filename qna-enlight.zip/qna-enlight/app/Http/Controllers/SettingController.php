<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class SettingController extends Controller
{
    public function index()
    {
        return view('settings.index');
    }

    public function postSite(Request $request)
    {
        $validatedData = $request->validate([
            'sitename' => 'required|max:50',
            'description' => 'required|max:100',
            'company' => 'required|max:30',
            'siteurl' => 'required|max:50',
        ]);

        Setting::updateOrCreate(
            ['key' => 'sitename'],
            [
                'value' => $validatedData['sitename'],
            ]
        );

        Setting::updateOrCreate(
            ['key' => 'description'],
            [
                'value' => $validatedData['description'],
            ]
        );

        Setting::updateOrCreate(
            ['key' => 'company'],
            [
                'value' => $validatedData['company'],
            ]
        );

        Setting::updateOrCreate(
            ['key' => 'siteurl'],
            [
                'value' => $validatedData['siteurl'],
            ]
        );

        return back()->with('flash', 'Site Settings Updated Successfully');
    }

    public function postSocial(Request $request)
    {
        $request->validate([
            'facebook_link' => 'max:100',
            'whatsapp_link' => 'max:100',
            'instagram_link' => 'max:100',
            'twitter_link' => 'max:100',
        ]);

        if ($request->facebook_link) {
            Setting::updateOrCreate(
                ['key' => 'facebook_link'],
                [
                    'value' => $request->facebook_link,
                ]
            );
        }

        if ($request->whatsapp_link) {
            Setting::updateOrCreate(
                ['key' => 'whatsapp_link'],
                [
                    'value' => $request->whatsapp_link,
                ]
            );
        }

        if ($request->instagram_link) {
            Setting::updateOrCreate(
                ['key' => 'instagram_link'],
                [
                    'value' => $request->instagram_link,
                ]
            );
        }

        if ($request->twitter_link) {
            Setting::updateOrCreate(
                ['key' => 'twitter_link'],
                [
                    'value' => $request->twitter_link,
                ]
            );
        }

        return back()->with('flash', 'Social Link Settings Updated Successfully');
    }

    public function postLogo(Request $request)
    {
        $request->validate([
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
        ]);

        File::delete(
            [
                public_path('logo.png'),
                public_path('apple-touch-icon.png'),
                public_path('favicon-48x48.png'),
                public_path('favicon-32x32.png'),
                public_path('favicon-16x16.png'),
                public_path('logo-96x96.png'),
                public_path('logo-144x144.png'),
                public_path('logo-256x256.png'),
                public_path('logo-512x512.png'),
            ]
        );

        $logo = request()->file('logo');

        $this->cropAndStoreImage($logo, 'logo.png', 180);

        $this->cropAndStoreImage($logo, 'apple-touch-icon.png', 180);

        $this->cropAndStoreImage($logo, 'favicon-48x48.png', 48);

        $this->cropAndStoreImage($logo, 'favicon-32x32.png', 32);

        $this->cropAndStoreImage($logo, 'favicon-16x16.png', 16);

        $this->cropAndStoreImage($logo, 'logo-96x96.png', 96);

        $this->cropAndStoreImage($logo, 'logo-144x144.png', 144);

        $this->cropAndStoreImage($logo, 'logo-256x256.png', 256);

        $this->cropAndStoreImage($logo, 'logo-512x512.png', 512);

        return back()->with('flash', 'Site Logo and Favicons Updated Successfully');
    }
}
