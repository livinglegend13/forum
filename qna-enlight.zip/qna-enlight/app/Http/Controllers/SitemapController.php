<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Thread;

class SitemapController extends Controller
{
    public function index()
    {
        $threads = Thread::all();
        $users = User::all();

        return response()->view('sitemap', [
            'threads' => $threads,
            'users' => $users,
        ], 200)->header('Content-Type', 'text/xml');
    }
}
