<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Thread;
use App\Models\Channel;
use App\Models\Trending;
use App\Rules\Recaptcha;
use Illuminate\Http\Request;
use App\Filters\ThreadFilters;

class ThreadController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
    }

    public function index(Channel $channel, ThreadFilters $filters, Trending $trendings)
    {
        $threads = $this->getThreads($channel, $filters);

        if (request()->wantsJson()) {
            return $threads->get();
        }

        return view('threads.index', [
            'queryChannel' => $channel,
            'threads' => $threads->paginate(20),
            'trendings' => $trendings->get(),
        ]);
    }

    public function create()
    {
        return view('threads.create');
    }

    public function store(Request $request, Recaptcha $recaptcha)
    {
        $request->validate([
            'title' => 'required|max:100',
            'body' => 'required',
            'channel_id' => 'required|exists:channels,id|numeric',
            'recaptcha_response' => ['required', $recaptcha],
        ]);

        $thread = Thread::create([
            'user_id' => auth()->id(),
            'channel_id' => $request->channel_id,
            'title' => $request->title,
            'body' => $request->body,
        ]);

        if (request()->expectsJson()) {
            return response($thread->load('channel'), 201);
        }

        return redirect($thread->path())
            ->with('flash', 'Your thread has been published.');
    }

    public function show($channel, Thread $thread, Trending $trendings)
    {
        if (auth()->check()) {
            auth()->user()->read($thread);
        }

        $trendings->push($thread);

        return view('threads.show', [
            'thread' => $thread,
            'trendings' => $trendings->get(),
        ]);
    }

    public function update($channel, Thread $thread)
    {
        $this->authorize('update', $thread);

        $thread->update(request()->validate([
            'title' => 'required|max:100',
            'body' => 'required',
        ]));
    }

    public function destroy($channel, Thread $thread)
    {
        $this->authorize('update', $thread);

        $thread->delete();

        if (request()->expectsJson()) {
            return response([], 204);
        }

        return redirect(route('threads.index'));
    }

    protected function getThreads($channel, ThreadFilters $filters)
    {
        $threads = Thread::latest()->filter($filters);

        if ($channel->exists) {
            $threads->where('channel_id', $channel->id);
        }

        return $threads;
    }
}
