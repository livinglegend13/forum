<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\Category;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Mailers\TicketMailer;
use Illuminate\Validation\Rule;
use Illuminate\Contracts\View\View;

class TicketController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->user()->hasAnyRole('admin')) {
            $tickets = Ticket::whereStatus('OPENED')
                            ->paginate(10);
        } else {
            $tickets = Ticket::whereUserId(auth()->id())
                            ->whereStatus('OPENED')
                            ->paginate(10);
        }

        return view('tickets.index', [
            'tickets' => $tickets,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tickets.create', ['categories' => Category::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, TicketMailer $mailer)
    {
        $validatedData = $request->validate([
            'category_id' => ['required',  Rule::exists('categories', 'id')],
            'title' => 'required|max:100',
            'message' => 'required',
            'priority' => ['required', Rule::in(['HIGH', 'MEDIUM', 'LOW'])],
        ]);

        $ticket = Ticket::create([
            'user_id' => auth()->id(),
            'category_id' => $validatedData['category_id'],
            'title' => $validatedData['title'],
            'message' => $validatedData['message'],
            'priority' => $validatedData['priority'],
            'slug' => (string) Str::uuid(),
            'status' => 'OPENED',
        ]);

        $mailer->sendTicketInformation(auth()->user(), $ticket);

        return redirect()->route('tickets.index')->with('flash', 'Ticket opened successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Ticket $ticket
     * @return \Illuminate\Contracts\View\View
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function show(Ticket $ticket): View
    {
        $this->authorize('update', $ticket);

        return view('tickets.show', [
            'ticket' => $ticket,
            'category' => $ticket->category,
            'comments' => $ticket->comments,
        ]);
    }

    public function close(Ticket $ticket, TicketMailer $mailer)
    {
        $this->authorize('update', $ticket);

        $ticket->update(['status' => 'CLOSED']);

        $mailer->sendTicketInformation(auth()->user(), $ticket);

        return redirect()->route('tickets.index')->with('flash', 'Ticket closed successfully');
    }
}
