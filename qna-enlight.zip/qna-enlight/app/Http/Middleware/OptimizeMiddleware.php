<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;

class OptimizeMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        $buffer = $response->getContent();
        $replace = [
            '/<!--(.*?)-->/s' => '',
            "/\r/" => '',
            "/\t/" => '',
            '/ +/' => ' ',
            "/>\s+\n</" => '> <',
            "/>\n\s+</" => '> <',
            "/>\s+\n\s+</" => '> <',
            "/\s+\n\s+/" => '',
            "/>\n</" => '> <',
        ];

        $buffer = preg_replace(array_keys($replace), array_values($replace), $buffer);
        $response->setContent($buffer);

        return $response;
    }
}
