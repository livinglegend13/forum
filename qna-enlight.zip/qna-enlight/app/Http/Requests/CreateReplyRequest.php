<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Models\Reply;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Http\FormRequest;
use App\Exceptions\ThrottleException as AppThrottleException;

class CreateReplyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return Gate::allows('create', new Reply);
    }

    /**
     * @throws AppThrottleException
     */
    public function failedAuthorization()
    {
        throw new AppThrottleException();
    }

    public function rules(): array
    {
        return [
            'body' => 'required',
        ];
    }
}
