<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Models\User;
use App\Events\ThreadReceivedNewReply;
use App\Notifications\YouWereMentioned;

class NotifyMentionedUsers
{
    /**
     * Handle the event.
     *
     * @param ThreadReceivedNewReply $event
     */
    public function handle(ThreadReceivedNewReply $event)
    {
        User::whereIn('username', $event->reply->mentionedUsers())
                ->get()
                ->each(function ($user) use ($event) {
                    $user->notify(new YouWereMentioned($event->reply));
                });
    }
}
