<?php declare(strict_types=1);

namespace App\Mailers;

use App\Models\User;
use App\Models\Ticket;
use Illuminate\Contracts\Mail\Mailer;

class TicketMailer
{
    protected $mailer;
    protected $fromAddress = 'support@supportticket.dev';
    protected $fromName = 'Support Ticket';
    protected $to;
    protected $subject;
    protected $view;
    protected $data = [];

    public function __construct(Mailer $mailer)
    {
        $this->mailer = $mailer;
    }

    public function sendTicketInformation($user, Ticket $ticket)
    {
        $this->to = $user->email;
        $this->subject = "[Ticket ID: $ticket->slug] $ticket->title";
        $this->view = 'emails.ticket_info';
        $this->data = compact('user', 'ticket');

        return $this->deliver();
    }

    public function sendTicketComments($ticketOwner, $user, Ticket $ticket, $comment)
    {
        $this->to = $ticketOwner->email;
        $this->subject = "RE: $ticket->title (Ticket ID: $ticket->slug)";
        $this->view = 'emails.ticket_comments';
        $this->data = compact('ticketOwner', 'user', 'ticket', 'comment');

        return $this->deliver();
    }

    public function deliver()
    {
        $this->mailer->send($this->view, $this->data, function ($message) {
            $message->from($this->fromAddress, $this->fromName)
            ->to($this->to)->subject($this->subject);
        });

        $this->notifyAdmins();
    }

    protected function notifyAdmins()
    {
        $admins = User::whereHas('roles', function ($q) {
            $q->whereIn('name', ['admin']);
        })->pluck('email');

        foreach ($admins as $email) {
            $this->mailer->send($this->view, $this->data, function ($message) use ($email) {
                $message->from($this->fromAddress, $this->fromName)
                        ->to($email)->subject($this->subject);
            });
        }
    }
}
