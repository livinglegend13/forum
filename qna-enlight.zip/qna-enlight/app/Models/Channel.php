<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Channel extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function ($channel) {
            $channel->threads->each->delete();
            cache()->forget('channels');
        });
        static::updated(function ($channel) {
            cache()->forget('channels');
        });
        static::created(function ($channel) {
            cache()->forget('channels');
        });
    }

    public function threads()
    {
        return $this->hasMany(Thread::class);
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}
