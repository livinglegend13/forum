<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CountReport extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $hidden = [
        'id',
        'updated_at',
    ];

    protected $casts = [
        'created_at' => 'datetime:d-m-Y',
        'updated_at' => 'datetime:d-m-Y',
    ];

    public function scopeCurrentMonth($query)
    {
        return $query->where(
            'created_at',
            '>=',
            Carbon::now()->firstOfMonth()->toDateTimeString()
        );
    }

    public function scopeLastThirtyDays($query)
    {
        return $query->where(
            'created_at',
            '>=',
            Carbon::now()->subDays(30)->toDateTimeString()
        );
    }
}
