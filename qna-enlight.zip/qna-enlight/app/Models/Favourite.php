<?php

declare(strict_types=1);

namespace App\Models;

use App\Traits\RecordsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Favourite extends Model
{
    use HasFactory;

    use RecordsActivity;

    protected $guarded = [];

    public function favourited()
    {
        return $this->morphTo();
    }
}
