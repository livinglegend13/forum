<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use App\Traits\Favouritable;
use App\Traits\RecordsActivity;
use Stevebauman\Purify\Facades\Purify;
use Illuminate\Database\Eloquent\Model;
use App\Achievements\Points\ReplyCreated;
use App\Achievements\Points\MarkBestReply;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Reply extends Model
{
    use HasFactory;

    use Favouritable, RecordsActivity;

    protected $guarded = [];

    protected $with = ['owner', 'favourites'];

    protected $appends = ['favouritesCount', 'isFavourited', 'isBest', 'humanReadableDate'];

    protected static function boot()
    {
        parent::boot();

        static::created(function ($reply) {
            $reply->thread->increment('replies_count');

            givePoint(new ReplyCreated($reply), $reply->owner);

            CountReport::firstOrCreate(['created_at' => Carbon::today()])
                ->increment('replies_count');
        });

        static::deleting(function ($reply) {
            if ($reply->fresh()->isBest()) {
                undoPoint(new MarkBestReply($reply), $reply->owner);
            }

            $reply->thread->decrement('replies_count');

            undoPoint(new ReplyCreated($reply), $reply->owner);

            $countReport = CountReport::whereDate('created_at', $reply->created_at)->first();

            if ($countReport && $countReport->replies_count > 0) {
                $countReport->decrement('replies_count');
            }
        });
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function thread()
    {
        return $this->belongsTo(Thread::class);
    }

    public function path()
    {
        return $this->thread->path() . '#reply-' . $this->id;
    }

    public function wasJustPublished()
    {
        return $this->created_at->gt(Carbon::now()->subSeconds(10));
    }

    public function mentionedUsers()
    {
        preg_match_all(
            '/\@([A-Za-z0-9\-\_]+)/',
            $this->body,
            $matches
        );

        return $matches[1];
    }

    public function getBodyAttribute($body)
    {
        return Purify::clean($body);
    }

    public function isBest(): bool
    {
        return (int)$this->thread->best_reply_id === (int)$this->id;
    }

    public function getIsBestAttribute(): bool
    {
        return $this->isBest();
    }

    public function getHumanReadableDateAttribute()
    {
        return $this->created_at->diffForHumans();
    }
}
