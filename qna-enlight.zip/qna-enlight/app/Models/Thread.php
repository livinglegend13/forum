<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Traits\RecordsActivity;
use App\Events\ThreadReceivedNewReply;
use Stevebauman\Purify\Facades\Purify;
use Illuminate\Database\Eloquent\Model;
use App\Achievements\Points\MarkBestReply;
use App\Achievements\Points\ThreadCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Thread extends Model
{
    use HasFactory;

    use RecordsActivity;

    protected $guarded = [];

    protected $with = ['creator', 'channel'];

    protected $appends = ['isSubscribedTo'];

    protected $casts = [
        'locked' => 'boolean',
    ];

    protected static function boot()
    {
        parent::boot();

        static::created(function ($thread) {
            $thread->update([
                'slug' => $thread->title,
            ]);

            givePoint(new ThreadCreated($thread), $thread->creator);

            CountReport::firstOrCreate(['created_at' => Carbon::today()])
                ->increment('threads_count');
        });

        static::deleting(function ($thread) {
            undoPoint(new ThreadCreated($thread), $thread->creator);

            $thread->replies->each->delete();

            $countReport = CountReport::whereDate('created_at', $thread->created_at)->first();

            if ($countReport && $countReport->threads_count > 0) {
                $countReport->decrement('threads_count');
            }
        });
    }

    public function path()
    {
        return '/threads/' . $this->channel->slug . '/' . $this->slug;
    }

    public function whatsappPath()
    {
        return '//api.whatsapp.com/send?text=' . asset($this->path());
    }

    public function facebookPath()
    {
        return 	'//www.facebook.com/sharer/sharer.php?u=' . asset($this->path());
    }

    public function twitterPath()
    {
        return '//twitter.com/share?url=' . asset($this->path());
    }

    public function replies()
    {
        return $this->hasMany(Reply::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function addReply($reply): Model
    {
        $reply = $this->replies()->create($reply);

        event(new ThreadReceivedNewReply($reply));

        return $reply;
    }

    public function lock()
    {
        $this->update(['locked' => true]);
    }

    public function unlock()
    {
        $this->update(['locked' => false]);
    }

    public function channel()
    {
        return $this->belongsTo(Channel::class);
    }

    public function scopeFilter($query, $filters)
    {
        return $filters->apply($query);
    }

    public function subscribe($userId = null)
    {
        $this->subscriptions()->create([
            'user_id' => $userId ?: auth()->id(),
        ]);

        return $this;
    }

    public function unsubscribe($userId = null)
    {
        $this->subscriptions()->where([
            'user_id' => $userId ?: auth()->id(),
        ])->delete();
    }

    public function subscriptions()
    {
        return  $this->hasMany(ThreadSubscription::class);
    }

    public function getIsSubscribedToAttribute()
    {
        return $this->subscriptions()
        ->where('user_id', auth()->id())
        ->exists();
    }

    public function hasUpdatesFor($user)
    {
        $key = auth()->user()->visitedThreadCacheKey($this);

        return $this->updated_at > cache($key);
    }

    public function setSlugAttribute($value)
    {
        $slug = Str::slug($value);

        if (static::whereSlug($slug)->exists()) {
            $slug = $slug . '-' . $this->id;
        }

        return $this->attributes['slug'] = $slug;
    }

    public function getBodyAttribute($body)
    {
        return Purify::clean($body);
    }

    public function markBestReply(Reply $reply)
    {
        $this->updateReputation($reply);

        $this->update([
            'best_reply_id' => $reply->id,
        ]);
    }

    protected function updateReputation($reply)
    {
        $old_reply = Reply::where('id', $this->best_reply_id)->first();

        if ($old_reply) {
            undoPoint(new MarkBestReply($old_reply), $old_reply->owner);
        }

        givePoint(new MarkBestReply($reply), $reply->owner);
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}
