<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

class Trending
{
    use HasFactory;

    public function get()
    {
        return Thread::orderBy('visits', 'desc')->take(5)->get();
    }

    public function push(Thread $thread)
    {
        $thread->increment('visits');
    }
}
