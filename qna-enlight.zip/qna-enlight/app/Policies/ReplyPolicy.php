<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use App\Models\Reply;
use Illuminate\Auth\Access\HandlesAuthorization;

class ReplyPolicy
{
    use HandlesAuthorization;

    public function update(User $authenticatedUser, Reply $reply): bool
    {
        if ($authenticatedUser->hasRole('admin')) {
            return true;
        }

        return (int)$reply->user_id === (int)$authenticatedUser->id;
    }

    public function create(User $authenticatedUser): bool
    {
        $lastReply = $authenticatedUser->fresh()->lastReply;

        if (! $lastReply) {
            return true;
        }

        return ! $lastReply->wasJustPublished();
    }
}
