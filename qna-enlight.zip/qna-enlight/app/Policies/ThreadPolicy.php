<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use App\Models\Thread;
use Illuminate\Auth\Access\HandlesAuthorization;

class ThreadPolicy
{
    use HandlesAuthorization;

    public function update(User $authenticatedUser, Thread $thread): bool
    {
        if ($authenticatedUser->hasRole('admin')) {
            return true;
        }

        return (int)$thread->user_id === (int)$authenticatedUser->id;
    }
}
