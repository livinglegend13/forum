<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use App\Models\Ticket;
use Illuminate\Auth\Access\HandlesAuthorization;

class TicketPolicy
{
    use HandlesAuthorization;

    public function update(User $authenticatedUser, Ticket $ticket): bool
    {
        if ($authenticatedUser->hasRole('admin')) {
            return true;
        }

        return (int)$ticket->user_id === (int)$authenticatedUser->id;
    }
}
