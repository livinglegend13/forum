<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class UserPolicy
{
    use HandlesAuthorization;

    public function update(User $authenticatedUser, User $signedInUser): bool
    {
        if ($authenticatedUser->hasRole('admin')) {
            return true;
        }

        return (int)$signedInUser->id === (int)$authenticatedUser->id;
    }
}
