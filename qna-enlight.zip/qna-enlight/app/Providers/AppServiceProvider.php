<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\Channel;
use App\Models\Setting;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register()
    {
        \View::composer('*', function ($view) {
            $channels = \Cache::rememberForever('channels', function () {
                return Channel::all();
            });

            $view->with('channels', $channels);

            $settings = \Cache::rememberForever('settings', function () {
                return Setting::all();
            });

            $view->with('settings', $settings);
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot()
    {
        if (config('app.force_https')) {
            URL::forceScheme('https');
        }

        Schema::defaultStringLength(191);
    }
}
