<?php declare(strict_types=1);

namespace App\Rules;

use App\Models\Setting;
use Illuminate\Contracts\Validation\Rule;

class Recaptcha implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $secret = Setting::where(['key' => 'recaptcha_secret'])->pluck('value')->first();

        if (! $secret) {
            return false;
        }

        $http = new \GuzzleHttp\Client();

        $response = $http->post('https://www.google.com/recaptcha/api/siteverify', [
            'form_params' => [
                'secret' => $secret,
                'response' => $value,
                'remoteip' => request()->ip(),
            ],
        ]);

        $response = json_decode($response->getBody()->getContents());

        return $response->success;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The reCaptcha Verification failed.';
    }
}
