<?php declare(strict_types=1);

namespace App\Traits;

use App\Models\Favourite;
use App\Achievements\Points\ReplyFavourited;

trait Favouritable
{
    public static function bootFavouritable()
    {
        static::deleting(function ($model) {
            $model->favourites->each(function ($m) {
                undoPoint(new ReplyFavourited($m->favourited), $m->favourited->owner);

                $m->delete();
            });
        });
    }

    public function favourites()
    {
        return $this->morphMany(Favourite::class, 'favourited');
    }

    public function favourite()
    {
        $attributes = ['user_id' => auth()->id()];

        if (! $this->favourites()->where($attributes)->exists()) {
            givePoint(new ReplyFavourited($this), $this->owner);

            return $this->favourites()->create($attributes);
        }
    }

    public function unfavourite()
    {
        $attributes = ['user_id' => auth()->id()];

        undoPoint(new ReplyFavourited($this), $this->owner);

        $this->favourites()->where($attributes)->get()->each->delete();
    }

    public function isFavourited()
    {
        return (bool) $this->favourites->where('user_id', auth()->id())->count();
    }

    public function getIsFavouritedAttribute()
    {
        return $this->isFavourited();
    }

    public function getFavouritesCountAttribute()
    {
        return $this->favourites->count();
    }
}
