<?php declare(strict_types=1);

return [
    // Allow duplicate reputation points
    'allow_reputation_duplicate' => true,

    // Where all badges icon stored
    'badge_icon_folder' => 'badges/',

    // Extention of badge icons
    'badge_icon_extension' => '.svg',

    // All the levels for badge
    'badge_levels' => [
        'beginner' => 1,
        'intermediate' => 2,
        'advanced' => 3,
        'pro' => 4,
    ],

    // Default level
    'badge_default_level' => 1
];
