<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\User;
use App\Models\Ticket;
use App\Models\Category;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Factories\Factory;

class TicketFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Ticket::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition(): array
    {
        return [
            'user_id' => function () {
                return User::first()->id ?? User::factory()->create()->id;
            },
            'category_id' => function () {
                return Category::first()->id ?? Category::factory()->create()->id;
            },
            'slug' => (string)Str::uuid(),
            'title' => $this->faker->sentence,
            'message' => $this->faker->sentence,
            'priority' => 'HIGH',
            'status' => 'OPENED',
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     *
     * @return Factory
     */
    public function unverified(): Factory
    {
        return $this->state(function (array $attributes) {
            return [
                'email_verified_at' => null,
            ];
        });
    }
}
