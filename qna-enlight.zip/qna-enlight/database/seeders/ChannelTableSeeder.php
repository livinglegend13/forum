<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ChannelTableSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('channels')->insert(
            [
                'name' => 'Laravel',
                'slug' => 'laravel',
                'font_awesome_classes' => 'fab fa-laravel red',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        DB::table('channels')->insert(
            [
                'name' => 'Vue.js',
                'slug' => 'vuejs',
                'font_awesome_classes' => 'fab fa-vuejs green',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        DB::table('channels')->insert(
            [
                'name' => 'PHP',
                'slug' => 'php',
                'font_awesome_classes' => 'fab fa-php blue',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        DB::table('channels')->insert(
            [
                'name' => 'General',
                'slug' => 'general',
                'font_awesome_classes' => 'fas fa-th',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
}
