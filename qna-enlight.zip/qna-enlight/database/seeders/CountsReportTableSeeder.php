<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CountsReportTableSeeder extends Seeder
{
    public function run(): void
    {
        for ($i = 0; $i < 100; $i++) {
            DB::table('count_reports')->insert(
                [
                    'users_count' => rand(10, 60),
                    'threads_count' => rand(10, 60),
                    'replies_count' => rand(10, 60),
                    'created_at' => now()->subDays($i + 1),
                    'updated_at' => now(),
                ]
            );
        }
    }
}
