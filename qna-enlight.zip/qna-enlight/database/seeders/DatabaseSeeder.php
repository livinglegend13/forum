<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(RoleTableSeeder::class);
        $this->call(UserTableSeeder::class);
        $this->call(ChannelTableSeeder::class);
        $this->call(RecaptchaKeySeeder::class);
        // $this->call(ThreadsTableSeeder::class);
        // $this->call(CountsReportTableSeeder::class);

        Artisan::call('optimize:clear');
        // Artisan::call('cache:forget achievements.badges.all');
    }
}
