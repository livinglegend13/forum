<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class RecaptchaKeySeeder extends Seeder
{
    public function run(): void
    {
        Setting::updateOrCreate(
            ['key' => 'recaptcha_key'],
            [
                'value' => '6LfSHYIUAAAAANSPEDbHYumJqsHrEqULCwRJdJyZ'
            ]
        );

        Setting::updateOrCreate(
            ['key' => 'recaptcha_secret'],
            [
                'value' => '6LfSHYIUAAAAAHwUqW3cMYYZDs1QYAKIp3fCdE6X'
            ]
        );
    }
}
