<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoleTableSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('roles')->insert(
            [
                'name' => 'admin',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
}
