<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Reply;
use App\Models\Thread;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class ThreadsTableSeeder extends Seeder
{
    public function run(): void
    {
        $threads = factory(Thread::class, 51)->create([
            'channel_id' => rand(1, 3)
        ]);

        foreach ($threads as $thread) {
            $thread->update([
                'channel_id' => rand(1, 3)
            ]);
        }

        $threads->each(
            function ($thread) {
                DB::table('activities')->insert(
                    [
                        'user_id' => $thread->user_id,
                        'subject_id' => $thread->id,
                        'subject_type' => Thread::class,
                        'type' => 'created_thread',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]
                );

                $replies = factory(Reply::class, 10)->create(['user_id' => rand(1, 20), 'thread_id' => $thread->id]);

                $replies->each(
                    function ($reply) {
                        $reply->update([
                            'user_id' => rand(1, 20)
                        ]);

                        DB::table('activities')->insert(
                            [
                                'user_id' => $reply->fresh()->user_id,
                                'subject_id' => $reply->id,
                                'subject_type' => Reply::class,
                                'type' => 'created_reply',
                                'created_at' => Carbon::now(),
                                'updated_at' => Carbon::now(),
                            ]
                        );
                    }
                );
            }
        );
    }
}
