require('./bootstrap');

// components

Vue.component('paginator', require('./components/Paginator.vue').default);

Vue.component('thread-create', require('./pages/CreateThread.vue').default);

Vue.component('user-notifications', require('./components/UserNotifications.vue').default);

Vue.component('wysiwyg', require('./components/WYSIWYG.vue').default);

Vue.component('scroll-link', require('./components/ScrollLink.vue').default);

Vue.component('scroll-to-top', require('./components/ScrollToTop.vue').default);

Vue.component('sidebar', require('./components/Sidebar.vue').default);

Vue.component("avatar-form", require("./components/AvatarForm.vue").default);

Vue.component("counts-graph", require("./components/CountsGraph.vue").default);

Vue.component("cookie", require("./components/Cookie.vue").default);

Vue.component("hamburger", require("./components/Hamburger.vue").default);

// pages 

Vue.component('thread-view', require('./pages/Thread.vue').default);

Vue.component('profile-view', require('./pages/Profile.vue').default);

new Vue({
    el: '#app',
});

document.addEventListener("keydown", function (e) {
    if (e.keyCode === 27) { // 'Esc' key code
        document.getElementById('page-wrapper').classList.add('toggled');
        document.getElementById("q").focus();
    }
});