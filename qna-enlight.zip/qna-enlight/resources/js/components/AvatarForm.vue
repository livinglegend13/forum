<template>
  <div class="row">
    <div class="col-12 d-flex flex-column align-items-center">
      <div class="avatar-container" v-if="canUpdate" @click="triggerUploader">
        <img v-if="canUpdate" :src="avatar" :alt="alt" class="profile" />
        <div class="avatar-overlay">
          <div class="text">
            <i class="fas fa-camera"></i> Upload
          </div>
        </div>
      </div>

      <img v-else :src="avatar" :alt="alt" class="rounded-circle" />

      <h2 class="font-weight-bold text-capitalize mt-3" v-text="user.name"></h2>
    </div>
    <div class="col-12 d-flex align-items-center">
      <form v-if="canUpdate" method="POST" enctype="multipart/form-data">
        <image-upload
          id="avatarUpload"
          class="form-control"
          name="avatar"
          @loaded="onLoad"
          ref="uploader"
        ></image-upload>
      </form>
    </div>
  </div>
</template>

<script>
import ImageUpload from "./ImageUpload.vue";

import Toast from "../mixins/SweetAlert";

export default {
  props: ["user"],

  components: { ImageUpload },

  data() {
    return {
      avatar: this.user.avatar,
      alt: this.user.name
    };
  },

  computed: {
    canUpdate() {
      return this.authorize(user => {
        if (user.isAdmin) return true;
        return user.id === this.user.id;
      });
    },
    reputation() {
      return this.user.reputation + " RP";
    }
  },

  methods: {
    triggerUploader() {
      this.$refs.uploader.$el.click();
    },
    onLoad(avatar) {
      this.avatar = avatar.src;

      this.persist(avatar.file);
    },

    persist(avatar) {
      this.$Progress.start();
      let data = new FormData();

      data.append("avatar", avatar);

      axios.post(`/api/users/${this.user.username}/avatar`, data).then(() => {
        Toast.fire({
          icon: "success",
          title: "Avatar uploaded !!"
        });

        this.$Progress.finish();
      });
    }
  }
};
</script>
<style scoped>
#avatarUpload {
  position: absolute;
  top: -1000px;
}

.avatar-container {
  position: relative;
}

.profile {
  display: block;
  max-width: 100px;
  max-height: 100px;
  height: auto;
  cursor: pointer;
  border-radius: 100%;
  box-shadow: 0 5px 8px rgba(0, 0, 0, 0.35);
}

.avatar-overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: 0.5s ease;
  background-color: #a5a5a5;
  border-radius: 100%;
  cursor: pointer;
}

.avatar-container:hover .avatar-overlay {
  opacity: 1;
}

.text {
  color: white;
  font-size: 14px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  text-align: center;
}
</style>