<template>
  <div
    class="cookieConsentContainer"
    ref="cookieConsentContainer"
    style="opacity: -0.02; display: none;"
  >
    <div class="cookieDesc">
      <p>
        By using our site, you acknowledge that you have read and understand our
        <a
          target="_blank"
          href="/cookie-policy"
        >Cookie Policy</a> and our
        <a target="_blank" href="/privacy-policy">Privacy Policy</a>.
      </p>
    </div>
    <div class="cookieButton">
      <a @click="purecookieDismiss()">Understood</a>
    </div>
  </div>
</template>

<script>
export default {
  mounted() {
    this.cookieConsent();
  },

  methods: {
    cookieConsent() {
      if (!this.getCookie("cookie-consent")) {
        this.pureFadeIn();
      }
    },

    pureFadeIn(display) {
      var el = this.$refs.cookieConsentContainer;
      el.style.opacity = 0;
      el.style.display = display || "block";

      (function fade() {
        var val = parseFloat(el.style.opacity);
        if (!((val += 0.02) > 1)) {
          el.style.opacity = val;
          requestAnimationFrame(fade);
        }
      })();
    },

    pureFadeOut() {
      var el = this.$refs.cookieConsentContainer;
      el.style.opacity = 1;

      (function fade() {
        if ((el.style.opacity -= 0.02) < 0) {
          el.style.display = "none";
        } else {
          requestAnimationFrame(fade);
        }
      })();
    },

    getCookie(name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(";");
      for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == " ") c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
      }
      return null;
    },

    setCookie(name, value, days) {
      var expires = "";
      if (days) {
        var date = new Date();
        date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
        expires = "; expires=" + date.toUTCString();
      }
      document.cookie = name + "=" + (value || "") + expires + "; path=/";
    },

    eraseCookie(name) {
      document.cookie = name + "=; Max-Age=-99999999;";
    },

    purecookieDismiss() {
      this.setCookie("cookie-consent", "1", 365);
      this.pureFadeOut();
    }
  }
};
</script>

<style scoped>
.cookieConsentContainer {
  z-index: 999;
  width: 350px;
  min-height: 20px;
  box-sizing: border-box;
  padding: 30px 30px 30px 30px;
  background: #232323;
  overflow: hidden;
  position: fixed;
  bottom: 30px;
  right: 30px;
  display: none;
}
.cookieConsentContainer .cookieDesc p {
  margin: 0;
  padding: 0;
  font-family: OpenSans, arial, "sans-serif";
  color: #ffffff;
  font-size: 13px;
  line-height: 20px;
  display: block;
  margin-top: 10px;
}
.cookieConsentContainer .cookieDesc a {
  font-family: OpenSans, arial, "sans-serif";
  color: #ffffff;
  text-decoration: underline;
}
.cookieConsentContainer .cookieButton a {
  display: inline-block;
  font-family: OpenSans, arial, "sans-serif";
  color: #ffffff;
  font-size: 14px;
  font-weight: bold;
  margin-top: 14px;
  background: #000000;
  box-sizing: border-box;
  padding: 15px 24px;
  text-align: center;
  transition: background 0.3s;
}
.cookieConsentContainer .cookieButton a:hover {
  cursor: pointer;
  background: #3e9b67;
}

@media (max-width: 980px) {
  .cookieConsentContainer {
    bottom: 0px !important;
    left: 0px !important;
    width: 100% !important;
  }
}
</style>