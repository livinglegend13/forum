<template>
  <canvas :width="width" :height="height" ref="canvas"></canvas>
</template>

<script>
import Chart from "chart.js";

export default {
  props: {
    url: {
      required: true
    },
    type: {
      default: "line"
    },
    width: {
      default: 900
    },
    height: {
      default: 300
    }
  },
  data() {
    return {
      chart: ""
    };
  },
  mounted() {
    this.load();
  },

  methods: {
    load() {
      this.fetchData().then(response => this.render(response.data));
    },
    fetchData() {
      return axios.get(this.url);
    },
    render(data) {
      let labels = this.getLabelsFromData(data);

      this.chart = new Chart(this.$refs.canvas.getContext("2d"), {
        type: this.type,
        data: {
          labels: labels,
          datasets: [
            this.getUsersData(data),
            this.getThreadsData(data),
            this.getRepliesData(data)
          ]
        },
        options: {
          scales: {
            yAxes: [
              {
                ticks: {
                  beginAtZero: true
                }
              }
            ]
          }
        }
      });
    },
    getLabelsFromData(data) {
      let labels = [];
      Object.values(data).forEach(function(item) {
        labels.push(item["created_at"]);
      });
      return labels;
    },
    getUsersData(data) {
      let users = [];
      Object.values(data).forEach(function(item) {
        users.push(item["users_count"]);
      });

      return {
        label: "# of Users",
        data: users,
        backgroundColor: ["rgba(255, 99, 132, 0.2)"],
        borderColor: ["rgba(255, 99, 132, 1)"],
        borderWidth: 1
      };
    },
    getThreadsData(data) {
      let threads = [];
      Object.values(data).forEach(function(item) {
        threads.push(item["threads_count"]);
      });

      return {
        label: "# of Threads",
        data: threads,
        backgroundColor: ["rgba(54, 162, 235, 0.2)"],
        borderColor: ["rgba(54, 162, 235, 1)"],
        borderWidth: 1
      };
    },
    getRepliesData(data) {
      let replies = [];
      Object.values(data).forEach(function(item) {
        replies.push(item["replies_count"]);
      });

      return {
        label: "# of Replies",
        data: replies,
        backgroundColor: ["rgba(153, 102, 255, 0.2)"],
        borderColor: ["rgba(153, 102, 255, 1)"],
        borderWidth: 1
      };
    }
  }
};
</script>

<style>
</style>