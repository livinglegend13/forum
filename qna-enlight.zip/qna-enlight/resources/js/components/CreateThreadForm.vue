<template>
  <div>
    <div v-if="signedIn" class="card border-primary card-primary">
      <div class="card-body">
        <div class="form-group">
          <label for="channel_id" class="font-weight-bold">Choose Channel</label>
          <select class="form-control" v-model="channel_id" id="channel_id" required>
            <option disabled value>Choose one from list</option>
            <option
              v-for="channel in channels"
              :key="channel.id"
              :value="channel.id"
              v-text="channel.name"
            ></option>
          </select>
          <span
            v-if="errors.channel_id"
            v-text="errors.channel_id ? errors.channel_id[0] : ''"
            class="red"
          ></span>
          <small v-else>Ask your question to specific community</small>
        </div>
        <div class="form-group">
          <label for="title" class="font-weight-bold">Title :</label>
          <input
            type="text"
            class="form-control"
            v-model="title"
            id="title"
            required
            placeholder="Title here.."
          />
          <span v-if="errors.title" v-text="errors.title ? errors.title[0] : ''" class="red"></span>
          <small v-else>Be specific and imagine you’re asking a question to another person</small>
        </div>
        <div class="form-group">
          <label for="body" class="font-weight-bold">Body :</label>
          <wysiwyg
            id="create-thread"
            name="body"
            v-model="body"
            :value="body"
            placeholder="Explain here.."
            required
          ></wysiwyg>
          <span v-if="errors.body" v-text="errors.body ? errors.body[0] : ''" class="red"></span>
          <small v-else>Include all the information someone would need to answer your question</small>
        </div>
        <input
          type="hidden"
          id="g-recaptcha"
          name="recaptcha_response"
          v-model="recaptcha_response"
        />

        <input
          type="submit"
          id="publish"
          class="btn btn-primary"
          @click="addThread"
          value="Publish"
          v-tooltip="'Publish a Thread'"
          :disabled="active"
        />
      </div>
    </div>
    <p class="text-center mt-4" v-else>
      Please
      <a href="/login">Sign in</a> to ask questions.
    </p>
  </div>
</template>

<script>
export default {
  props: ["channels", "recaptcha_site_key"],

  data() {
    return {
      channel_id: "",
      title: "",
      body: "",
      active: false,
      recaptcha_response: "",
      errors: {}
    };
  },
  mounted() {
    this.load();
  },
  methods: {
    addThread() {
      this.$Progress.start();
      this.active = true;

      axios
        .post("/threads", {
          channel_id: this.channel_id,
          title: this.title,
          body: this.body,
          recaptcha_response: this.recaptcha_response
        })
        .then(({ data }) => {
          this.$Progress.finish();
          window.location = "/threads/" + data.channel.slug + "/" + data.slug;
        })
        .catch(error => {
          this.errors = error.response.data.errors;

          this.active = false;

          this.load();
          this.$Progress.fail();
        });
    },
    load() {
      let vm = this;
      grecaptcha.ready(function() {
        grecaptcha
          .execute(vm.recaptcha_site_key, {
            action: "homepage"
          })
          .then(function(response) {
            vm.recaptcha_response = response;
          });
      });
    }
  }
};
</script>

<style>
</style>
