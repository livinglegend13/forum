<template>
  <div class="d-flex align-items-center">
    <button v-tooltip="'Like/Unlike a Reply'" type="submit" :class="classes" @click="toggle">
      <span :class="textClasses" v-text="count"></span>
      <span :class="heartClasses"></span>
    </button>
  </div>
</template>

<script>
import Toast from "../mixins/SweetAlert";

export default {
  props: ["reply"],

  data() {
    return {
      count: this.reply.favouritesCount,
      active: this.reply.isFavourited
    };
  },

  computed: {
    classes() {
      return ["btn", "btn-sm", "bg-red", "rounded-pill"];
    },
    textClasses() {
      return [this.active ? "red" : ""];
    },
    heartClasses() {
      return ["fa", "fa-heart", this.active ? "red" : ""];
    },
    endpoint() {
      return "/replies/" + this.reply.id + "/favourites";
    }
  },

  methods: {
    toggle() {
      this.$Progress.start();
      this.active ? this.destroy() : this.create();
    },

    create() {
      axios.post(this.endpoint);

      this.active = true;

      this.count++;

      Toast.fire({
        icon: "success",
        title: "Liked a reply"
      });

      this.$Progress.finish();
    },

    destroy() {
      axios.delete(this.endpoint);

      this.active = false;

      this.count--;

      Toast.fire({
        icon: "success",
        title: "Unliked a reply"
      });

      this.$Progress.finish();
    }
  }
};
</script>
