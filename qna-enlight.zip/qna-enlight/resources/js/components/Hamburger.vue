<template>
  <div class="mr-auto">
    <a
      v-tooltip="active ? 'Close Sidebar' : 'Open Sidebar'"
      @click.prevent="toggle"
      class="mr-1 text-decoration-none fixed-md"
    >
      <i :class="toggleClass"></i>
    </a>
    <portal to="overlay">
      <div class="overlay" @click.prevent="toggle"></div>
    </portal>
  </div>
</template>

<script>
export default {
  data() {
    return {
      active: false
    };
  },
  computed: {
    toggleClass() {
      return ["fas", "fa-2x", this.active ? "fa-times" : "fa-sliders-h"];
    }
  },
  methods: {
    toggle() {
      this.active = !this.active;
      localStorage.setItem("hamburger", this.active);
      document.getElementById("page-wrapper").classList.toggle("toggled");
    },
    isMobile() {
      if (
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
          navigator.userAgent
        )
      ) {
        return true;
      } else {
        return false;
      }
    }
  },
  mounted() {
    if (!this.isMobile()) {
      this.active = JSON.parse(localStorage.getItem("hamburger"));
    } else {
      this.active = false;
    }

    if (this.active) {
      document.getElementById("page-wrapper").classList.add("toggled");
    } else {
      document.getElementById("page-wrapper").classList.remove("toggled");
    }
  }
};
</script>

<style scoped>
@media (min-width: 767px) {
  .fixed-md {
    position: fixed;
    cursor: pointer;
  }
}
</style>