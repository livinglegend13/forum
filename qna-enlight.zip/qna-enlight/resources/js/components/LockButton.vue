<template>
  <button :class="classes" v-tooltip="title" @click="toggleLock" v-if="authorize('isAdmin')">
    <span class="font-weight-bold" v-if="active">&#128274; Locked</span>
    <span class="blue font-weight-bold" v-else>Unlocked</span>
  </button>
</template>

<script>
import Toast from "../mixins/SweetAlert";

export default {
  props: ["thread"],

  data() {
    return {
      active: this.thread.locked
    };
  },

  computed: {
    classes() {
      return [
        "btn",
        "rounded",
        this.active ? "btn-primary" : "bg-blue",
        "mr-2"
      ];
    },

    title() {
      return this.active ? "Unlock this Thread" : "Lock this Thread";
    }
  },

  methods: {
    toggleLock() {
      this.$Progress.start();

      axios[this.active ? "delete" : "post"](
        "/lock-threads/" + this.thread.slug
      );

      this.$emit("lock_toggled");

      this.active = !this.active;

      Toast.fire({
        icon: "success",
        title: this.active ? "Thread is Locked" : "Thread is Unlocked"
      });

      this.$Progress.finish();
    }
  }
};
</script>

<style>
</style>