<template>
  <div class="mt-4">
    <div v-if="signedIn" class="card border-primary card-primary">
      <div class="card-body">
        <div class="form-group">
          <wysiwyg
            id="new-reply-body"
            name="body"
            v-model="body"
            placeholder="Have something to say.."
          ></wysiwyg>
        </div>
        <input
          type="submit"
          class="btn btn-primary"
          @click="addReply"
          value="Post"
          v-tooltip="'Post Reply'"
          :disabled="active"
        />
      </div>
    </div>
    <p class="text-center my-4" v-else>
      Please
      <a href="/login">Sign in</a> to participate in this discussion.
    </p>
  </div>
</template>

<script>
import Toast from "../mixins/SweetAlert";

export default {
  data() {
    return {
      body: "",
      active: false
    };
  },
  methods: {
    addReply() {
      this.$Progress.start();
      this.active = true;

      axios
        .post(location.pathname + "/replies", { body: this.body })
        .then(({ data }) => {
          this.body = "";

          Toast.fire({
            icon: "success",
            title: "Your reply has been posted !!"
          });

          this.$emit("reply_created", data);

          this.active = false;

          this.$Progress.finish();
        })
        .catch(error => {
          Toast.fire({
            icon: "error",
            title: JSON.stringify(error.response.data.errors)
          });

          this.active = false;
          this.$Progress.fail();
        });
    }
  }
};
</script>

<style>
</style>
