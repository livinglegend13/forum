<template>
  <div class="col-12 mt-4">
    <div v-for="(reply,index) in items" :key="reply.id">
      <reply :reply="reply" @reply_deleted="remove(index)"></reply>
    </div>
    <paginator :dataSet="dataSet" @page_changed="fetch"></paginator>
    <new-reply @reply_created="add" v-if="! $parent.active"></new-reply>
    <p
      class="font-weight-bold text-center"
      v-else
    >This thread has been &#128274; locked !! No more replies are allowed !!</p>
  </div>
</template>

<script>
import Reply from "./Reply.vue";

import NewReply from "./NewReply.vue";

import collection from "../mixins/Collection";

export default {
  components: { Reply, NewReply },

  mixins: [collection],

  data() {
    return {
      dataSet: false
    };
  },
  created() {
    this.fetch();
  },
  methods: {
    fetch(page) {
      axios.get(this.url(page)).then(this.refresh);
    },
    url(page) {
      if (!page) {
        let query = location.search.match(/page=(\d+)/);

        page = query ? query[1] : 1;
      }

      return `${location.pathname}/replies?page=${page}`;
    },
    refresh({ data }) {
      this.dataSet = data;

      this.items = data.data;

      document.querySelector("#app").scrollIntoView({ behavior: "smooth" });
    }
  }
};
</script>

<style>
</style>