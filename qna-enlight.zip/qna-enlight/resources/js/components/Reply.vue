<template>
  <div :id="'reply-' + id " class="card mb-4">
    <div class="card-header">
      <div class="d-flex align-items-center">
        <div class="green-check-wraper" v-if="isBest">
          <span class="green-check">
            <i class="fas fa-check"></i>
          </span>
          <img
            class="mr-2 rounded-circle border border-success"
            :src="reply.owner.avatar"
            :alt="reply.owner.name"
            height="45"
          />
        </div>
        <img
          v-else
          class="mr-2 rounded-circle"
          :alt="reply.owner.name"
          :src="reply.owner.avatar"
          height="45"
        />
        <div class="d-flex flex-column">
          <a class="mr-2" :href="'/profiles/' + reply.owner.username" v-text="reply.owner.username"></a>
          <small class="mr-2 text-capitalize font-weight-bold text-muted">said {{ ago }}</small>
        </div>

        <span v-if="isBest" class="is-best font-weight-bold d-none d-md-block">Best answer</span>

        <span class="float-right ml-auto">
          <favourite :reply="reply" v-if="signedIn"></favourite>
          <span v-else>
            <span v-text="reply.favouritesCount"></span>
            <span class="fa fa-heart"></span>
          </span>
        </span>
      </div>
    </div>

    <div class="card-body">
      <div v-if="editing">
        <div class="form-group">
          <wysiwyg :id="'reply-body-' + id" name="reply_body" v-model="body" :value="body"></wysiwyg>
        </div>
        <div class="d-flex align-items-center">
          <button
            type="button"
            class="btn btn-sm bg-blue blue font-weight-bold float-left mt-2 mr-3"
            @click="update"
            v-tooltip="'Update Reply'"
          >Update</button>
          <button
            type="button"
            class="btn btn-sm mt-2"
            @click="cancel"
            v-tooltip="'Cancel Editing'"
          >Cancel</button>
          <button
            type="submit"
            v-tooltip="'Delete Reply'"
            class="btn btn-sm btn-outline-danger ml-auto"
            @click="destroy"
          >
            <i class="fa fa-times-circle"></i>
          </button>
        </div>
      </div>
      <div v-else v-html="body"></div>
    </div>
    <div class="card-footer" v-if="authorize('owns', reply) || authorize('owns', reply.thread)">
      <div v-if="! editing">
        <div class="d-inline" v-if="authorize('owns', reply)">
          <button
            type="submit"
            v-tooltip="'Edit Reply'"
            class="btn btn-sm btn-outline-primary float-left mr-2"
            @click="editing = true"
          >
            <i class="fas fa-edit"></i>
          </button>
        </div>

        <button
          type="submit"
          v-tooltip="'Mark this as a best reply !!'"
          class="btn btn-sm btn-outline-success float-right"
          @click="markBestReply"
          v-show="!isBest"
          v-if="authorize('owns', reply.thread)"
        >
          <i class="fa fa-check"></i>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import Favourite from "./Favourite.vue";

import hljs from "highlightjs";

import "../../sass/_hljs.scss";

import Toast from "../mixins/SweetAlert";

export default {
  props: ["reply"],

  components: { Favourite },

  data() {
    return {
      id: this.reply.id,
      editing: false,
      body: this.reply.body,
      old_body: this.reply.body,
      isBest: this.reply.isBest
    };
  },

  computed: {
    ago() {
      return this.reply.humanReadableDate + "...";
    }
  },
  created() {
    window.events.$on("best-reply-selected", id => {
      this.isBest = id === this.id;
    });
  },
  mounted() {
    this.scrollToReply();

    this.highlightPre();
  },
  methods: {
    scrollToReply() {
      let hash = window.location.href.split("#")[1];
      if (hash != undefined && "reply-" + this.id == hash) {
        document
          .querySelector("#" + hash)
          .scrollIntoView({ behavior: "smooth" });
        document.querySelector("#" + hash).classList.add("card-highlight");

        setTimeout(() => {
          this.removeHighlighting();
        }, 800);
      }
    },
    highlightPre() {
      document.querySelectorAll("pre").forEach(block => {
        hljs.highlightBlock(block);
      });
    },
    cancel() {
      this.editing = false;
      this.body = this.old_body;
    },
    update() {
      this.$Progress.start();
      axios
        .patch("/replies/" + this.id, {
          body: this.body
        })
        .then(data => {
          this.editing = false;

          this.old_body = this.body;

          Toast.fire({
            icon: "success",
            title: "Your reply has been updated !!"
          });
          this.$Progress.finish();
        })
        .catch(error => {
          Toast.fire({
            icon: "error",
            title: JSON.stringify(error.response.data.errors)
          });
          this.$Progress.fail();
        });
    },
    destroy() {
      this.$Progress.start();
      axios.delete("/replies/" + this.id);

      this.$emit("reply_deleted", this.id);

      Toast.fire({
        icon: "success",
        title: "Your reply has been deleted !!"
      });
      this.$Progress.finish();
    },
    markBestReply() {
      this.$Progress.start();
      axios.post("/replies/" + this.id + "/best");

      window.events.$emit("best-reply-selected", this.id);

      Toast.fire({
        icon: "success",
        title: "Marked as a best reply !!"
      });

      this.$Progress.finish();
    },
    removeHighlighting() {
      let classList = document.querySelector("#reply-" + this.id).classList;
      if (classList.contains("card-highlight")) {
        classList.remove("card-highlight");
        history.pushState(null, null, window.location.href.split("#")[0]);
      }
    }
  }
};
</script>

<style scoped>
.card-highlight {
  box-shadow: 0 0.25rem 0.5rem #01325d !important;
}
</style>