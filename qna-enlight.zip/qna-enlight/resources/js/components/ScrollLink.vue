<template>
  <a :href="href" @click.prevent="scroll">
    <slot />
  </a>
</template>

<script>
export default {
  props: ["href"],
  methods: {
    scroll() {
      document.querySelector(this.href).scrollIntoView({ behavior: "smooth" });
      history.pushState(null, null, this.href);
    }
  }
};
</script>

<style>
</style>