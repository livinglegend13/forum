<template>
  <button
    ref="toTop"
    class="btn btn-primary btn-position"
    @click.prevent="scrollToTop"
    v-if="display"
    v-tooltip="'Scroll to TOP'"
  >
    <i class="fas fa-angle-up"></i>
  </button>
</template>

<script>
export default {
  data() {
    return {
      display: false
    };
  },
  created() {
    window.addEventListener("scroll", this.handleScroll);
  },
  methods: {
    handleScroll() {
      window.scrollY > 100 ? (this.display = true) : (this.display = false);
    },
    scrollToTop() {
      document.querySelector("#app").scrollIntoView({ behavior: "smooth" });
    }
  }
};
</script>

<style scoped>
.btn-position {
  position: fixed;
  bottom: 10px;
  right: 25px;
  z-index: 999;
}
</style>