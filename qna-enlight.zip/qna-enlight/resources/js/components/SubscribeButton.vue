<template>
  <button v-tooltip="title" :class="classes" @click="subscribe">
    <span class="font-weight-bold" v-if="active">&#128525; Subscribed</span>
    <span class="blue font-weight-bold" v-else>Subscribe</span>
  </button>
</template>

<script>
import Toast from "../mixins/SweetAlert";

export default {
  props: {
    issubscribed: {
      type: Boolean,
      default: false
    },
    path: {
      type: String,
      default: location.pathname
    }
  },

  data() {
    return {
      active: this.issubscribed
    };
  },

  computed: {
    classes() {
      return [
        "btn",
        "rounded",
        this.active ? "btn-primary" : "bg-blue",
        "mr-2"
      ];
    },
    title() {
      return this.active
        ? "Unsubscribe from this Thread"
        : "Subscribe to this Thread";
    }
  },

  methods: {
    subscribe() {
      this.$Progress.start();

      axios[this.active ? "delete" : "post"](this.path + "/subscriptions");

      this.active = !this.active;

      Toast.fire({
        icon: "success",
        title: this.active
          ? "Subscribed to this Thread"
          : "Unsubscribed from this Thread"
      });

      this.$Progress.finish();
    }
  }
};
</script>

<style>
</style>