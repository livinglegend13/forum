<template>
  <div class="dropdown" v-if="notifications.length">
    <a
      href="#"
      :data-toggle="active ? 'dropdown show' : 'dropdown'"
      :aria-haspopup="active"
      :aria-expanded="active"
      @click.prevent="toggle"
       v-tooltip="'Notifications'"
    >
      <i class="fa fa-bell"></i>
      <span class="badge-sonar"></span>
      <!-- <span
        class="badge badge-sm badge-pill badge-warning notification"
        v-text="notifications.length"
      ></span>-->
    </a>
    <div
      class="dropdown-menu notifications"
      :class="{show: active}"
      aria-labelledby="dropdownMenuMessage"
    >
      <div class="notifications-header">
        <i class="fa fa-bell"></i>
        Notifications
      </div>
      <div class="dropdown-divider"></div>

      <a
        class="dropdown-item"
        :href="notification.data.link"
        v-for="notification in notifications"
        :key="notification.id"
        :title="notification.data.message"
        @click="markAsRead(notification)"
      >
        <div class="notification-content">
          <div class="icon">
            <i class="fas fa-comment"></i>
          </div>
          <div class="content">
            <div class="notification-detail" v-text="notification.data.message"></div>
            <div class="notification-time" v-text="ago(notification.humanReadableDate)"></div>
          </div>
        </div>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      notifications: false,
      active: false
    };
  },
  created() {
    axios
      .get("/profiles/" + window.App.user.username + "/notifications")
      .then(response => (this.notifications = response.data));
  },
  methods: {
    ago(date) {
      return date + "...";
    },
    toggle() {
      this.active = !this.active;
    },
    markAsRead(notification) {
      axios.delete(
        "/profiles/" +
          window.App.user.username +
          "/notifications/" +
          notification.id
      );
    }
  }
};
</script>

<style scoped>
</style>