<template>
  <div>
    <input :id="id" type="hidden" :name="name" :value="value" />
    <trix-editor ref="trix" :input="id" :placeholder="placeholder"></trix-editor>
  </div>
</template>

<script>
import Trix from "trix";

import "../../sass/_trix.scss";

import Tribute from "tributejs";

import "../../sass/_tribute.scss";

export default {
  props: ["id", "name", "value", "placeholder"],

  watch: {
    value(value) {
      value = value === undefined ? "" : value;
      if (this.$refs.trix.innerHTML !== value) {
        this.$refs.trix.editor.loadHTML(value);
      }
    }
  },
  mounted() {
    this.createEditor();

    this.getReadyFileUpload();
  },
  computed: {
    url() {
      return "/upload-files";
    }
  },
  methods: {
    getReadyFileUpload() {
      addEventListener("trix-attachment-add", event => {
        if (event.attachment.file) {
          this.uploadFileAttachment(event.attachment);
        }
      });
    },
    uploadFileAttachment(attachment) {
      this.uploadFile(attachment.file, setProgress, setAttributes);

      function setProgress(progress) {
        attachment.setUploadProgress(progress);
      }

      function setAttributes(attributes) {
        attributes["content"] = `<img src="${
          attributes["url"]
        }" class="img-fluid">`;

        attachment.setAttributes(attributes);
      }
    },
    uploadFile(file, progressCallback, successCallback) {
      var key = this.createStorageKey(file);

      var formData = this.createFormData(key, file);

      var xhr = new XMLHttpRequest();

      xhr.open("POST", this.url, true);

      xhr.setRequestHeader("X-CSRF-TOKEN", window.token);

      xhr.upload.addEventListener("progress", event => {
        var progress = (event.loaded / event.total) * 100;

        progressCallback(progress);
      });

      xhr.addEventListener("load", event => {
        if (xhr.status == 204) {
          var attributes = {
            url: "/" + key,

            href: "/" + key + "?content-disposition=attachment"
          };

          successCallback(attributes);
        }
      });

      xhr.send(formData);
    },
    createStorageKey(file) {
      var date = new Date();

      var day = date.toISOString().slice(0, 10);

      var name = date.getTime() + "-" + file.name;

      return ["tmp", day, name].join("/");
    },
    createFormData(key, file) {
      var data = new FormData();

      data.append("key", key);

      data.append("Content-Type", file.type);

      data.append("file", file);

      return data;
    },
    createEditor() {
      var tribute = new Tribute({
        values: function(query, callback) {
          if (query) {
            axios.get("/api/users?username=" + query).then(response => {
              callback(response.data.data);
            });
          }
        },
        selectTemplate: function(item) {
          if (typeof item === "undefined") return null;
          if (this.range.isContentEditable(this.current.element)) {
            return (
              '<a href="/profiles/' +
              item.original.value +
              '">@' +
              item.original.value +
              "</a>"
            );
          }
          return "@" + item.original.value;
        },
        menuItemTemplate: function(item) {
          return (
            '<div class="d-flex align-items-center"><img src="' +
            item.original.avatar +
            '" height="20" class="rounded-circle mr-2">' +
            item.original.value +
            "</div>"
          );
        }
      });
      tribute.attach(this.$refs.trix);

      this.$refs.trix.addEventListener("trix-change", e => {
        this.$emit("input", e.target.innerHTML);
      });
    }
  }
};
</script>