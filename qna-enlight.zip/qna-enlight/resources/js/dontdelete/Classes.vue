<template>
  <div class="ml-2">
    <span class="primary">
      <i class="primary" :class="classes"></i>
    </span>
    <span class="secondary">
      <i class="secondary" :class="classes"></i>
    </span>
    <span class="success">
      <i class="success" :class="classes"></i>
    </span>
    <span class="danger">
      <i class="danger" :class="classes"></i>
    </span>
    <span class="warning">
      <i class="warning" :class="classes"></i>
    </span>
    <span class="info">
      <i class="info" :class="classes"></i>
    </span>
    <span class="light">
      <i class="light" :class="classes"></i>
    </span>
    <span class="dark">
      <i class="dark" :class="classes"></i>
    </span>

    <span class="white">
      <i class="white" :class="classes"></i>
    </span>
    <span class="black">
      <i class="black" :class="classes"></i>
    </span>
    <span class="blue">
      <i class="blue" :class="classes"></i>
    </span>
    <span class="indigo">
      <i class="indigo" :class="classes"></i>
    </span>
    <span class="purple">
      <i class="purple" :class="classes"></i>
    </span>
    <span class="pink">
      <i class="pink" :class="classes"></i>
    </span>
    <span class="red">
      <i class="red" :class="classes"></i>
    </span>
    <span class="orange">
      <i class="orange" :class="classes"></i>
    </span>
    <span class="yellow">
      <i class="yellow" :class="classes"></i>
    </span>
    <span class="green">
      <i class="green" :class="classes"></i>
    </span>
    <span class="teal">
      <i class="teal" :class="classes"></i>
    </span>
    <span class="cyan">
      <i class="cyan" :class="classes"></i>
    </span>
    <span class="alert alert-primary"></span>
    <span class="alert alert-secondary"></span>
    <span class="alert alert-success"></span>
    <span class="alert alert-danger"></span>
    <span class="alert alert-warning"></span>
    <span class="alert alert-info"></span>
    <span class="alert alert-light"></span>
    <span class="alert alert-dark"></span>
    <span class="atwho-view atwho-header cur"></span>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>