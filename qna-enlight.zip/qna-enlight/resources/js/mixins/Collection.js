export default {
    data() {
        return {
            items: []
        };
    },
    methods: {

        add(item) {
            this.items.push(item);

            this.$emit("reply_added");
        },

        remove(index) {
            this.items.splice(index, 1);

            this.$emit("reply_deleted");
        }
    }
}