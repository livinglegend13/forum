<script>
import CreateThreadForm from "../components/CreateThreadForm.vue";

export default {
  components: {
    CreateThreadForm
  }
};
</script>

<style>
</style>
