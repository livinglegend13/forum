<script>
import SubscribeButton from "../components/SubscribeButton.vue";

export default {
  components: { SubscribeButton },

  data() {
    return {
      timelineClass: true,
      subscriptionListClass: false
    };
  },
  computed: {
    timelineClasses() {
      return [this.timelineClass ? "active show" : ""];
    },
    subscriptionListClasses() {
      return [this.subscriptionListClass ? "active show" : ""];
    }
  },

  methods: {
    toggle() {
      this.timelineClass = !this.timelineClass;
      this.subscriptionListClass = !this.subscriptionListClass;
    }
  }
};
</script>

<style>
</style>