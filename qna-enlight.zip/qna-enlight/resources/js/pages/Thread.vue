<script>
import Replies from "../components/Replies.vue";

import SubscribeButton from "../components/SubscribeButton.vue";

import LockButton from "../components/LockButton.vue";

import pluralize from "pluralize";

import hljs from "highlightjs";

import "../../sass/_hljs.scss";

import Toast from "../mixins/SweetAlert";

export default {
  props: ["thread"],

  components: { Replies, SubscribeButton, LockButton },

  data() {
    return {
      repliesCount: this.thread.replies_count,
      active: this.thread.locked,
      editing: false,
      title: this.thread.title,
      old_title: this.thread.title,
      body: this.thread.body,
      old_body: this.thread.body
    };
  },

  computed: {
    pluralComment() {
      return pluralize("reply", this.repliesCount, true);
    }
  },

  mounted() {
    document.querySelectorAll("pre").forEach(block => {
      hljs.highlightBlock(block);
    });
  },

  methods: {
    toggleLockStatus() {
      this.active = !this.active;
    },
    update() {
      this.$Progress.start();

      let url = `/threads/${this.thread.channel.slug}/${this.thread.slug}`;

      axios
        .patch(url, {
          title: this.title,
          body: this.body
        })
        .then(() => {
          this.old_title = this.title;

          this.old_body = this.body;

          this.editing = false;

          Toast.fire({
            icon: "success",
            title: "Your thread has been updated !!"
          });

          this.$Progress.finish();
        })
        .catch(error => {
          Toast.fire({
            icon: "error",
            title: JSON.stringify(error.response.data.errors)
          });

          this.$Progress.fail();
        });
    },
    resetForm() {
      this.editing = false;
      this.title = this.old_title;
      this.body = this.old_body;
    }
  }
};
</script>

<style>
</style>