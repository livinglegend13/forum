<div class="row justify-content-center">
    <div class="col-md-11">
        <div class="card border-warning card-warning">
            <div class="card-body flex-column">
                <a class="btn btn-sm mt-1 mr-2 btn-dark" title="Dashboard" href="{{ route('admin.dashboard') }}">
                    <i class="fas fa-tachometer-alt"></i>
                    {{ __('Dashboard') }}
                </a>
                <a class="btn btn-sm mt-1 mr-2 btn-warning" title="Channels" href="{{ route('admin.channels.index')}}">
                    <i class="fas fa-podcast"></i>
                    {{ __('Channels') }}
                </a>
                <a class="btn btn-sm mt-1 mr-2 btn-warning" title="Ticket Categories"
                    href="{{ route('admin.ticket.categories.index')}}">
                    <i class="fas fa-ticket-alt"></i>
                    {{ __('Ticket Categories') }}
                </a>
                <a class="btn btn-sm mt-1 mr-2 btn-warning" title="Settings" href="{{ route('admin.settings.index')}}">
                    <i class="fas fa-cogs"></i>
                    {{ __('Settings') }}
                </a>
                <a class="btn btn-sm mt-1 mr-2 btn-warning" title="APISettings"
                    href="{{ route('admin.api-settings.index')}}">
                    <i class="fas fa-cog"></i>
                    {{ __('Api Settings') }}
                </a>
                <a class="btn btn-sm mt-1 mr-2 btn-warning" title="Google Adsense"
                    href="{{ route('admin.google-adsense.index')}}">
                    <i class="fab fa-google"></i>
                    {{ __('Google Adsense') }}
                </a>
            </div>
        </div>
    </div>
</div>