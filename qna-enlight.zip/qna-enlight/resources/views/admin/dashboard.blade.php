@extends('layouts.app')

@section('content')
<div class="container-fluid">

    @include('admin._admin_nav')

    <div class="row justify-content-center">
        <div class="col-md-11 mt-4 mb-4">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title h1">{{ $usersCount }}</h4>
                            <p class="card-text font-weight-bold">
                                <span class="h2 text-capitalize">
                                    {{Str::plural('user', $usersCount)}}
                                </span>
                                <span class="text-muted">{{ __('so far..') }}</span></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title h1">{{ $threadsCount }}</h4>
                            <p class="card-text font-weight-bold">
                                <span class="h2 text-capitalize">
                                    {{Str::plural('thread', $threadsCount)}}
                                </span>
                                <span class="text-muted">{{ __('so far..') }}</span></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title h1">{{ $repliesCount }}</h4>
                            <p class="card-text font-weight-bold">
                                <span class="h2 text-capitalize">
                                    {{Str::plural('reply', $repliesCount)}}
                                </span>
                                <span class="text-muted">{{ __('so far..') }}</span></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <span class="float-right">
                                {{ __('Monthly Overview') }}
                            </span>
                        </div>
                        <div class="card-body">
                            <counts-graph url="{{ route('admin.api.counts-report') }}">
                            </counts-graph>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
