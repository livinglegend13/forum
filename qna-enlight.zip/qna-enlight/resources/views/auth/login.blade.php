@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-3">
                <img class="img-fluid mr-2" src="{{ asset('logo.png') }}"
                    alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}"
                    >
                <h1 class="font-weight-bold text-uppercase">
                    {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                </h1>
            </div>
            <form method="POST" action="{{ route('login') }}">
                @csrf

                <div class="form-group row justify-content-center ">

                    <div class="col-md-6">
                        <input id="email" type="text" class="form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ old('email') }}" required autocomplete="email"
                            placeholder="E-Mail Address or Username" autofocus>

                        @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group row justify-content-center ">

                    <div class="col-md-6">
                        <input id="password" type="password"
                            class="form-control @error('password') is-invalid @enderror" name="password" required
                            autocomplete="current-password" placeholder="Password">

                        @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>

                <div class="form-group row justify-content-center ">
                    <div class="col-md-6 d-flex align-items-center">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                {{ old('remember') ? 'checked' : '' }}>

                            <label class="form-check-label" for="remember">
                                {{ __('Remember Me') }}
                            </label>
                        </div>

                        @if (Route::has('password.request'))
                        <a class="btn btn-sm btn-link text-decoration-none ml-auto" title="forgot your password"
                            href="{{ route('password.request') }}">
                            {{ __('Forgot Your Password?') }}
                        </a>
                        @endif
                    </div>
                </div>

                <div class="form-group row justify-content-center mb-0">
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary w-100">
                            {{ __('Sign in to your account') }}
                        </button>
                    </div>
                </div>
            </form>

            @if (Route::has('register'))
            <div class="form-group row justify-content-center mt-3">
                <div class="col-md-6 text-center">
                    {{ __("Don't have an account?") }}
                    <a title="Register" class="w-100 text-decoration-none" href="{{ route('register') }}">
                        {{ __('Sign Up') }}
                    </a>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection