@extends('layouts.app')@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-3">
                <img class="img-fluid mr-2" src="{{ asset('logo.png') }}"
                    alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}"
                  >
                <h1 class="font-weight-bold text-uppercase">
                    {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                </h1>
            </div>
            <form method="POST" action="{{ route('register') }}">
                @csrf 
                <div class="form-group row justify-content-center">
                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                            name="name" value="{{ old('name') }}" required autocomplete="name"
                            placeholder="What's your name?" autofocus> @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>
                <div class="form-group row justify-content-center">
                    <div class="col-md-6">
                        <input id="username" type="text" class="form-control @error('username') is-invalid @enderror"
                            name="username" value="{{ old('username') }}" required placeholder="What's your nickname?"
                            autocomplete="username" autofocus> @error('username')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>
                <div class="form-group row justify-content-center">
                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                            name="email" value="{{ old('email') }}" placeholder="Your E-Mail address, We won't spam."
                            required autocomplete="email"> @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>
                <div class="form-group row justify-content-center">
                    <div class="col-md-6">
                        <input id="password" type="password"
                            class="form-control @error('password') is-invalid @enderror" name="password" required
                            autocomplete="new-password" placeholder="Secure account with strong password">
                        @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>
                <div class="form-group row justify-content-center">
                    <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control " name="password_confirmation"
                            required autocomplete="new-password" placeholder="Ensure you typed right">
                    </div>
                </div>
                <div class="form-group row justify-content-center mb-0">
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary w-100">
                            {{ __('Create your') }} <span
                                class="text-uppercase">{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}</span>
                            {{ __('account') }}
                        </button>
                    </div>
                </div>
            </form>
            <div class="form-group row justify-content-center mt-3">
                <div class="col-md-6 text-center">
                    {{ __('Already have an account?') }}
                    <a title="Login" class="w-100 text-decoration-none" href="{{ route('login') }}">
                        {{ __('Sign in') }}
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection