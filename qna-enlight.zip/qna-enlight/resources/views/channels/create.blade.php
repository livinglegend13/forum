@extends('layouts.app')

@section('content')
<div class="container-fluid">

    @include('admin._admin_nav')

    <div class="row justify-content-center">
        <div class="col-md-11 mt-4 mb-4">
            <div class="card border-warning card-warning">
                <div class="card-header d-flex align-items-center">
                    <h4 class="card-title font-weight">{{ __('Create Channel') }}</h4>
                </div>
                <form action="{{ route('admin.channels.store') }}" method="post">
                    @csrf
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name:') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                                    name="name" value="{{ old('name') }}" required autofocus>

                                @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="font_awesome_classes" class="col-md-4 col-form-label text-md-right">
                                {{ __('Font Awesome 5 Classes:') }} <a title="Fontawesome 5" href="//fontawesome.com/"
                                    tabIndex="-1" target="_blank">{{ __('here..') }}</a>
                            </label>
                            <div class="col-md-6">
                                <input id="font_awesome_classes" type="text"
                                    class="form-control @error('font_awesome_classes') is-invalid @enderror"
                                    name="font_awesome_classes" value="{{ old('font_awesome_classes') }}" required>

                                @error('font_awesome_classes')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <p class="font-weight-bold text-md-center">
                            {{ __('Ex. fab fa-laravel') }} <span class="red">{{ __('red') }}</span> {{ __('for') }} <i
                                class="fab fa-laravel red"></i>
                            ({{ __('Available Colors:') }} &nbsp;
                            <span class="blue">{{ __('blue') }}</span>, &nbsp;
                            <span class="indigo">{{ __('indigo') }}</span>, &nbsp;
                            <span class="purple">{{ __('purple') }}</span>, &nbsp;
                            <span class="pink">{{ __('pink') }}</span>, &nbsp;
                            <span class="red">{{ __('red') }}</span>, &nbsp;
                            <span class="orange">{{ __('orange') }}</span>, &nbsp;
                            <span class="yellow">{{ __('yellow') }}</span>, &nbsp;
                            <span class="green">{{ __('green') }}</span>, &nbsp;
                            <span class="teal">{{ __('teal') }}</span>, &nbsp;
                            <span class="cyan">{{ __('cyan') }}</span>.
                            ).
                        </p>
                    </div>
                    <div class="card-footer text-center">
                        <button type="submit" class="btn btn-primary">{{ __('Save') }}</button>
                        <a href="{{ route('admin.channels.index')}}" title="back"
                            class="btn btn-sm mr-2">{{ __('Back') }}</a>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
@endsection