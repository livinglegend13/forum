@extends('layouts.app')

@section('content')
<div class="container-fluid">

    @include('admin._admin_nav')

    <div class="row justify-content-center">
        <div class="col-md-11 mt-4 mb-4">
            <div class="card border-warning card-warning">
                <div class="card-header d-flex align-items-center">
                    <h4 class="font-weight">
                        {{ __('All channels') }}
                    </h4>
                    <div class="ml-auto">
                        <a title="Create" href="{{ route('admin.channels.create') }}" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus"></i>
                            {{ __('Create') }}
                        </a>
                    </div>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">{{ __('Name') }}</th>
                                <th>{{ __('Font Awesome 5 classes') }}</th>
                                <th class="text-center">{{ __('Actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($channels as $channel)
                            <tr>
                                <th scope="row">{{ $channel->name }}</th>
                                <th scope="row">
                                    <i class="{{ $channel->font_awesome_classes }}"></i>
                                    {{ $channel->font_awesome_classes }}
                                </th>
                                <th class="text-center">
                                    <div class="d-inline">
                                        <a href="{{ route('admin.channels.edit', $channel) }}" title="Edit Channel"
                                            class="btn btn-sm btn-outline-primary mr-4">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <div class="d-inline">
                                            <a href=""
                                                onclick="event.preventDefault();
                                                     document.getElementById('channel-{{ $channel->slug }}-form').submit();"
                                                title="Delete Channel" class="btn btn-sm btn-outline-danger">
                                                <i class="fa fa-times-circle"></i>
                                            </a>
                                            <form id="channel-{{ $channel->slug }}-form"
                                                action="{{ route('admin.channels.destroy', $channel) }}" method="POST"
                                                style="display: none;">
                                                @csrf
                                                @method('DELETE')
                                            </form>
                                        </div>
                                    </div>
                                </th>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection