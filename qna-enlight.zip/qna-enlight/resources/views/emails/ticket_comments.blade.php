<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Suppor Ticket</title>
</head>

<body>
    <p>
        {{ $comment->body }}
    </p>

    ---
    <p>Replied by: {{ $user->name }}</p>

    <p>Title: {{ $ticket->title }}</p>
    <p>Status: {{ $ticket->status }}</p>

    <p>
        You can view the ticket at any time at
        <a href="{{ route('tickets.show', $ticket) }}">
            here
        </a>
    </p>

</body>

</html>