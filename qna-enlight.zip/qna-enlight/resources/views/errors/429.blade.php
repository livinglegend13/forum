@extends('layouts.app')

@section('title')
{{ __('404') }}
@endsection

@section('description')
{{ __('I think you are lost, try searching by pressing ESC key.') }}
@endsection

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form method="GET" action="{{ route('threads.search.index') }}" class="mt-3">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Try searching anything here..."
                        autocomplete="off">
                </div>
            </form>
            <img class="img-fluid mt-3" src="{{ asset('svgs/429.svg') }}" alt="429 Too Many Requests">
        </div>
    </div>
</div>
@endsection
