@extends('layouts.app')

@section('content')
<div class="container-fluid">

    @include('admin._admin_nav')

    <div class="row justify-content-center">
        <div class="col-md-11 mt-4 mb-4">
            <div class="card border-warning card-warning">
                <div class="card-header d-flex align-items-center">
                    <h4 class="font-weight">
                        {{ __('Google Adsenses') }}
                    </h4>
                    <h5 class="ml-2 text-danger">{{ __('No data is sanitized be aware of what you add here!!')}}</h5>
                </div>
                <div class="card-body table-responsive">
                    <div class="row justify-content-center">
                        <div class="col-md-4">
                            <form action="{{ route('admin.google-adsense.postGoogleAdsenseSquare')}}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label for="sitename">{{ __('Square Ads:') }}</label>
                                    <textarea name="square" id="square" class="form-control"
                                        rows="10">{{ ($settings->where('key', 'square-ads')->pluck('value')->first() ?? '')}}</textarea>
                                    @error('square')
                                    <small class="red">
                                        <strong>{{ $message }}</strong>
                                    </small>
                                    @enderror
                                </div>
                                <button class="btn btn-sm bg-blue blue font-weight-bold"
                                    type="submit">{{ __('Update') }}</button>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <form action="{{ route('admin.google-adsense.postGoogleAdsenseHorizontal')}}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label for="sitename">{{ __('Horizontal Ads:') }}</label>
                                    <textarea name="horizontal" id="horizontal" class="form-control"
                                        rows="10">{{ ($settings->where('key', 'horizontal-ads')->pluck('value')->first() ?? '')}}</textarea>
                                    @error('horizontal')
                                    <small class="red">
                                        <strong>{{ $message }}</strong>
                                    </small>
                                    @enderror
                                </div>
                                <button class="btn btn-sm bg-blue blue font-weight-bold"
                                    type="submit">{{ __('Update') }}</button>
                            </form>
                        </div>
                        <div class="col-md-4">
                            <form action="{{ route('admin.google-adsense.postGoogleAdsenseVertical')}}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label for="sitename">{{ __('Vertical Ads:') }}</label>
                                    <textarea name="vertical" id="vertical" class="form-control"
                                        rows="10">{{ ($settings->where('key', 'vertical-ads')->pluck('value')->first() ?? '')}}</textarea>
                                    @error('vertical')
                                    <small class="red">
                                        <strong>{{ $message }}</strong>
                                    </small>
                                    @enderror
                                </div>
                                <button class="btn btn-sm bg-blue blue font-weight-bold"
                                    type="submit">{{ __('Update') }}</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection