<div class="container-fluid mb-5">
    <div class="row justify-content-center">
        <div class="col-12 d-flex align-items-center">
            <hamburger></hamburger>
            <nav aria-label="breadcrumb" class="d-none d-md-block">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/') }}">
                            <i class="fas fa-home"></i> {{ __('Home') }}
                        </a>
                    </li>
                    <?php $segments = ''; ?>
                    @foreach(Request::segments() as $segment)
                    <?php $segments .= '/'.$segment; ?>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="{{ $segments }}" class="text-capitalize">{{ str_replace('-', ' ', $segment) }}</a>
                    </li>
                    @endforeach
                </ol>
            </nav>
            <a v-tooltip="'Create a Thread'" href="{{ route('threads.create') }}"
                class="btn btn-sm btn-primary text-wrap text-white ml-auto d-md-none">
                {{ __('Ask a Question') }}
            </a>
        </div>
    </div>
</div>
