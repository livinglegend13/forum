<footer class="d-flex flex-column flex-md-row justify-content-center mt-5 p-4 border-top">
    <div class="px-4 pt-4 text-center">
        <p class="mb-2">
            &copy; {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
            2018-{{ \Carbon\Carbon::now()->year}}. {{ __('All rights reserved') }}. &nbsp;
            <a class="text-uppercase" href="{{ route('sitemap.xml') }}" v-tooltip="'Sitemap.xml'" target="_blank">
                <i class="fas fa-sitemap"></i>
            </a>
        </p>
        <p class="mb-2">
            {{ __('Designed and Developed with') }}
            <i class="fas fa-heart heartbeat mx-2"></i>
            {{ __('by') }}
            <br class="d-md-none d-sm-block">
            <a v-tooltip="'Enlight Technologies is a leading information technology company providing end-to-end services.'" class="px-2" href="//www.enlighttechnologies.in"
                target="_blank">Enlight
                Technologies</a>
        </p>
        <p class="mb-2">
            <small>
                <a class="text-uppercase font-weight-bold" href="{{ url('/cookie-policy') }}" v-tooltip="'Cookie Policy'"
                    target="_blank">
                    {{ __('Cookie') }}
                </a>
                /
                <a class="text-uppercase font-weight-bold" href="{{ url('/privacy-policy') }}" v-tooltip="'Privacy Policy'"
                    target="_blank">
                    {{ __('Privacy Policy') }}
                </a>

            </small>
        </p>
    </div>
    <div class="px-4 pt-0 pt-md-4 pb-4 text-center">

        <a href="{{ ($settings->where('key', 'facebook_link')->pluck('value')->first() ?? '#') }}"
            v-tooltip="'{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight')}} Facebook Link'"
            target="_blank" class="text-decoratione-none m-2 shine h3">
            <i class="fab fa-facebook"></i>
        </a>

        <a href="{{ ($settings->where('key', 'whatsapp_link')->pluck('value')->first() ?? '#') }}"
            v-tooltip="'{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight')}} Whatsapp Link'"
            target="_blank" class="text-decoratione-none m-2 shine h3">
            <i class="fab fa-whatsapp"></i>
        </a>

        <a href="{{ ($settings->where('key', 'instagram_link')->pluck('value')->first() ?? '#') }}"
            v-tooltip="'{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight')}} Instagram Link'"
            target="_blank" class="text-decoratione-none m-2 shine h3">
            <i class="fab fa-instagram"></i>
        </a>

        <a href="{{ ($settings->where('key', 'twitter_link')->pluck('value')->first() ?? '#') }}"
            v-tooltip="'{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight')}} Twitter Link'"
            target="_blank" class="text-decoratione-none m-2 shine h3">
            <i class="fab fa-twitter"></i>
        </a>

    </div>
</footer>