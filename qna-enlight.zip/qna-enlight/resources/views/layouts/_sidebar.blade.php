<sidebar inline-template>
    <nav id="sidebar" class="sidebar-wrapper border-right" style="border-top: 5px solid #1a0dab;">
        <div class="sidebar-content">
            <!-- sidebar-brand  -->
            <div class="sidebar-item sidebar-brand">
                <a class="navbar-brand" href="{{ url('/') }}"
                    title="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}">
                    <img src="{{ asset('logo.png') }}"
                        alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}"
                        height="32" class="mr-2">
                    {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                </a>
            </div>
            <!-- sidebar-header  -->
            @guest
            <div class="sidebar-item sidebar-menu">
                <ul>
                    <li>
                        <a title="Login" href="{{ route('login') }}">
                            <i class="fas fa-users-cog"></i>
                            <span class="menu-text">{{ __('Login') }}</span>
                        </a>
                    </li>
                    @if (Route::has('register'))
                    <li>
                        <a title="Register" href="{{ route('register') }}">
                            <i class="fas fa-user-plus"></i>
                            <span class="menu-text">{{ __('Register') }}</span>
                        </a>
                    </li>
                    @endif
                </ul>
            </div>
            @else
            <div class="sidebar-item sidebar-header d-flex flex-nowrap">
                <div class="user-pic">
                    <a href="{{ route('profiles.show', \Illuminate\Support\Facades\Auth::user())}}" alt="{{ \Illuminate\Support\Facades\Auth::user()->name }}">
                        <img class="img-responsive rounded-circle" src="{{ \Illuminate\Support\Facades\Auth::user()->avatar }}"
                            alt="{{ \Illuminate\Support\Facades\Auth::user()->name }}">
                    </a>
                </div>
                <div class="user-info">
                    <span class="user-name text-capitalize font-weight-bold">
                        <a href="{{ route('profiles.show', \Illuminate\Support\Facades\Auth::user())}}" alt="{{ \Illuminate\Support\Facades\Auth::user()->name }}">
                            {{ \Illuminate\Support\Facades\Auth::user()->name }}
                        </a>
                    </span>
                    <span class="user-role">{{ \Illuminate\Support\Facades\Auth::user()->hasRole('admin') ? 'Administrator' : 'User'  }}</span>
                    <span class="user-status">
                        <i class="fa fa-circle"></i>
                        <span>{{ __('Online') }}</span>
                    </span>
                </div>
            </div>
            @endguest
            <!-- sidebar-search  -->
            <form method="GET" action="{{ route('threads.search.index') }}" class="d-inline w-50 order-md-1">
                <div class="sidebar-item sidebar-search">
                    <div class="input-group">
                        <input type="text" name="q" id="q" class="form-control search-menu"
                            placeholder="Press 'Esc' to focus" autocomplete="off">
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </form>

            <!-- sidebar-menu  -->
            <div class="sidebar-item sidebar-menu">
                <ul>
                    <li class="header-menu">
                        <span>{{ __('General') }}</span>
                    </li>
                    <li>
                        <a title="Ask Question" href="{{ route('threads.create') }}">
                            <i class="fas fa-question"></i>
                            <span class="menu-text">{{ __('Ask a Question') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="Open Ticket" href="{{ route('tickets.index') }}">
                            <i class="fas fa-ticket-alt"></i>
                            <span class="menu-text">{{ __('Open Ticket') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="All Threads" href="{{ route('threads.index') }}">
                            <i class="fas fa-layer-group"></i>
                            <span class="menu-text">{{ __('All Threads') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="Popular Threads" href="{{ route('threads.index', ['popular' => 1]) }}">
                            <i class="fas fa-star"></i> <span class="menu-text">{{ __('Popular Threads') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="Unanswered Threads" href="{{ route('threads.index', ['unanswered' => 1]) }}">
                            <i class="fas fa-comment-slash"></i> <span
                                class="menu-text">{{ __('Unanswered Threads') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="Unsolved Threads" href="{{ route('threads.index', ['unsolved' => 1]) }}">
                            <i class="fas fa-times-circle"></i> <span class="menu-text">{{ __('Unsolved') }}</span>
                        </a>
                    </li>
                    <li>
                        <a title="Solved Threads" href="{{ route('threads.index', ['solved' => 1]) }}">
                            <i class="fas fa-check-circle"></i> <span class="menu-text">{{ __('Solved') }}</span>
                        </a>
                    </li>
                    @auth
                    <li>
                        <a title="My Threads" href="{{ route('threads.index', ['by' => auth()->user()->username ]) }}">
                            <i class="fas fa-user"></i> <span class="menu-text">{{ __('My Threads') }}</span>
                        </a>
                    </li>
                    @endauth
                    <li>
                        <a title="Leaderboard" href="{{ route('profiles.index') }}">
                            <i class="fas fa-trophy"></i> <span class="menu-text">{{ __('Leaderboard') }}</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- sidebar-menu  -->
        </div>
        <!-- sidebar-footer  -->
        @auth
        <div class="sidebar-footer">
            <user-notifications></user-notifications>

            <div class="dropdown" :class="{ show: userMenu }">
                <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                    @click.prevent="userMenu = !userMenu" v-tooltip="'Settings'">
                    <i class="fa fa-cog"></i>
                </a>
                <div class="dropdown-menu" :class="{ show: userMenu }" aria-labelledby="dropdownMenuMessage">
                    @if(\Illuminate\Support\Facades\Auth::user()->hasAnyRole(['admin']))
                    <a title="Admin Dashboard" class="dropdown-item" href="{{ route('admin.dashboard') }}">
                        <i class="fas fa-cogs"></i> {{ __('Admin Dashboard') }}
                    </a>
                    @endif

                    <a title="My Profile" class="dropdown-item" href="{{ url('/profiles/'. \Illuminate\Support\Facades\Auth::user()->username) }}">
                        <i class="fas fa-user"></i> {{ __('My Profile') }}
                    </a>
                </div>

                <a v-tooltip="'Logout'" href="#" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                    <i class="fas fa-power-off red"></i>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </div>
        </div>
        @endauth
    </nav>
</sidebar>
