<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    @if ($settings->where('key', 'analytics_key')->pluck('value')->first())
    <script async
        src="//www.googletagmanager.com/gtag/js?id={{$settings->where('key', 'analytics_key')->pluck('value')->first()}}">
    </script>
    <script>
        window.dataLayer = window.dataLayer || [];
             function gtag(){dataLayer.push(arguments);}
             gtag('js', new Date());

             gtag('config', "{{$settings->where('key', 'analytics_key')->pluck('value')->first()}}");
    </script>
    @endif

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta name="description"
        content="@yield('description', ($settings->where('key', 'description')->pluck('value')->first() ?? 'Demo of QNA Enlight app for you ideas. You can be purchase this app at EnlightTechnologies.in.'))">

    <meta name="keywords"
        content="@foreach ( $channels as $channel ) {{$channel->name}} @if(! $loop->last ) , @endif @endforeach">

    <meta name="robots" content="index, follow">

    <meta name="author" content="EnlightTechnologies.in">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title v-pre>@yield('title', ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') )
    </title>

    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
    <link rel="icon" type="image/png" sizes="48x48" href="{{ asset('favicon-48x48.png') }}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">

    <link rel="canonical" href="{{ asset( request()->path() ) }}">

    <link rel='manifest' href="{{ asset('manifest.json') }}">

    <link href="{{ mix('css/app.css') }}" rel="stylesheet">

    <link href="//fonts.googleapis.com/css?family=Montserrat:500&display=swap" rel="stylesheet">

    <link href="{{ asset('css/font-awesome5.css')}}" rel="stylesheet">

    <script type="application/ld+json">
        {
            "@context": "//schema.org",
            "@type": "WebSite",
            "url":  "{{ route('welcome') }}" ,
            "potentialAction": {
                "@type": "SearchAction",
                "target": "{{ route('threads.search.index') .  '?q={search_term_string}' }}",
                "query-input": "required name=search_term_string"
            }
        }
    </script>

    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    @yield('head')
</head>

<body>
    <div id="loader-overlay" class="loader-overlay">
        <div class="loader"></div>
    </div>

    <div id="app" style="border-top: 5px solid #1a0dab;">
        <vue-progress-bar></vue-progress-bar>

        <div id="page-wrapper" class="page-wrapper">

            @include('layouts._sidebar')


            <main class="page-content pt-2">
                <portal-target name="overlay"></portal-target>

                @include('layouts._breadcrumb')

                <div class="container-fluid d-md-none d-sm-block my-4">
                    <div class="d-flex align-items-center">
                        <a href="{{ url()->previous() }}" class="text-decoration-none text-uppercase dark">
                            <i class="fas fa-chevron-left"></i> {{ __('Back') }}
                        </a>
                    </div>
                </div>

                @yield('content')

                @include('layouts._footer')
            </main>

        </div>
        <scroll-to-top></scroll-to-top>

        <cookie></cookie>

    </div>

    <script src="{{ mix('js/manifest.js') }}" defer></script>
    <script src="{{ mix('js/vendor.js') }}" defer></script>
    <script src="{{ mix('js/app.js') }}" defer></script>
    <script>
        window.App = {!! json_encode(['signedIn' => Auth::check(), 'user' => Auth::user()]) !!};
    </script>
    @yield('scripts')

    @if (Session::has('flash'))
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            window.Toast.fire({
                icon: 'success',
                title: "{{ Session::get('flash') }}"
            });
        });
    </script>
    @endif
    @if ($settings->where('key', 'onesignal_key')->pluck('value')->first())
    <script src="//cdn.onesignal.com/sdks/OneSignalSDK.js" async></script>
    <script>
        var OneSignal = window.OneSignal || [];
            OneSignal.push(function() {
           OneSignal.init({
             appId: "{{$settings->where('key', 'onesignal_key')->pluck('value')->first()}}",
    });
    });
    </script>
    @endif

    <script src="{{ asset('service-worker-register.js') }}" defer></script>
</body>

</html>
