@extends('layouts.app')

@section('title')
{{ 'Cookie Policy | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
A cookie is a small piece of text that allows a website to recognize your device and maintain a consistent, cohesive
experience throughout multiple sessions.
@endsection

@section('content')
<div class="text-center mb-3">
    <img class="mr-2" src="{{ asset('logo.png') }}"
        alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}">
    <h1 class="font-weight-bold text-uppercase">
        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
    </h1>
</div>

<main>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        How does {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                        use COOKIES?
                    </h2>
                    <p class="mt-4">
                        A cookie is a small piece of text that allows a website to recognize your device and
                        maintain a consistent, cohesive experience throughout multiple sessions. If you use
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} Network or
                        organizational network like Google
                        all
                        will use cookies
                        to track and monitor some of your activities on and off.
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                        stores and access some data about you, your browsing history, and your usage of
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}.
                    </p>
                    <p class="mt-4">
                        This policy describes how
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} and other
                        third parties (
                        Google Analytics, One Signal ) use
                        cookies
                        both within and without
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} and how
                        you can exercise a
                        greater degree of control over cookies. Please keep in mind that this may alter your
                        experience with our platform, and may limit certain features (including being logged
                        in as a user).
                    </p>
                    <p class="mt-4">
                        <span class="font-weight-bold">General Browsing:</span> We use cookies that are important for
                        certain technical features of our website, like logging into user accounts and
                        implementing fixes and improvements to our platform.
                    </p>
                    <p class="mt-4">
                        These cookies:
                    </p>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Enable behavior in our Products and/or Services that is tailored to the activity
                            or preferences of a person visiting our properties.
                        </li>
                        <li class="list-group-item">
                            Allow users to opt out of certain types of modeling, tailoring, or
                            personalization in our products.
                        </li>
                        <li class="list-group-item">
                            Collect information on our user's preferences in order to create more useful
                            products.
                        </li>
                        <li class="list-group-item">
                            Maintain the regular business operations of our Advertising and Marketing
                            departments (such as one-time pop-ups displays when first visiting a
                            site and to collect impressions and click data).
                        </li>
                        <li class="list-group-item">
                            Help to diagnose and correct downtime, bugs, and errors in our code to ensure
                            that our products are operating efficiently.
                        </li>
                    </ul>
                    <p class="mt-4">
                        <span class="font-weight-bold">Public Q&amp;A Platform:</span> We use cookies that support
                        and enhance our public Q&amp;A platform by enabling important functionality. Such
                        activity includes tracking and attributing activities and badges.
                    </p>
                    <p class="mt-4">
                        These cookies:
                    </p>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Validate the authenticity of persons attempting to gain access to a specific
                            user account.
                        </li>
                        <li class="list-group-item">
                            Enable the core platform of community-generated questions and answers, including
                            diagnosing and resolving issues within our Q&amp;A platform.
                        </li>
                        <li class="list-group-item">
                            Identify individual users to attribute activities and awards.
                        </li>
                    </ul>
                    <p class="mt-4">
                        <span class="font-weight-bold">Advertising:</span> We use cookies to enable advertising with
                        our third-party Partners, which in turn allows us to provide many of our services
                        free of charge.
                    </p>
                    <p class="mt-4">
                        These cookies:
                    </p>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Customize the ad experience for our users, including tailoring and display
                            ads to the technologies a person has previously looked at, the communities a
                            person has visited, and the ads a person has already seen.
                        </li>
                        <li class="list-group-item">
                            Allow direct communication between a 3rd party partner who hosts a promotional
                            event with us, and users who have opted into the promotion.
                        </li>
                        <li class="list-group-item">
                            Allow us to track when a
                            {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} user
                            sees or clicks on
                            an ad or
                            later
                            visits a third-party website or purchases a product on a third-party website.
                        </li>
                        <li class="list-group-item">
                            Collect impressions and click data for internal reporting and product
                            optimization.
                        </li>
                    </ul>
                    <p class="mt-4">
                        <span class="font-weight-bold">Analytics:</span> We use cookies to compile usage activity in
                        order to better cater our Products and Services offerings to you, and to third
                        parties. We DO NOT share identifiable “raw” data with our clients or any third
                        parties, however we do make high-level decisions based on aggregated data about your
                        usage of our Products and Services.
                    </p>
                    <p class="mt-4">
                        These cookies:
                    </p>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Monitor site traffic and behavior flows of users.
                        </li>
                        <li class="list-group-item">
                            Measure the effectiveness of on-site products.
                        </li>
                        <li class="list-group-item">
                            Measure the effectiveness of off-site marketing campaigns and tactics.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        What information is collected on me via COOKIES?
                    </h2>
                    <p class="mt-4">
                        In general, we collect most data from you via form submission. However, there are
                        cases when visiting our site and/or using our platforms in which we may receive
                        certain information through the use of cookies. This data will generally not include
                        personally identifying information about you.
                    </p>
                    <ul class="list-group mt-4">
                        <li class="list-group-item">
                            Unique identification tokens
                        </li>
                        <li class="list-group-item">
                            XSRF-TOKEN for protecting against Cross-site request forgery.
                        </li>
                    </ul>
                    <p class="mt-4 font-weight-bold">Third Party Cookies</p>
                    <p class="mt-4">
                        The use of cookies, the names of cookies and other cookies related
                        technology may change over time and
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} will make
                        all
                        reasonable
                        efforts
                        to notify you by updating our cookies table where material changes occur from
                        time-to-time. Please also note that companies and other organization that sponsor
                        pages on {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                        may use cookies or other technologies to
                        learn more
                        about
                        your interest in their products and services and in some cases to tailor such
                        products and services to you.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        How do i restrict COOKIES?
                    </h2>
                    <p class="mt-4">
                        If you don’t want
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} to use
                        cookies when you visit the
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                        , you can opt-out of certain cookie related processing activities.
                        It is usually possible to stop your browser accepting cookies, or to stop accepting cookies
                        from a particular website
                        If you opt-out
                        of cookies, we (ironically) have to set a cookie to tell us that. Please note that
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }} may not
                        work properly and you may have diminished
                        functionality if
                        you opt-out of certain cookies.
                    </p>
                    <p class="mt-4">
                        If you decide that you do not want cookies to be set on your device by our
                        third-party Partners, you can adjust the settings on your internet browser and
                        choose from the available Cookies setting to best meet your preferences. While
                        setting options it may vary from browser to browser, you can generally choose to reject
                        some or all cookies, or instead to receive a notification when a cookie is being
                        placed on your device. For more information, please refer to the user help
                        information for your browser of choice. Please keep in mind that cookies may be
                        required for certain functionalities, and by blocking these cookies, you may limit
                        your access to certain parts or features of our sites and platforms.
                    </p>
                    <p class="mt-4">
                        Finally, while cookies are set for varying durations on your device, you can
                        manually delete them at any time. However, deleting cookies will not prevent the
                        site from setting further cookies on your device unless you adjust the settings
                        discussed above.
                    </p>
                    <div class="float-right">Last update: November 14, 2019</div>
                </div>
            </div>
        </div>
    </section>
</main>
@endsection