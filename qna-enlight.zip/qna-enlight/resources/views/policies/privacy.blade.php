@extends('layouts.app')

@section('title')
{{ 'Privacy Policy | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
Our privacy policy for {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}.
@endsection

@section('content')
<div class="text-center mb-3">
    <img class="mr-2" src="{{ asset('logo.png') }}"
        alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}">
    <h1 class="font-weight-bold text-uppercase">
        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
    </h1>
</div>

<main>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Introduction
                    </h2>
                    <p class="mt-4">
                        The {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                        is a set
                        of
                        related Internet sites and other applications for questions and answers, owned and operated by
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        welcomes
                        you
                        to the Network, the niche community of developers for @foreach ( $channels as $channel )
                        {{$channel->name}} @if(! $loop->last ) , @endif @endforeach and invites you to participate
                        in
                        the community by sharing knowledge with your peers and colleagues. We have the modest goal of
                        making
                        the internet a better place, and as such are committed to your privacy. This privacy policy
                        describes what information we collect on our Network and in the use of our Products and
                        Services,
                        how we use that information, and what options we offer you to control your personal information.
                    </p>
                    <p class="mt-4">
                        We will need to process your personal information in order to offer the Network, and to offer
                        you
                        our Products and Services. By using the Network or (whether via the public or private Network,
                        collectively the “Terms of Service”), or purchasing our Products or Services, you confirm that
                        you
                        have read and understood the Terms of Service and this privacy policy (“Privacy Policy”)
                        including
                        how and why we use your information and that your use of the Network is subject to the
                        applicable
                        Terms of Service and this Privacy Policy. If you do not want us to collect or process your
                        personal
                        information as described herein, you have several choices including limiting the information we
                        collect on you, or not using the Network, or our Products and Services.
                    </p>
                    <p class="mt-4">
                        By using the Network or purchasing our Products and Services, you acknowledge that
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        will use your information in the India, the United States, the United Kingdom, and Germany as
                        well as any
                        other
                        country where
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        operates. This privacy policy has been updated to comply with
                        the
                        EU’s
                        General Data Protection Regulation (GDPR) and this policy describes how we protect personal
                        information that is transferred outside of the EU. Please be aware that the privacy laws and
                        standards in certain countries, including the rights of authorities to access your personal
                        information, may differ from those that apply in the country in which you reside. We will
                        transfer
                        personal information only to countries to which we are permitted by law to transfer personal
                        information and we will continue to ensure that your personal information is appropriately
                        safeguarded.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        How we collect information of you
                    </h2>
                    <p class="mt-4">
                        In the course of providing you access to the Network, as well as Products and Services,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        collects and receives personal information in a few ways. Often, you can choose
                        what
                        information to provide, but sometimes we require personal information from you to carry out
                        certain
                        activities such as account verification. This section details the ways in which we collect
                        information from you and how that information is received.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Account Registration
                    </h3>
                    <p class="mt-4">
                        Although the Network provides for anonymous and pseudonymous participation, in some instances in
                        order to use certain Products or Services, we require account registration. This requires a name
                        associated with your account, an email address at which we can contact you, and in some cases,
                        additional information including, a contact address, a billing address, and a password to help
                        secure your personal information.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Profile Information
                    </h3>
                    <p class="mt-4">
                        When completing a public “profile” be it for use of the Network or our Products and Services, we
                        may
                        require you to share certain personally identifying information or sensitive information in
                        required
                        and optional profile fields. The name associated with your account, which you may review and
                        change
                        in your account settings, as well as reputation points are publicly displayed and connected to
                        your
                        activity on the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network and via certain Products and Services.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Information Collected Automatically
                    </h3>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        receives and records information from your browser or mobile device when
                        you
                        visit
                        the Network or use the Apps, such as your Internet Protocol (IP) address or unique device
                        identifier. Cookies and data about which pages you visit on our Network allow us to operate and
                        optimize the Products and Services we provide to you. This information is stored in secure logs
                        and
                        is collected automatically. We may combine this browser information with other information we
                        collect about you. This information is used to keep the Products and Services secure, analyze
                        and
                        understand how our Products and Services are used, optimize such usage, provide advertising
                        across
                        the Network as well as certain Products and Services to personalize your experience, and to help
                        connect you with potential job opportunities in the case of our recruiting Products and
                        Services.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Location Information
                    </h3>
                    <p class="mt-4">
                        When you use the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network, and certain of our Products and Services, we
                        collect
                        location information about you including your IP address, your location, browser information,
                        and
                        how you came to the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network. This is the case for individuals who have
                        registered
                        for
                        an account, and non-members who engage with the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network by visiting our
                        website(s)
                        but who have not completed an account registration. This information is collected for various
                        purposes, including advertising, analytics and to serve content as it relates to certain
                        Products or
                        Services (e.g., Talent), as well as to provide you with localized content, recommendations, and
                        marketing. You may revoke our permission to collect some of this data, including your location
                        and
                        browser information through your Account Settings, but this may limit functionality in some
                        cases.
                        Certain location information we collect is required for security and site functionality. We
                        share
                        this information with certain third-parties (e.g., talent recruiters, payment processors, and
                        advertising providers) in order to provide you with our Products and Services.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Information Shared with Third Parties
                    </h3>
                    <p class="mt-4">
                        We may share personal information with third parties who provide services to
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }},
                        such as
                        payment processors, email delivery services, and advertising providers. Additionally, to improve
                        user experience, we offer single sign-on solutions for account login and these third parties
                        (including Facebook and Google) may receive information from these services when you elect to
                        use
                        them. When
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        shares your personal information and other collected information
                        with
                        third party service providers, we require that they use your information only for the purpose of
                        providing services to us and that their terms are consistent with this privacy policy.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Advertising and Marketing Partners
                    </h3>
                    <p class="mt-4">
                        When you register for an account, and when you interact with
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }},
                        we and
                        authorized
                        third
                        parties place cookies on you and your account activity as described in more detail within our <a
                            href="/cookie-policy">Cookies Policy</a>. We use this information to serve you certain
                        advertising content. Similarly, we market our Products and Services to you and communicate
                        important
                        information and product opportunities to you. If you do not wish to receive direct marketing
                        communications from us, you can tell us and remove yourself from our marketing communications
                        via
                        the unsubscribe and opt out options in our email communications and your Account Settings. If
                        you do
                        not wish to receive advertising promotions, you may contact us, but you should know that by
                        doing so, you may reduce some functionality and you may
                        not
                        have access to certain features within our Products and Services (e.g., job recommendations on
                        our
                        Talent platform).
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Analytics Information
                    </h3>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        uses data analytics to ensure site functionality and to optimize our
                        Product and
                        Service offerings to you. We use web browser and mobile analytics to allow us to understand
                        Network
                        and Apps functionality. In doing so, we record information including, for example how often you
                        visit the Network, how often you contribute content, Network and Apps performance data, errors
                        and
                        debugging information, and the type of activity you engage in while on the Network or in your
                        use of
                        our Products and Services. We may on occasion share this information with third parties for
                        research
                        or product and services optimization.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Billing Information
                    </h3>
                    <p class="mt-4">
                        For Products and Services requiring payment, we collect a billing name, phone number, and email
                        address. We also collect a billing and shipping address for invoicing purposes. If you elect to
                        pay
                        by credit/debit card,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        may engage a third party to securely process your
                        payment. All
                        payment processing is done through a PCI DSS compliant third party. If customers are paying by a
                        credit/debit card, their card details are vaulted through a third party payment gateway.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        will store an encrypted token along with the last four digits of the credit/debit card and the
                        expiration
                        month and year of the card and will not store or retain any other billing information about you.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        What information we collect on you
                    </h2>
                    <p class="mt-4">
                        This section describes in further detail the information we collect on you and how we use that
                        information broken down by our Products and Services offerings.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Public Network (Questions and Answers Content)
                    </h3>
                    <p class="mt-4">
                        The Public Question and Answer Network (“public Network”) allows individual users to engage in a
                        community to share their knowledge and expertise, and to acquire knowledge and expertise. It is
                        community-moderated, and the content in the public Network is . . . public. To provide an
                        optimal
                        community experience, and to ensure Network security, we collect certain personal information.
                    </p>
                    <p class="mt-4">
                        We collect information such as your username, password, email address, IP address (collected at
                        each
                        site visit). This information is also used to identify individual users to the public Network
                        and to
                        award activities and attribute them to you. Your username and additional content you provide
                        including your profile picture, question and answer content, and your reputation are visible
                        publicly. Other limited information is visible to moderators, who have elevated access
                        privileges,
                        and may access content including your posts. For more information about moderators and their
                        role in
                        the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network.
                        In addition, when you choose to use certain features such as our support features, we
                        collect a record of your communications with us and other third parties that are accessible to
                        support
                        participants and certain authorized third parties. Other account information and usage
                        information
                        including your IP address and browser data may be used for diagnosis, security and Product and
                        Service optimization.
                    </p>
                    <p class="mt-4">
                        Please be aware that when using the Public Question and Answer Network, you cannot revoke
                        permission
                        for
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }} to
                        publish and to allow others to have derivative rights to such public
                        content
                        once it is made public. The content you contribute on the public network is public, in
                        perpetuity,
                        and
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        loses direct control over such content when it is published on the open
                        internet.
                        This also means that if you post personal information about yourself, you do so at your own
                        risk,
                        including the risk of abandoning any privacy rights you had in such information.
                    </p>
                    <p class="mt-4">
                        Additionally, from time to time,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        makes such public content available via
                        compilation
                        via the Creative Commons Data Dump and by providing public content to the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network,
                        you should be aware that such content, once public, cannot often be removed from public view
                        even if
                        it is removed from the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network and our servers.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Talent and Jobs
                    </h3>
                    <p class="mt-4">
                        The
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Talent platform allows for companies looking to hire and those seeking
                        job
                        opportunities to connect with each other and to engage in new employment opportunities. To
                        optimize
                        the recruitment experience, and to connect job seekers with jobs, we collect certain personal
                        information on you the account holder (or account unregistered job seeker), and on the company
                        and
                        its authorized recruiters.
                    </p>
                    <p class="mt-4">
                        Whether you are a recruiter seeking to hire on our Talent platform, or a registered account
                        holder
                        using our Jobs platform while seeking employment opportunities, we collect certain account
                        registration information on you. For job seekers on the Jobs platform, we collect your name,
                        location, email and resume (where applicable) along with certain optional information including
                        your
                        phone number and a cover letter (where applicable). For company authorized users using our
                        Talent
                        Platform to recruit developers, we collect certain account registration information on you
                        including
                        your name, email, and affiliated company. For job seekers who chose to participate in our Jobs
                        platform your public profile can be observed and collected by those looking to hire you. For
                        company
                        authorized users your profiles are visible to authorized users of the company account and your
                        contact details are visible to job seekers via direct messaging on the Talent platform. The
                        information we collect on you as a job seeker is also used by
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }} to
                        customize
                        job
                        recommendations. You may additionally opt-in to specific features that rely on personal
                        information.
                        For example, you may elect to provide personal information in your Developer Story which
                        collects
                        certain CV-like information and achievements including employment history which may be used for
                        recruiting purposes.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Advertising Products
                    </h3>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        partners with third parties to display advertisements on our public Network
                        and
                        within our Talent Platform. These partnerships provide third parties access to the developer
                        community to promote themselves or services and to provide you with visibility into companies
                        and
                        third parties seeking to recruit you for employment opportunities, and for other purposes. In
                        providing this opportunity,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        and its third party partners may collect and
                        use your
                        personal information to tailor your advertising experience to suit your interests, skills, as
                        well
                        as to monitor your account activity in order to optimize our Products and Services.
                    </p>
                    <p class="mt-4">
                        We seek to limit what information advertisers and similar third parties have access to, as well
                        as
                        to ensure that your user experience on the public and private
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network is
                        not
                        overwhelmed by advertising initiatives. However, our advertising products and services require
                        us to
                        collect certain personal and non-personal information on you, which includes:
                    </p>
                    <ul class="list-group mt-4">
                        <li class="list-group-item">
                            Data from advertising technologies like cookies, web beacons, pixels, ad tags, and
                            browser/device identifiers
                        </li>
                        <li class="list-group-item">
                            Information you have provided to us directly including profile information, your Developer
                            Story, and in limited instances your job history
                        </li>
                        <li class="list-group-item">
                            Usage analytics including your visits to the Network, browsing and search history
                        </li>
                        <li class="list-group-item">
                            Information from our advertising partners (e.g., device type and location)
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Cookies
                    </h2>
                    <p class="mt-4">
                        In order to provide the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network along with the Products and Services
                        described in
                        this policy, we may place cookies on you as well as partner with third parties including
                        advertising
                        partners, who may use cookies or other similar technologies to provide you with advertising
                        based on
                        your browsing activities and interests. Please see our <a href="/cookie-policy">Cookies
                            Policy</a> for additional information on how we use cookies and what third party cookies we
                        permit.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Data Processing Disclose
                    </h2>
                    <p class="mt-4">
                        When you access the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network and use the Products and Services we offer, we
                        collect,
                        display, store, share, transmit, and process your information in the manner described in this
                        policy. In order to carry out these activities,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        may rely on a number of
                        legal
                        bases
                        in order to process your personal data, including where:
                    </p>
                    <ul class="list-group mt-4">
                        <li class="list-group-item">
                            necessary to perform the contractual obligations in our Terms of Service and in order to
                            provide
                            the Products and Services to you
                        </li>
                        <li class="list-group-item">
                            necessary for a third party’s, or our, legitimate interests
                        </li>
                        <li class="list-group-item">
                            necessary to comply with a legal obligation or to defend legal claims
                        </li>
                        <li class="list-group-item">
                            necessary to protect the public interest or vital interest of others
                        </li>
                        <li class="list-group-item">
                            you have expressly made information public
                        </li>
                        <li class="list-group-item">
                            you have consented to the processing, which may be revoked at any time
                        </li>
                    </ul>
                    <p class="mt-4">
                        Where we process your information on the basis of legitimate interests, we do so in order to:
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Secure your Personal Data and Information
                    </h3>
                    <p class="mt-4">
                        All records containing personal or financial information are considered to be proprietary and
                        are
                        afforded confidential treatment at all times.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }} is
                        committed to the safety
                        and
                        security
                        of your personal data and the information that you share with us and with the public. We treat
                        your
                        personal safety and safety from harassment as top organizational priorities. At
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        we
                        consider it necessary to pursue these legitimate interests in order to keep our community, you
                        and
                        your information safe from spam, harassment, intellectual property infringement, identity theft,
                        and
                        the scraping and unlawful collection of your information.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Provide and Optimize Products and Services
                    </h3>
                    <p class="mt-4">
                        We use your information to provide and improve our Products and Services, for identification
                        verification, to provide support, for online and offline marketing including through third party
                        tools such as Google Analytics, and for general research and analytics reporting. In doing so,
                        we
                        may learn which of our Products and Services you are using most, what you’re interested in, and
                        to
                        better enable you to use and access our Products and Services. As a core part of our business,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        has a legitimate interest in enabling and customizing your experience of
                        our Product
                        and
                        Services offerings.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Engage in Commercial Transactions
                    </h3>
                    <p class="mt-4">
                        As part of providing our core Products and Services,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        may charge you for the
                        use
                        of
                        some Products and Services, or certain features within these Products and Services. In order to
                        process your payment, and to secure your financial information, we may facilitate the sharing of
                        your information with third parties. We share your information only with third parties who have
                        met
                        strict security standards and consider the secure processing of your financial information to be
                        a
                        strict and legitimate business necessity.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Comply with Regulatory and Legal Obligations
                    </h3>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        has a legitimate interest in complying with certain legal obligations and
                        interests
                        which, from time to time, may require the disclosure of your personal information.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        will not disclose your personal information to legal authorities except where such disclosure is
                        by
                        lawful request, including to meet legitimate national security or law enforcement demands
                        (including
                        a subpoena, court order, or other lawful legal demand by a legal authority with lawful
                        jurisdiction). In some cases, we may also release your personal information to defend our
                        legitimate
                        legal interests. We consider our obligation to protect the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        community from
                        imminent
                        physical harm to be both a legitimate business interest as well as to be within the public
                        interest
                        and may disclose your personal information if we believe you or another individual may be in
                        imminent danger of harm to yourself or to another.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Marketing and Product Communications
                    </h3>
                    <p class="mt-4">
                        From time to time,
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        may communicate with you about commercial and other
                        Product
                        and
                        Services offerings. In doing so, we provide you with an opportunity to opt-out of such messages
                        at
                        any time you choose via your account settings.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        will not sell your personal
                        information to enhance our marketing opportunities or profitability (except as may relate to a
                        corporate event such as a sale or merger), and as we are committed to preventing spam, our
                        direct
                        marketing efforts are limited in scope and frequency. We engage in such activities as a
                        legitimate
                        business interest in order to promote key Products and Service offerings and provide you with
                        every
                        opportunity to unsubscribe from such communications or to further limit their scope and
                        frequency.
                        In short, while we want to communicate some key commercial communications with you and have
                        determined it to be a legitimate interest for us to be able to do so, you have the final say in
                        whether or not you would like to receive such commercial communications from us.
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Core Business Operations
                    </h3>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        may engage with third parties in business transactions including the buying
                        and
                        selling of assets, the auditing of our business practices and financials, and to engage in
                        business
                        development opportunities. These core activities may involve the processing and/or disclosure of
                        some limited personal information which may be necessary and within our legitimate interests to
                        develop the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        brand and business. If we transfer any personal information in
                        pursuing
                        such a business transaction, we will always ensure that strict confidentiality measures are in
                        place
                        to protect your privacy interests.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Data Transfers
                    </h2>
                    <p class="mt-4">
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }} is
                        a global community and as such, you may access the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network from
                        most anywhere in the world, and are subject to the local laws of your jurisdiction. By accessing
                        the
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        Network and engaging with our Products and Services, you acknowledge that
                        your
                        personal data may be collected and transferred from your local jurisdiction (including member
                        states
                        to the European Union) to the India.
                    </p>
                    <p class="mt-4">
                        Where
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        transfers your personal data from your local jurisdiction (including
                        member
                        states to the European Union) we rely on certain lawful transfer mechanisms to do so, including
                        the
                        following lawful bases for such transfers:
                    </p>
                    <h3 class="h5 mt-4 text-capitalize">
                        Standard Contractual Clauses
                    </h3>
                    <p class="mt-4">
                        The European Commission has adopted standard contractual clauses (also referred to as model
                        clauses), which provide safeguards to protect the transfer of personal information outside of
                        the
                        European Union. We may use these standard contractual clauses when transferring personal
                        information
                        outside of the European Union. You may review and request a copy of such standard contractual
                        clauses as used by
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }} by
                        contacting us.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Our ongoing commitment to data security
                    </h2>
                    <p class="mt-4">
                        Security is important to us and we know it is important to you.
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        follows
                        generally
                        accepted standards to protect your personal information when processing, transferring, and
                        storing
                        your personal information including Transport Layer Security (“TLS”), by restricting your
                        personal
                        data when we do not need to access it and by keeping your personal data only as necessary to
                        perform
                        our legitimate business interests.
                    </p>
                    <p class="mt-4">
                        As the data subject, you too have an important role to play in helping us protect your personal
                        information. We encourage you to protect yourself against unauthorized access to your personal
                        information by choosing a password carefully and in accordance with industry best standards. Do
                        not
                        share your password with anyone you do not trust, and make sure your computer accesses
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        via a secure network and that you do not leave your personal information vulnerable
                        to
                        hackers and other bad actors by leaving your computer unattended or by failing to logout of your
                        account when you have ended your session activity.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Direct Marketing Opt-Out
                    </h2>
                    <p class="mt-4">
                        You may opt-out of receiving
                        {{ ($settings->where('key', 'company')->pluck('value')->first() ?? 'Enlight Technologies') }}
                        email marketing materials by using the
                        unsubscribe
                        link
                        in these communications.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8 mt-4">
                    <h2 class="h4 text-center font-weight-bold text-capitalize">
                        Privacy Policy Amendments
                    </h2>
                    <p class="mt-4">
                        We may amend or update this policy from time to time, and will notify you of any material
                        changes to
                        this policy. Previous versions of this privacy policy are available upon request.
                    </p>
                    <div class="float-right">Last update: November 14, 2019</div>
                </div>
            </div>
        </div>
    </section>
</main>
@endsection