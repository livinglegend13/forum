<div class="tracking-item">
    <div class="tracking-icon bg-gray">
        {{ $icon }}
    </div>
    <div class="tracking-date">
        {{ $date }}
    </div>
    <div class="tracking-content">
        {{ $heading }}
        <span>{{ $body }}</span>
    </div>
</div>