@component('profiles.activities.activity')

    @slot('icon')
        <i class="fas fa-heart red"></i>
    @endslot

    @slot('date')
        {{ $date }}
        <span>{{ $activity->created_at->diffForHumans() }}</span>
    @endslot

    @slot('heading')
        {{ __('Liked a reply :') }}
    @endslot


    @slot('body')
        <a title="{{ Str::limit(strip_tags($activity->subject->favourited->body), 150) }}"
           href="{{ $activity->subject->favourited->path() }}" v-pre>
            {{ Str::limit(strip_tags($activity->subject->favourited->body), 150) }}
        </a>
    @endslot

@endcomponent
