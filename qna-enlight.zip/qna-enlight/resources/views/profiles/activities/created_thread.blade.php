@component('profiles.activities.activity')

    @slot('icon')
        <i class="fas fa-question dark"></i>
    @endslot

    @slot('date')
        {{ $date }}
        <span>{{ $activity->created_at->diffForHumans() }}</span>
    @endslot

    @slot('heading')
        {{ __('Published a question :') }}
        <a title="{{ Str::limit(strip_tags($activity->subject->title, 50)) }}" href="{{ $activity->subject->path() }}"
           v-pre>
            {{ Str::limit(strip_tags($activity->subject->title, 50)) }}
        </a>
    @endslot

    @slot('body')
        <span v-pre>
    {{ Str::limit(strip_tags($activity->subject->body), 150) }}
</span>
    @endslot

@endcomponent
