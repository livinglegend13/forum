@extends('layouts.app')

@section('title')
    {{ 'Top 50 Contributors | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
    Top 50 contributors of {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}.
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center my-4">

            @php
                $counter = 1;
            @endphp
            <div class="col-md-8">

                <div class="row justify-content-center">
                    <div class="col-lg-10 m-2">
                        <h1 class="text-center font-weight-normal p-2">
                            <i class="fas fa-trophy"></i> {{ __('Leaderboard') }}
                        </h1>
                    </div>
                    @foreach ($users as $user)
                        <div class="col-lg-5 rounded m-2 p-2 border">
                            <div class="d-flex align-items-center">
                                <img src="{{ $user->avatar }}" alt="{{ $user->name }}" class="rounded-circle mr-2"/>
                                <div class="flex-column">

                                    <h3 class="font-weight-normal text-capitalize mr-2">
                                        {{ $user->name }}
                                    </h3>
                                    <div>{{ __('Points:') }} <span class="font-weight-bold">{{ $user->getPoints() }}
                                            {{ __('RP') }}</span>
                                    </div>
                                    <div>{{ __('Profile @') }}
                                        <a title="Profile of {{ $user->name }}"
                                           href="{{ route('profiles.show', ['user' => $user ]) }}">
                                            {{ $user->username }}
                                        </a>
                                    </div>
                                </div>
                                <span class="font-weight-bold ml-auto text-muted display-3">{{ $counter++ }}</span>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="col-md-3 mt-4">
                @include('threads._trendingThreads')
                @include('threads._allchannels')

                @for ($i = 0; $i < 4; $i++) {!! ($settings->where('key', 'vertical-ads')->pluck('value')->first() ??
                '') !!}
                @endfor

            </div>
        </div>
    </div>
@endsection
