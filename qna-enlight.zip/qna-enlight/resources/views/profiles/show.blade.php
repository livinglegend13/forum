@extends('layouts.app')

@section('title')
    {{ $profileUser->name . ' | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
    {{ $profileUser->name . ' is the memeber of this community since ' . $profileUser->created_at->diffForHumans() . ' and has total reputation points: ' . $profileUser->getPoints() }}
@endsection

@section('content')
    <profile-view inline-template>
        <div class="container-fluid">
            <div class="row justify-content-center mt-5">
                <div class="col-md-3">
                    <avatar-form :user="{{ $profileUser }}"></avatar-form>

                    <div class="d-flex justify-content-center mt-4">
                        @foreach ($badges as $badge)
                            <img class="mr-2 {{ $profileUser->hasBadge($badge) ? '' : 'gray-scale'}}"
                                 src="{{ asset($badge->icon) }}" alt="{{ $badge->name }}"
                                 title="{{ $badge->description}}">

                        @endforeach
                    </div>

                    <p class="text-muted text-uppercase text-center">{{ __('total reputation points:') }} <span
                                class="dark font-weight-bold">{{ $profileUser->getPoints() }}
                            {{ __('RP') }}</span>
                    </p>
                    <p class="text-muted text-uppercase text-center">{{ __('joined us') }} <span
                                class="dark font-weight-bold">{{ $profileUser->created_at->diffForHumans() }}</span></p>
                    <p class="text-muted text-uppercase text-center">{{ __('all threads by') }}
                        <a title="All threads by {{ $profileUser->name }}"
                           href="{{ route('threads.index', ['by' => $profileUser->username ]) }}">
                            <span class="font-weight-bold">{{ $profileUser->name }}</span>
                        </a>
                    </p>

                    @can('update', $profileUser)
                        <form action="{{ route('profiles.update', $profileUser ) }}" method="post" class="mt-3">
                            @csrf
                            @method('patch')
                            <div class="input-group mt-3">
                                <input class="form-control" type="text" name="name" placeholder="Name" aria-label="Name"
                                       aria-describedby="name" value="{{ $profileUser->name }}">
                                <div class="input-group-append">
                            <span class="input-group-text" id="name">
                                <i class="fas fa-user primary"></i>
                            </span>
                                </div>
                            </div>
                            @error('name')
                            <small class="red">
                                <strong>{{ $message }}</strong>
                            </small>
                            @enderror
                            <div class="input-group mt-3">
                                <input class="form-control" type="email" name="email" placeholder="Email"
                                       aria-label="Email"
                                       aria-describedby="email" value="{{ $profileUser->email }}">
                                <div class="input-group-append">
                            <span class="input-group-text" id="email">
                                <i class="fas fa-envelope primary"></i>
                            </span>
                                </div>
                            </div>
                            @error('email')
                            <small class="red">
                                <strong>{{ $message }}</strong>
                            </small>
                            <br>
                            @enderror
                            <button class="btn btn-sm bg-blue blue font-weight-bold mt-3" v-tooltip="'Update Profile'"
                                    type="submit">
                                {{ __('Update') }}
                            </button>
                        </form>
                    @endcan

                    @can('update', $profileUser)
                        <form action="{{ route('profiles.password', $profileUser )}}" method="post" class="mt-3">
                            @csrf
                            @method('patch')
                            <div class="input-group mt-3">
                                <input class="form-control" type="password" name="current_password"
                                       placeholder="Current Password" aria-label="current_password"
                                       aria-describedby="current_password">
                            </div>
                            @error('current_password')
                            <small class="red">
                                <strong>{{ $message }}</strong>
                            </small>
                            @enderror
                            <div class="input-group mt-3">
                                <input class="form-control" type="password" name="password" placeholder="New Password"
                                       aria-label="password" aria-describedby="password">
                            </div>
                            @error('password')
                            <small class="red">
                                <strong>{{ $message }}</strong>
                            </small>
                            @enderror
                            <div class="input-group mt-3">
                                <input class="form-control" type="password" name="password_confirmation"
                                       placeholder="Confirm New Password" aria-label="password_confirmation"
                                       aria-describedby="password_confirmation">
                            </div>
                            @error('password_confirmation')
                            <small class="red">
                                <strong>{{ $message }}</strong>
                            </small>
                            <br>
                            @enderror
                            <button class="btn btn-sm bg-blue blue font-weight-bold mt-3" v-tooltip="'Update Password'"
                                    type="submit">
                                {{ __('Update') }}
                            </button>
                        </form>
                    @endcan
                    <?php for ($i = 0; $i < 4; $i++) { ?>
                    {!! ($settings->where('key', 'vertical-ads')->pluck('value')->first() ?? '') !!}
                    <?php } ?>
                </div>
                <div class="col-md-8 mt-5 mt-md-0">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link nav-link" :class="timelineClasses" id="timeline-tab" data-toggle="tab"
                               href="#timeline" role="tab" aria-controls="timeline" aria-selected="true"
                               @click.prevent="toggle">
                                {{ __('Timeline') }}
                            </a>
                        </li>
                        @can('update', $profileUser)
                            <li class="nav-item">
                                <a class="nav-link nav-link" :class="subscriptionListClasses" id="subscriptionList-tab"
                                   data-toggle="tab" href="#subscriptionList" role="tab"
                                   aria-controls="subscriptionList"
                                   aria-selected="false" @click.prevent="toggle">
                                    {{ __('Subscriptions') }}
                                </a>
                            </li>
                        @endcan
                    </ul>
                    <div class="tab-content mt-2">
                        <div class="tab-pane fade" :class="timelineClasses" id="timeline" role="tabpanel"
                             aria-labelledby="timeline-tab">
                            <div class="tracking-list">
                                @forelse( $activities as $date => $activity)
                                    @foreach ($activity as $record)
                                        @if(view()->exists("profiles.activities.{$record->type}"))
                                            @include("profiles.activities.{$record->type}", ['activity' => $record, 'date'=> $date])
                                        @endif
                                    @endforeach
                                @empty
                                    <p class="text-center mt-4">
                                        {{ __('There is no activity for this user yet !!') }}
                                    </p>
                                @endforelse
                            </div>
                        </div>
                        @can('update', $profileUser)
                            <div class="tab-pane fade" :class="subscriptionListClasses" id="subscriptionList"
                                 role="tabpanel"
                                 aria-labelledby="subscriptionList-tab">
                                <ul class="list-group">
                                    @foreach ($profileUser->subscriptions as $thread)
                                        <li class="list-group-item">
                                            <div class="d-flex flex-row">
                                                <a title="{{ $thread->title }}" href="{{ $thread->path() }}">
                                                    <h3 class="font-weight-bold">
                                                        {{ $thread->title }}
                                                    </h3>
                                                </a>
                                                <div class="ml-auto">
                                                    <subscribe-button
                                                            :issubscribed="{{ json_encode($thread->isSubscribedTo) }}"
                                                            :path="{{ json_encode($thread->path()) }}">
                                                    </subscribe-button>
                                                </div>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>
        </div>
    </profile-view>
@endsection
