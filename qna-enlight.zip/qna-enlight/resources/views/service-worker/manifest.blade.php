{
"dir" : "ltr",
"lang" : "en",
"name" : "{{ $settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight - An Automated Forum' }}",
"scope" : "/",
"display" : "standalone",
"start_url" : "{{ asset('/')}}",
"short_name" :
"{{ $settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight - An Automated Forum' }}",
"theme_color" : "#f7fafc",
"description" :
"{{ $settings->where('key', 'description')->pluck('value')->first() ?? 'QnA Enlight - An Automated Forum' }}",
"orientation" : "portrait",
"background_color" : "#f7fafc",
"icons" : [
{
"src": "{{ asset('logo-512x512.png') }}",
"sizes": "512x512",
"type": "image/png"
},
{
"src": "{{ asset('logo-256x256.png') }}",
"sizes": "256x256",
"type": "image/png"
},
{
"src": "{{ asset('apple-touch-icon.png') }}",
"sizes": "180x180",
"type": "image/png"
},
{
"src": "{{ asset('logo-144x144.png') }}",
"sizes": "144x144",
"type": "image/png"
},
{
"src": "{{ asset('logo-96x96.png') }}",
"sizes": "96x96",
"type": "image/png"
},
{
"src": "{{ asset('favicon-48x48.png') }}",
"sizes": "48x48",
"type": "image/png"
},
{
"src": "{{ asset('favicon-32x32.png') }}",
"sizes": "32x32",
"type": "image/png"
},
{
"src": "{{ asset('favicon-16x16.png') }}",
"sizes": "16x16",
"type": "image/png"
}
]
}