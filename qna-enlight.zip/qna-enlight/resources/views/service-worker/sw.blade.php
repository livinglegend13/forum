const CACHE = "qna-enlight-offline";

const offlineFallbackPage = "/";

self.addEventListener("install", function (event) {
//console.log("[PWA] Install Event processing");

event.waitUntil(
caches.open(CACHE).then(function (cache) {
//console.log("[PWA] Cached offline page during install");

return cache.add(offlineFallbackPage);
})
);
});

self.addEventListener("fetch", function (event) {
if (event.request.method !== "GET") return;

event.respondWith(
fetch(event.request)
.then(function (response) {

event.waitUntil(updateCache(event.request, response.clone()));

//console.log("[PWA Cache] add page to offline cache: " + response.url);

return response;
})
.catch(function (error) {
//console.log("[PWA Failed] Network request Failed. Serving content from cache: " + error);
return fromCache(event.request);
})
);
});

function fromCache(request) {
return caches.open(CACHE).then(function (cache) {
return cache.match(request).then(function (matching) {
if (!matching || matching.status === 404) {
return Promise.reject("no-match");
}

return matching;
});
});
}

function updateCache(request, response) {
return caches.open(CACHE).then(function (cache) {
return cache.put(request, response);
});
}