@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        @include('admin._admin_nav')

        <div class="row justify-content-center">
            <div class="col-md-11 mt-4 mb-4">
                <div class="card border-warning card-warning">
                    <div class="card-header d-flex align-items-center">
                        <h4 class="font-weight">
                            {{ __('Api Settings') }}
                        </h4>
                    </div>
                    <div class="card-body table-responsive">
                        <form action="{{ route('admin.api-settings.postRecaptchaKeys') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="recaptcha_key">{{ __('Google Recaptcha V3 Key:') }} <span
                                            class="red">*</span></label>
                                <input id="recaptcha_key" class="form-control" type="text" name="recaptcha_key"
                                       placeholder="Google reCaptcha Key"
                                       value="{{ ($settings->where('key', 'recaptcha_key')->pluck('value')->first() ?? '')}}">
                                @error('recaptcha_key')
                                <small class="red">
                                    <strong>{{ $message }}</strong>
                                </small>
                                @enderror
                            </div>
                            <div class="form-group">
                                <label for="recaptcha_secret">{{ __('Google Recaptcha V3 Secret:') }} <span
                                            class="red">*</span></label>
                                <input id="recaptcha_secret" class="form-control" type="text" name="recaptcha_secret"
                                       placeholder="Google reCaptcha Secret"
                                       value="{{ ($settings->where('key', 'recaptcha_secret')->pluck('value')->first() ?? '')}}">
                                @error('recaptcha_secret')
                                <small class="red">
                                    <strong>{{ $message }}</strong>
                                </small>
                                @enderror
                            </div>
                            <button class="btn btn-sm bg-blue blue font-weight-bold"
                                    type="submit">{{ __('Update') }}</button>
                        </form>
                        <hr>
                        <form action="{{ route('admin.api-settings.postAnalyticsKey') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="analytics_key">{{ __('Google Analytics Key:') }}</label>
                                <input id="analytics_key" class="form-control" type="text" name="analytics_key"
                                       placeholder="Google Analytics Key Ex. UA-1518934132423-2"
                                       value="{{ ($settings->where('key', 'analytics_key')->pluck('value')->first() ?? '')}}">
                                @error('analytics_key')
                                <small class="red">
                                    <strong>{{ $message }}</strong>
                                </small>
                                @enderror
                            </div>
                            <button class="btn btn-sm bg-blue blue font-weight-bold border"
                                    type="submit">{{ __('Update') }}</button>
                        </form>
                        <hr>
                        <form action="{{ route('admin.api-settings.postOneSignalKey') }}" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="onesignal_key">{{ __('OneSignal App ID:') }}</label>
                                <input id="onesignal_key" class="form-control" type="text" name="onesignal_key"
                                       placeholder="One Signal Key"
                                       value="{{ ($settings->where('key', 'onesignal_key')->pluck('value')->first() ?? '')}}">
                                @error('onesignal_key')
                                <small class="red">
                                    <strong>{{ $message }}</strong>
                                </small>
                                @enderror
                            </div>
                            <button class="btn btn-sm bg-blue blue font-weight-bold"
                                    type="submit">{{ __('Update') }}</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
