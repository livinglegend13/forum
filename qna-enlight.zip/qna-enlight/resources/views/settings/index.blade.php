@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        @include('admin._admin_nav')

        <div class="row justify-content-center">
            <div class="col-md-11 mt-4 mb-4">
                <div class="card border-warning card-warning">
                    <div class="card-header d-flex align-items-center">
                        <h4 class="font-weight">
                            {{ __('All Settings') }}
                        </h4>
                    </div>
                    <div class="card-body table-responsive">
                        <div class="row justify-content-center">
                            <div class="col">
                                <form action="{{ route('admin.settings.postSite')}}" method="post">
                                    @csrf
                                    <div class="form-group">
                                        <label for="sitename">{{ __('Sitename:') }}</label>
                                        <input id="sitename" class="form-control" type="text" name="sitename"
                                               placeholder="Your sitename goes here.."
                                               value="{{ ($settings->where('key', 'sitename')->pluck('value')->first
                                               () ?? '')}}">
                                        @error('sitename')
                                        <small class="red">
                                            <strong>{{ $message }}</strong>
                                        </small>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="description">{{ __('Description:') }}</label>
                                        <input id="description" class="form-control" type="text" name="description"
                                               placeholder="Description for your website SEO.."
                                               value="{{ ($settings->where('key', 'description')->pluck('value')
                                               ->first() ?? '')}}">
                                        @error('description')
                                        <small class="red">
                                            <strong>{{ $message }}</strong>
                                        </small>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="company">{{ __('Company:') }}</label>
                                        <input id="company" class="form-control" type="text" name="company"
                                               placeholder="Company name.."
                                               value="{{ $settings->where('key', 'company')->pluck('value')->first()
                                               ?? '' }}">
                                        @error('company')
                                        <small class="red">
                                            <strong>{{ $message }}</strong>
                                        </small>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label for="siteurl">{{ __('Site Url:') }}</label>
                                        <input id="siteurl" class="form-control" type="text" name="siteurl"
                                               placeholder="Ex. //enlight.host"
                                               value="{{ ($settings->where('key', 'siteurl')->pluck('value')->first()
                                                ?? '')}}">
                                        @error('siteurl')
                                        <small class="red">
                                            <strong>{{ $message }}</strong>
                                        </small>
                                        @enderror
                                    </div>
                                    <button class="btn btn-sm bg-blue blue font-weight-bold"
                                            type="submit">{{ __('Update') }}</button>
                                </form>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-12 mt-4">
                                <form action="{{ route('admin.settings.postLogo') }}" method="post"
                                      enctype="multipart/form-data">
                                    @csrf
                                    <img src="{{ asset('logo.png')}}" alt="sitelogo" title="logo">
                                    <img src="{{ asset('apple-touch-icon.png')}}" alt="apple-touch-icon"
                                         title="apple-touch-icon" class="mr-4">
                                    <img src="{{ asset('favicon-48x48.png')}}" alt="favicon-48x48" title="favicon-48x48"
                                         class="mr-4">
                                    <img src="{{ asset('favicon-32x32.png')}}" alt="favicon-32x32" title="favicon-32x32"
                                         class="mr-4">
                                    <img src="{{ asset('favicon-16x16.png')}}" alt="favicon-16x16" title="favicon-16x16"
                                         class="mr-4">
                                    <div class="input-group mt-4">
                                        <div class="custom-file">
                                            <input name="logo" class="custom-file-input" type="file"
                                                   accept="image/x-png">
                                            <label for="logo" class="custom-file-label">
                                                {{ __('Logo: (Best fit 180x180 transparent png)') }}
                                            </label>
                                        </div>
                                        <div class="input-group-append">
                                            <button class="btn btn-sm bg-blue blue font-weight-bold border"
                                                    type="submit">{{ __('Upload') }}</button>
                                        </div>
                                    </div>
                                    @error('logo')
                                    <small class="red">
                                        <strong>{{ $message }}</strong>
                                    </small>
                                    @enderror
                                </form>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <form action="{{ route('admin.settings.postSocial') }}" method="post">
                                    @csrf
                                    <div class="form-group">
                                        <label for="facebook"><i class="fab fa-facebook"></i>
                                            {{ __('Facebook Link:') }}</label>
                                        <input id="facebook" class="form-control" type="text" name="facebook_link"
                                               placeholder="Ex. //www.facebook.com/your_brand"
                                               value="{{ ($settings->where('key', 'facebook_link')->pluck('value')->first() ?? '')}}">
                                    </div>
                                    <div class="form-group">
                                        <label for="whatsapp"><i class="fab fa-whatsapp"></i>
                                            {{ __('Whatsapp Link:') }}</label>
                                        <input id="whatsapp" class="form-control" type="text" name="whatsapp_link"
                                               placeholder="Ex. //api.whatsapp.com/send?phone=your_mobile_number_with_country_code"
                                               value="{{ ($settings->where('key', 'whatsapp_link')->pluck('value')->first() ?? '')}}">
                                    </div>
                                    <div class="form-group">
                                        <label for="instagram"><i class="fab fa-instagram"></i>
                                            {{ __('Instagram Link:') }}</label>
                                        <input id="instagram" class="form-control" type="text" name="instagram_link"
                                               placeholder="Ex. //www.instagram.com/your_brand"
                                               value="{{ ($settings->where('key', 'instagram_link')->pluck('value')->first() ?? '')}}">
                                    </div>
                                    <div class="form-group">
                                        <label for="twitter"><i class="fab fa-twitter"></i>
                                            {{ __('Twitter Link:') }}</label>
                                        <input id="twitter" class="form-control" type="text" name="twitter_link"
                                               placeholder="Ex. //www.twitter.com/your_brand"
                                               value="{{ ($settings->where('key', 'twitter_link')->pluck('value')->first() ?? '')}}">
                                    </div>
                                    <button class="btn btn-sm bg-blue blue font-weight-bold"
                                            type="submit">{{ __('Update') }}</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
