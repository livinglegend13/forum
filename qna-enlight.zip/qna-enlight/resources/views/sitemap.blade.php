<?php

echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc>{{ route('welcome') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>1</priority>
    </url>
    <url>
        <loc>{{ route('login') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('register') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('password.request') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('threads.index') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('threads.search.index', ['q' => '']) }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('threads.index', ['popular' => 1]) }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('threads.index', ['unanswered' => 1]) }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('policies.cookie') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('policies.privacy') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    <url>
        <loc>{{ route('profiles.index') }}</loc>
        <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    @foreach ($channels as $channel)
        <url>
            <loc>{{ route('threads.filterBy.channel.index', $channel) }}</loc>
            <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
    @endforeach
    @foreach ($threads as $thread)
        <url>
            <loc>{{ asset($thread->path()) }}</loc>
            <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
    @endforeach
    @foreach ($users as $user)
        <url>
            <loc>{{ route('profiles.show', $user) }}</loc>
            <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
        <url>
            <loc>{{ route('threads.index', ['by' => $user]) }}</loc>
            <lastmod>{{ Carbon\Carbon::now()->tz('Asia/Kolkata')->toAtomString() }}</lastmod>
            <changefreq>daily</changefreq>
            <priority>0.8</priority>
        </url>
    @endforeach
</urlset>
