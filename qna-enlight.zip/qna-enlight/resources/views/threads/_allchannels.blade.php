<ul class="list-unstyled">
    <li class="text-uppercase font-weight-bold mb-4 ml-2">
        <i class="fas fa-th-list mr-1"></i> {{ __('All Channels') }}
    </li>
    @foreach ($channels as $channel)
        <li class="text-center m-2">
            @include('threads._channelButton')
        </li>
    @endforeach
</ul>
