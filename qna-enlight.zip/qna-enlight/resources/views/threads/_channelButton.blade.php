<a class="btn btn-sm rounded-pill bg-blue w-100 text-uppercase font-weight-bold"
   href="{{ route( 'threads.filterBy.channel.index', $channel->slug) }}"
   v-tooltip="'Filter threads by {{ $channel->name }}'">
    <i class="{{ $channel->font_awesome_classes }}"></i>
    {{ $channel->name }}
</a>
