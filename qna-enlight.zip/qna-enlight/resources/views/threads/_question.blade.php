{{-- editing --}}
<div class="card border-primary card-primary" v-if="editing" v-cloak>
    <div class="card-header d-flex align-items-center">
        <img class="rounded-circle mr-2" src="{{  $thread->creator->avatar }}" alt="{{ $thread->creator->name }}"
             height="55">

        <div class="d-flex flex-column">

            <a title="{{ $thread->creator->username }}" class="ml-2"
               href="{{ route('profiles.show', $thread->creator->username) }}">
                {{ $thread->creator->username }}</a>

            <small class="ml-2 text-capitalize font-weight-bold text-muted"> {{ __('asked') }}
                {{ $thread->created_at->diffForHumans() }}...</small>

        </div>
    </div>

    <div class="card-body">

        <div class="form-group">
            <label for="title" class="font-weight-bold">{{ __('Title :') }}</label>
            <input type="text" id="title" required="required" placeholder="Title here.." class="form-control"
                   v-model="title">
            <small>{{ __('Be specific and imagine you’re asking a question to another person') }}</small>
        </div>
        <div class="form-group">
            <label for="body" class="font-weight-bold">{{ __('Body :') }}</label>
            <wysiwyg id="update-thread" name="body" placeholder="Explain here.." v-model="body"></wysiwyg>
            <small>{{ __('Include all the information someone would need to answer your question') }}</small>
        </div>
    </div>

    <div class="card-footer d-flex align-items-center">

        <div class="mr-auto">
            <button class="btn btn-sm bg-blue blue font-weight-bold ml-2 ml-auto" v-tooltip="'Update Thread'"
                    @click="update">
                {{ __('Update') }}
            </button>
            <button class="btn btn-sm ml-2 ml-auto" v-tooltip="'Cancel Editing'" @click="resetForm">
                {{ __('Cancel') }}
            </button>
        </div>

        <div class="ml-auto">
            @can('update', $thread)
                <form action="{{$thread->path()}}" method="post">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-sm btn-outline-danger ml-2" v-tooltip="'Delete Thread'">
                        <i class="fa fa-times-circle"></i>
                    </button>
                </form>
            @endcan
        </div>
    </div>
</div>

{{-- viewing --}}

<div class="card border-primary card-primary" v-else>
    <div class="card-header">
        <h1 class="h2 mb-4" v-text="title"></h1>
        <div class="d-flex align-items-center">
            <img class="rounded-circle mr-2" src="{{  $thread->creator->avatar }}" alt="{{ $thread->creator->name }}"
                 height="55">
            <div class="d-flex flex-column">

                <a title="{{ $thread->creator->username }}" class="ml-2"
                   href="{{ route('profiles.show', $thread->creator->username) }}">
                    {{ $thread->creator->username }}</a>

                <small class="ml-2 text-capitalize font-weight-bold text-muted"> {{ __('asked') }}
                    {{ $thread->created_at->diffForHumans() }}...</small>

            </div>


            @can('update', $thread)
                <button class="btn btn-sm btn-outline-primary ml-2 ml-auto" v-tooltip="'Edit Thread'"
                        @click="editing = true">
                    <i class="fas fa-edit"></i>
                </button>
            @endcan
        </div>
    </div>

    <div class="card-body">
        <div v-html="body"></div>
    </div>

    <div class="card-footer d-flex align-items-center">

        <div class="mr-auto">
            @include('threads._channelButton', [ 'channel' => $thread->channel ])
        </div>

        <small v-tooltip="'{{ $thread->visits }} {{ \Illuminate\Support\Str::plural('visit', $thread->visits) }} and ' + pluralComment"
               class="mr-2 ml-2 font-weight-bold d-none d-md-block">
            <i class="far fa-eye mr-2 ml-2"></i> {{ $thread->visits }}
            <i class="fas fa-comment mr-2 ml-2"></i> <span v-text="repliesCount"></span>
        </small>

        <div class="ml-auto">
            <a href="{{ $thread->whatsappPath() }}" class="btn btn-md whatsapp-icon mr-1"
               v-tooltip="'Share this thread on Whatsapp'" target="_blank">
                <i class="fab fa-whatsapp"></i>
            </a>
            <a href="{{ $thread->facebookPath() }}" class="btn btn-md facebook-icon mr-1"
               v-tooltip="'Share this thread on Facebook'" target="_blank">
                <i class="fab fa-facebook"></i>
            </a>
            <a href="{{ $thread->twitterPath() }}" class="btn btn-md twitter-icon mr-1"
               v-tooltip="'Share this thread on Twitter'" target="_blank">
                <i class="fab fa-twitter"></i>
            </a>
        </div>

    </div>
</div>
