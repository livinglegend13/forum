@if ($trendings->count())

    <ul class="list-group mb-4">
        <li class="list-group-item ">
            <div class="d-flex">
            <span class="mr-2 font-weight-bold text-uppercase">
                &#128293; {{ __('Trending Threads') }}
            </span>
                <a v-tooltip="'Create a Thread'" href="{{ route('threads.create') }}"
                   class="btn btn-sm btn-primary text-white text-wrap ml-auto">
                    {{ __('Ask a Question') }}
                </a>
            </div>
        </li>
        @foreach ($trendings as $trendingThread)
            <li class="list-group-item">
                <a title="{{ $trendingThread->title }}" href="{{ $trendingThread->path() }}" v-pre>
                    {{ $trendingThread->title }}
                </a>
            </li>
        @endforeach
    </ul>
@else
    <div class="d-flex m-4">
        <a v-tooltip="'Create a Thread'" href="{{ route('threads.create') }}"
           class="btn btn-sm btn-primary text-wrap ml-auto">
            {{ __('Ask a Question') }}
        </a>
    </div>
@endif
