@extends('layouts.app')

@section('head')
    <script src="//www.google.com/recaptcha/api.js?render={{ ($settings->where('key', 'recaptcha_key')->pluck('value')->first() ?? 'your_recaptcha_key')}}"></script>
@endsection

@section('title')
    {{ 'Ask your question to specific community  | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
    Be specific and imagine you’re asking a question to another person and include all the information someone would need to
    answer your question.
@endsection


@section('content')
    <thread-create inline-template>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-10">

                    <create-thread-form :channels="{{ $channels }}"
                                        :recaptcha_site_key="{{ json_encode($settings->where('key', 'recaptcha_key')->pluck('value')->first() ?? 'your_recaptcha_key') }}">
                    </create-thread-form>

                </div>
            </div>
        </div>
    </thread-create>
@endsection
