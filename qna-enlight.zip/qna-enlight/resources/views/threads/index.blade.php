@extends('layouts.app')

@isset($queryChannel)
    @if ($queryChannel->name)

@section('title')
    {{ $queryChannel->name . ' threads can be searched here | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@endif
@endisset

@section('description')
    List of all threads available at {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }},
    You can filter threads according using
    @foreach (
    $channels as $channel ) {{$channel->name}} @if(! $loop->last ) , @endif @endforeach keywords here.
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-2">
                <div class="row">
                    @forelse ( $threads as $thread)
                        <div class="col-12 p-4">
                            <div class="row">
                                <div class="col-12 d-flex align-items-center">

                                    <a title="{{ $thread->title }}" href="{{ $thread->path() }}" v-pre>
                                        @if (auth()->check() && $thread->hasUpdatesFor(auth()->user()))
                                            <h3 class="font-weight-bold">
                                                {{ $thread->title }}
                                            </h3>
                                        @else
                                            <h4 class="secondary">
                                                {{ $thread->title }}
                                            </h4>
                                        @endif
                                    </a>

                                    <span class="ml-auto mb-2 d-none d-md-block">
                                <a v-tooltip="'{{ $thread->visits }} {{ \Illuminate\Support\Str::plural('visit', $thread->visits) }} and {{
                                $thread->replies_count }} {{ \Illuminate\Support\Str::plural('reply', $thread->replies_count) }}'"
                                   class="btn btn-sm rounded-pill {{ $thread->best_reply_id  ? 'bg-green' : ($thread->replies_count > 0 ? 'bg-blue' : 'bg-gray')}}"
                                   href="{{$thread->path()}}">
                                    {{$thread->visits}}
                                    <i class="far fa-eye mr-2"></i>
                                    {{$thread->replies_count}}
                                    <i class="fas fa-comment"></i>
                                </a>
                            </span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12" v-pre>
                                    <a title="{{ \Illuminate\Support\Str::limit(strip_tags($thread->body),150) }}"
                                       href="{{ $thread->path() }}">
                                        <p class="secondary">
                                            {{ \Illuminate\Support\Str::limit(strip_tags($thread->body),150) }}
                                        </p>
                                    </a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 d-flex align-items-center">
                                    <div class="mr-auto d-flex align-items-center">

                                        <img class="rounded-circle" src="{{ $thread->creator->avatar }}"
                                             alt="{{ $thread->creator->name }}" height="45">

                                        <div class="d-flex flex-column">

                                            <a title="{{ $thread->creator->username }}" class="ml-2"
                                               href="{{ route('profiles.show', $thread->creator->username) }}">
                                                {{ $thread->creator->username }}</a>

                                            <small class="ml-2 text-capitalize font-weight-bold text-muted"> {{ __('asked') }}
                                                {{ $thread->created_at->diffForHumans() }}...</small>

                                        </div>

                                    </div>
                                    <div class="ml-auto">
                                        @include('threads._channelButton', ['channel' => $thread->channel ])
                                    </div>
                                </div>
                            </div>

                        </div>
                    @empty
                        <div class="col-md-12 mb-4 text-center">
                            {{ __('There are no relevent results at this time. Find all threads') }}
                            <a title="Find all threads here.." href="{{ route('threads.index') }}">{{ __('here.') }}</a>
                        </div>
                    @endforelse
                    <div class="col-12 my-4 text-center">
                        {{ $threads->appends($_GET)->links() }}
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-2">

                @include('threads._trendingThreads')

                @include('threads._allchannels')

                <?php for ($i = 0; $i < 4; $i++) { ?>

                {!! ($settings->where('key', 'square-ads')->pluck('value')->first() ?? '') !!}

                <?php } ?>

            </div>
        </div>
    </div> @endsection
