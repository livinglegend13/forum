@extends('layouts.app')

@section('title')
    {{ $thread->title . ' | ' .  ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
@endsection

@section('description')
    {{ \Illuminate\Support\Str::limit(strip_tags($thread->body),150) }}
@endsection

@section('content')
    <thread-view :thread="{{ json_encode($thread) }}" inline-template>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-3">

                    <div class="row">

                        <div class="col-12 order-md-2 d-none d-md-block">

                            @include('threads._trendingThreads')

                            @include('threads._allchannels')

                            <?php for ($i = 0; $i < 4; $i++) { ?>
                            {!! ($settings->where('key', 'square-ads')->pluck('value')->first() ?? '') !!}
                            <?php } ?>
                        </div>

                        <div class="col-12 mb-4 order-md-1">
                            <div class="card">
                                <div class="card-header">
                                    {{ __('This thread was published') }} {{ $thread->created_at->diffForHumans() }} by
                                    <a title="{{ $thread->creator->username }}"
                                       href="{{ route('profiles.show', $thread->creator->username) }}">
                                        {{ $thread->creator->username }}
                                    </a>,
                                    {{ __('and currently has') }}
                                    <span v-text="pluralComment"></span>
                                </div>

                                <div class="card-footer" v-if="signedIn">

                                    <subscribe-button :issubscribed="{{ json_encode($thread->isSubscribedTo) }}"
                                                      :path="{{ json_encode($thread->path()) }}">
                                    </subscribe-button>

                                    <lock-button :thread="{{ json_encode($thread) }}" @lock_toggled="toggleLockStatus">
                                    </lock-button>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-12">
                            @include('threads._question')
                        </div>

                        <replies @reply_added="repliesCount++" @reply_deleted="repliesCount--">
                        </replies>
                    </div>

                </div>
            </div>
        </div>
    </thread-view>
@endsection
