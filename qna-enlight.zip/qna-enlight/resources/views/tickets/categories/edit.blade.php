@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        @include('admin._admin_nav')

        <div class="row justify-content-center">
            <div class="col-md-11 mt-4 mb-4">
                <div class="card border-warning card-warning">
                    <div class="card-header d-flex align-items-center">
                        <h4 class="card-title font-weight">{{ __('Edit Ticket Category') }}</h4>
                    </div>
                    <form action="{{ route('admin.ticket.categories.update', $category) }}" method="post">
                        @csrf
                        @method('PUT')

                        <div class="card-body">
                            <div class="form-group row">
                                <label for="name"
                                       class="col-md-4 col-form-label text-md-right">{{ __('Name:') }}</label>

                                <div class="col-md-6">
                                    <input id="name" type="text"
                                           class="form-control @error('name') is-invalid @enderror"
                                           name="name" value="{{ $category->name }}" required autofocus>

                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-center">
                            <button type="submit" class="btn bg-blue blue font-weight-bold">{{ __('Update') }}
                            </button>
                            <a href="{{ route('admin.ticket.categories.index')}}" title="Back to categories"
                               class="btn btn-sm mr-2">{{ __('Back') }}</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
