@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h3>
                                Open Ticket
                            </h3>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="{{ route('tickets.store') }}" method="post">
                            @csrf
                            <div class="input-group mb-3">
                                <select class="form-control @error('category_id') is-invalid @enderror"
                                        name="category_id">
                                    <option disabled selected>Choose Category</option>
                                    @foreach ($categories as $category)
                                        <option value="{{ $category->id }}">
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('category_id')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                                @enderror
                            </div>
                            <div class="input-group mb-3">
                                <input id="title" type="text" class="form-control @error('title') is-invalid @enderror"
                                       name="title" placeholder="Title" value="{{ old('title') }}" required
                                       autocomplete="title" autofocus>
                                @error('title')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                                @enderror
                            </div>
                            <div class="input-group mb-3">
                                <select class="form-control @error('priority') is-invalid @enderror" name="priority">
                                    <option disabled selected>Choose Priority</option>
                                    <option value="HIGH">HIGH</option>
                                    <option value="MEDIUM">MEDIUM</option>
                                    <option value="LOW">LOW</option>
                                </select>
                                @error('priority')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                                @enderror
                            </div>
                            <div class="input-group mb-3">
                            <textarea name="message" id="message" cols="30" rows="10"
                                      class="form-control @error('message') is-invalid @enderror"
                                      placeholder="Your brief message about problem.." required></textarea>
                                @error('message')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                                @enderror
                            </div>
                            <a href="{{ route('tickets.index') }}" class="btn btn-dark">Back</a>
                            <input class="btn btn-primary" type="submit"
                                   onclick="this.form.submit();this.disabled = true;"
                                   value="Open Ticket"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
