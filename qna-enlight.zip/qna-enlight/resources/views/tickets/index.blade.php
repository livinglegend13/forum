@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex flex-row align-items-baseline">
                        <div class="mr-auto">
                            <h3>
                                {{ __('Tickets') }}
                            </h3>
                        </div>
                        <div class="d-flex flex-row align-items-baseline ml-auto">
                            <a href="{{ route('tickets.create') }}" class="btn btn-sm btn-primary mr-2">
                                <i class="fas fa-plus"></i> {{ __('Open Ticket') }}
                            </a>
                            {{ $tickets->links() }}
                        </div>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table table-light table-hover">
                            <thead class="thead-light">
                            <tr>
                                <th># Category</th>
                                <th># Title</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach ($tickets as $ticket)
                                <tr>
                                    <td>
                                        {{ $ticket->category->name }}

                                        <span
                                                class="ml-2 badge badge-sm {{ $ticket->priority === 'HIGH' ? 'badge-danger' : ( $ticket->priority === 'MEDIUM' ? 'badge-warning' : 'badge-success') }}">
                                        {{ $ticket->priority }}
                                    </span>
                                    </td>
                                    <td>
                                        <a href="{{ route('tickets.show', $ticket) }}">
                                            {{ $ticket->title }}
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
