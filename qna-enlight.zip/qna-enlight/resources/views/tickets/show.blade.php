@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex flex-row align-items-baseline">
                        <div class="mr-auto">
                            <h3>
                                {{ $ticket->title }}
                            </h3>
                        </div>
                        <div class="d-flex flex-row align-items-baseline ml-auto">
                            <form action="{{ route('tickets.close', $ticket) }}" method="post">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-success mr-2">
                                    <i class="fas fa-check"></i> {{ __('Mark Resolved') }}
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="card-body">
                        <h5 class="mb-3">
                            {{ __('Category:') }} {{ $ticket->category->name }}
                        </h5>

                        <p class="mb-3">
                        <span
                                class="text-uppercase badge {{ $ticket->priority === 'HIGH' ? 'badge-danger' : ( $ticket->priority === 'MEDIUM' ? 'badge-warning' : 'badge-success') }}">
                            {{ __('Priority:') }}
                            {{ $ticket->priority }}
                        </span>
                            <span
                                    class="text-uppercase badge badge-pill {{ $ticket->status === 'CLOSED' ? 'badge-success' : 'badge-danger' }}">
                            {{ __('Status:') }}
                                {{ $ticket->status }}
                        </span>
                            <span class="text-uppercase">
                            {{ __('Created:') }}
                            <small class="text-muted">
                                {{ $ticket->created_at->diffForHumans() }}
                            </small>
                        </span>
                        </p>

                        <div class="p-4 mb-3 bg-gray">
                            {{ $ticket->message }}
                        </div>

                        @foreach ($comments as $comment)
                            <div class="h4">
                                {{ $comment->user->name}}
                                <small class="muted-text">
                                    commented {{ $comment->created_at->diffForHumans() }}...
                                </small>
                            </div>
                            <div class="p-4 mb-3 bg-gray">{{ $comment->body }}</div>
                        @endforeach

                        <form action="{{ route('comments.store', $ticket)}}" method="POST" class="form">
                            @csrf

                            <div class="input-group mb-3">
                            <textarea id="body" class="form-control @error('body') is-invalid @enderror" name="body"
                                      rows="3" placeholder="What happened??" required>
                                {{ old('body') }}
                            </textarea>
                                @error('body')
                                <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <a href="{{ route('tickets.index') }}" class="btn btn-dark">Back</a>
                                <input class="btn btn-primary" type="submit"
                                       onclick="this.form.submit();this.disabled = true;" value="Submit"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
