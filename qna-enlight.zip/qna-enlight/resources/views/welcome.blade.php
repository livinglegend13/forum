@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <div class="text-center mb-3">
                    <img class="mr-2" src="{{ asset('logo.png') }}"
                         alt="{{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}">
                    <h1 class="font-weight-bold text-uppercase">
                        {{ ($settings->where('key', 'sitename')->pluck('value')->first() ?? 'QnA Enlight') }}
                    </h1>
                </div>


                <h2 class="h4 font-weight-bold text-capitalize">
                    <span class="text-danger">#</span>
                    {{ __('The robust and automatic forum to discuss your questions or ideas.') }}
                </h2>
                <h2 class="h4 font-weight-bold text-capitalize">
                    <span class="text-danger">#</span>
                    {{ __('Fluent support ticket system to serve your clients.') }}
                </h2>
                <h2 class="h4 font-weight-bold">
                    <span class="text-danger">#</span>
                    {{ __('A Progressive Web App That Works Like Android/iOS/Desktop App.') }}
                </h2>
                <div class="text-center mb-3">
                    @foreach ($channels as $channel)
                        <span class="badge">
                    @include('threads._channelButton')
                </span>
                    @endforeach

                    <form method="GET" action="{{ route('threads.search.index') }}" class="mt-3">
                        <div class="sidebar-item sidebar-search">
                            <div class="input-group">
                                <input type="text" name="q" class="form-control search-menu"
                                       placeholder="What is your question?" autocomplete="off">
                                <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                </span>
                                </div>
                            </div>
                        </div>
                    </form>


                </div>
            </div>

            <?php for ($i = 0; $i < 4; $i++) { ?>

            <div class="col-md-8 my-4">
                {!! ($settings->where('key', 'horizontal-ads')->pluck('value')->first() ?? '') !!}
            </div>

            <?php } ?>
        </div>
    </div>
@endsection
