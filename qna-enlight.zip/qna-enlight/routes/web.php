<?php

declare(strict_types=1);

use App\Models\CountReport;
use Illuminate\Support\Facades\Route;

// Route::get('/symlink', function () {
// // symlink('destination', 'target);

// symlink('/home/user_name_of_hosting/qna/public/avatars', '/home/user_name_of_hosting/public_html/avatars');
// symlink('/home/user_name_of_hosting/qna/public/tmp', '/home/user_name_of_hosting/public_html/tmp');
// symlink('/home/user_name_of_hosting/qna/public/apple-touch-icon.png', '/home/user_name_of_hosting/public_html/apple-touch-icon.png');
// symlink('/home/user_name_of_hosting/qna/public/favicon-16x16.png', '/home/user_name_of_hosting/public_html/favicon-16x16.png');
// symlink('/home/user_name_of_hosting/qna/public/favicon-32x32.png', '/home/user_name_of_hosting/public_html/favicon-32x32.png');
// symlink('/home/user_name_of_hosting/qna/public/favicon-48x48.png', '/home/user_name_of_hosting/public_html/favicon-48x48.png');
// symlink('/home/user_name_of_hosting/qna/public/logo-96x96.png', '/home/user_name_of_hosting/public_html/logo-96x96.png');
// symlink('/home/user_name_of_hosting/qna/public/logo-144x144.png', '/home/user_name_of_hosting/public_html/logo-144x144.png');
// symlink('/home/user_name_of_hosting/qna/public/logo-256x256.png', '/home/user_name_of_hosting/public_html/logo-256x256.png');
// symlink('/home/user_name_of_hosting/qna/public/logo-512x512.png', '/home/user_name_of_hosting/public_html/logo-512x512.png');
// symlink('/home/user_name_of_hosting/qna/public/logo.png', '/home/user_name_of_hosting/public_html/logo.png');

// return view('welcome');

// });

Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('sitemap.xml', 'SitemapController@index')->name('sitemap.xml');

Route::get('manifest.json', 'PWAController@manifest');

Route::get('service-worker-register.js', 'PWAController@register');

Route::get('service-worker.js', 'PWAController@serviceWorker');

Route::get('/cache-clear', function () {
    cache()->flush();

    return redirect('/');
});

Route::get('cookie-policy', function () {
    return view('policies.cookie');
})->name('policies.cookie');

Route::get('privacy-policy', function () {
    return view('policies.privacy');
})->name('policies.privacy');

Auth::routes(['verify' => true]);

Route::get('threads', 'ThreadController@index')->name('threads.index');
Route::get('threads/create', 'ThreadController@create')->name('threads.create')->middleware('verified');

Route::get('threads/search', 'SearchController@index')->name('threads.search.index');

Route::get('threads/{channel}/{thread}', 'ThreadController@show')->name('threads.show');
Route::patch('threads/{channel}/{thread}', 'ThreadController@update')->name('threads.update');
Route::delete('threads/{channel}/{thread}', 'ThreadController@destroy')->name('threads.destroy');
Route::post('threads', 'ThreadController@store')->name('threads.store');
Route::get('threads/{channel}', 'ThreadController@index')->name('threads.filterBy.channel.index');

Route::get('threads/{channel}/{thread}/replies', 'ReplyController@index');
Route::post('threads/{channel}/{thread}/replies', 'ReplyController@store');
Route::patch('replies/{reply}', 'ReplyController@update');
Route::delete('replies/{reply}', 'ReplyController@destroy')->name('replies.destroy');

Route::post('replies/{reply}/best', 'BestReplyController@store')->name('best-reply.store');

Route::post('threads/{channel}/{thread}/subscriptions', 'ThreadSubscriptionController@store');
Route::delete('threads/{channel}/{thread}/subscriptions', 'ThreadSubscriptionController@destroy');

Route::post('replies/{reply}/favourites', 'FavouriteController@store');
Route::delete('replies/{reply}/favourites', 'FavouriteController@destroy');

Route::get('profiles', 'ProfileController@index')->name('profiles.index');

Route::get('profiles/{user}', 'ProfileController@show')->name('profiles.show');

Route::patch('profiles/{user}/update', 'ProfileController@update')->name('profiles.update');

Route::patch('profiles/{user}/password', 'ProfileController@password')->name('profiles.password');

Route::get('profiles/{user}/notifications', 'UserNotificationsController@index');
Route::delete('profiles/{user}/notifications/{notification}', 'UserNotificationsController@destroy');

Route::get('api/users', 'Api\UserController@index');

Route::post('api/users/{user}/avatar', 'Api\UserAvatarController@store')->name('avatar.store');

Route::post('upload-files', 'FileUploadController@store')->name('file-upload.store');

Route::get('tickets', 'TicketController@index')->name('tickets.index');
Route::post('tickets', 'TicketController@store')->name('tickets.store');
Route::get('tickets/create', 'TicketController@create')->name('tickets.create');
Route::get('tickets/{ticket}', 'TicketController@show')->name('tickets.show');
Route::post('tickets/{ticket}/close', 'TicketController@close')->name('tickets.close');

Route::post('tickets/{ticket}/comments', 'CommentController@store')->name('comments.store');


Route::group([
    'as' => 'admin.',
    'middleware' => 'roles',
    'roles' => ['admin'],
], function () {
    Route::get('dashboard', 'AdminController@index')->name('dashboard');

    Route::resource('channels', 'ChannelController');

    Route::get('settings', 'SettingController@index')->name('settings.index');

    Route::post('settings/site', 'SettingController@postSite')->name('settings.postSite');

    Route::post('settings/logo', 'SettingController@postLogo')->name('settings.postLogo');

    Route::post('settings/social', 'SettingController@postSocial')->name('settings.postSocial');

    Route::get('api-settings', 'ApiSettingController@index')->name('api-settings.index');

    Route::post('api-settings/recaptcha-keys', 'ApiSettingController@postRecaptchaKeys')->name('api-settings.postRecaptchaKeys');

    Route::post('api-settings/analytics-key', 'ApiSettingController@postAnalyticsKey')->name('api-settings.postAnalyticsKey');

    Route::post('api-settings/onesignal-key', 'ApiSettingController@postOneSignalKey')->name('api-settings.postOneSignalKey');

    Route::post('lock-threads/{thread}', 'LockThreadController@store')->name('lock-threads.store');

    Route::delete('lock-threads/{thread}', 'LockThreadController@destroy')->name('lock-threads.destroy');

    Route::get('google-adsense', 'GoogleAdsenseController@index')->name('google-adsense.index');
    Route::post('google-adsense-square', 'GoogleAdsenseController@postGoogleAdsenseSquare')->name('google-adsense.postGoogleAdsenseSquare');
    Route::post('google-adsense-horizontal', 'GoogleAdsenseController@postGoogleAdsenseHorizontal')->name('google-adsense.postGoogleAdsenseHorizontal');
    Route::post('google-adsense-vertical', 'GoogleAdsenseController@postGoogleAdsenseVertical')->name('google-adsense.postGoogleAdsenseVertical');

    Route::get('api/counts-report', function () {
        return 	CountReport::currentMonth()->orderBy('created_at')->get();
    })->name('api.counts-report');

    Route::resource('categories', 'CategoryController', ['as' => 'ticket']);
});
