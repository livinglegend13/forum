<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AddAvatarTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function only_members_can_add_avatars()
    {
        $this->withExceptionHandling();

        $this->json('post', 'api/users/john/avatar')
            ->assertStatus(401);
    }

    /** @test */
    public function a_valid_avatar_must_be_provided()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->json('post', route('avatar.store', auth()->user()), [
            'avatar' => 'not-an-image',
        ])
            ->assertStatus(422);
    }

    /** @test */
    public function a_user_may_add_an_avatar_to_their_profile()
    {
        $this->signIn();

        $this->json('POST', route('avatar.store', auth()->user()), [
            'avatar' => $file = UploadedFile::fake()->image('avatar.png'),
        ]);

        $this->assertEquals(asset('avatars/' . $file->hashName()), auth()->user()->fresh()->avatar);

        Storage::disk('test')->assertExists('avatars/' . $file->hashName());
    }

    /** @test */
    public function a_user_may_not_add_an_avatar_to_others_profile()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $another_user = create(User::class);

        $this->json('POST', route('avatar.store', $another_user), [
            'avatar' => UploadedFile::fake()->image('avatar.png'),
        ])->assertStatus(403);
    }

    /** @test */
    public function an_admin_may_add_an_avatar_to_any_users_profile()
    {
        $user = create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $user->roles()->attach($admin_role);

        $this->signIn($user);

        $another_user = create(User::class);

        $this->json('POST', route('avatar.store', $another_user), [
            'avatar' => $file = UploadedFile::fake()->image('avatar.png'),
        ]);

        $this->assertEquals(asset('avatars/' . $file->hashName()), $another_user->fresh()->avatar);

        Storage::disk('test')->assertExists('avatars/' . $file->hashName());
    }
}
