<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ApiSettingsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->signIn($this->user);
    }

    /** @test */
    public function it_requires_recaptcha_key_and_secret()
    {
        $this->withExceptionHandling();

        $this->post(route('admin.api-settings.postRecaptchaKeys', [
            'recaptcha_secret' => 'sdfsdfsdf',
        ]))
            ->assertSessionHasErrors('recaptcha_key');

        $this->post(route('admin.api-settings.postRecaptchaKeys', [
            'recaptcha_key' => 'sdfsdfdf',
        ]))
            ->assertSessionHasErrors('recaptcha_secret');
    }

    /** @test */
    public function it_stores_google_recaptcha_keys()
    {
        $response = $this->post(route('admin.api-settings.postRecaptchaKeys', [
            'recaptcha_key' => 'sdf',
            'recaptcha_secret' => 'sdf',
        ]));

        $response->assertStatus(302)
            ->assertSessionHas('flash', 'Recaptcha Settings Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'recaptcha_key',
            'value' => 'sdf',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'recaptcha_secret',
            'value' => 'sdf',
        ]);
    }

    /** @test */
    public function it_requires_analytics_key()
    {
        $this->withExceptionHandling();

        $this->post(route('admin.api-settings.postAnalyticsKey'))
            ->assertSessionHasErrors('analytics_key');
    }

    /** @test */
    public function it_stores_google_anaylytics_key()
    {
        $response = $this->post(route('admin.api-settings.postAnalyticsKey', [
            'analytics_key' => 'sdf',
        ]));

        $response->assertStatus(302)
            ->assertSessionHas('flash', 'Google Analytics Settings Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'analytics_key',
            'value' => 'sdf',
        ]);
    }

    /** @test */
    public function it_requires_onesignal_key()
    {
        $this->withExceptionHandling();

        $this->post(route('admin.api-settings.postOneSignalKey'))
            ->assertSessionHasErrors('onesignal_key');
    }

    /** @test */
    public function it_stores_onesignal_key()
    {
        $response = $this->post(route('admin.api-settings.postOneSignalKey', [
            'onesignal_key' => 'sdf',
        ]));

        $response->assertStatus(302)
            ->assertSessionHas('flash', 'OneSignal Settings Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'onesignal_key',
            'value' => 'sdf',
        ]);
    }
}
