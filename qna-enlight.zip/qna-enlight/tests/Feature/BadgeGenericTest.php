<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Achievements\Badge;
use Illuminate\Foundation\Testing\RefreshDatabase;

class BadgeGenericTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_badge_can_be_given_to_a_user()
    {
        $user = create(User::class);

        $badge = create(Badge::class);

        $badge->awardTo($user);

        $this->assertCount(1, $user->badges);

        $this->assertTrue($user->badges->first()->is($badge));
    }

    /** @test */
    public function a_badge_can_be_removed_from_a_user()
    {
        $user = create(User::class);

        $badge = create(Badge::class);

        $badge->awardTo($user);

        $this->assertCount(1, $user->badges);

        $badge->removeFrom($user);

        $this->assertCount(0, $user->fresh()->badges);
    }

    /** @test */
    public function a_badge_is_removed_if_user_contributor_points_are_reduced()
    {
        $user = create(User::class);

        $this->assertCount(0, $user->badges);

        $user->addPoint($minimumPointsForBadge = 2);

        $this->assertCount(1, $user->fresh()->badges);

        $user->reducePoint(2);

        $this->assertCount(0, $user->fresh()->badges);
    }
}
