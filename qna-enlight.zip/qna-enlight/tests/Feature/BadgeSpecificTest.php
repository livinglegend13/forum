<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Achievements\Badge;
use Illuminate\Foundation\Testing\RefreshDatabase;

class BadgeSpecificTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);
    }

    /** @test */
    public function a_badge_is_awarded_if_user_contributes_for_the_first_time()
    {
        $badge = create(Badge::class, [
            'name' => 'First Contribution',
        ]);

        $this->user->addPoint($minimumPointsForBadge = 2);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function a_badge_is_awarded_if_user_point_reached_fifty()
    {
        $badge = create(Badge::class, [
            'name' => 'Fifty Reputation Points',
        ]);

        $this->user->addPoint(51);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function a_badge_is_awarded_if_user_point_reached_hundred()
    {
        $badge = create(Badge::class, [
            'name' => 'Hundred Reputation Points',
        ]);

        $this->user->addPoint(101);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function a_badge_is_awarded_if_user_point_reached_five_hundred()
    {
        $badge = create(Badge::class, [
            'name' => 'Five Hundred Reputation Points',
        ]);

        $this->user->addPoint(501);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function a_badge_is_awarded_if_user_point_reached_thousand()
    {
        $badge = create(Badge::class, [
            'name' => 'Thousand Reputation Points',
        ]);

        $this->user->addPoint(1001);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function a_badge_is_awarded_if_user_point_reached_five_thousand()
    {
        $badge = create(Badge::class, [
            'name' => 'Five Thousand Reputation Points',
        ]);

        $this->user->addPoint(5001);

        $this->assertTrue($this->user->fresh()->hasBadge($badge));
    }
}
