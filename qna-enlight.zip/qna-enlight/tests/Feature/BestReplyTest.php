<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use Illuminate\Foundation\Testing\RefreshDatabase;

class BestReplyTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_thread_creator_may_mark_any_reply_as_the_best_reply()
    {
        $this->signIn();

        $thread = create(Thread::class, ['user_id' => auth()->id()]);

        $replies = create(Reply::class, ['thread_id' => $thread->id], 2);

        $this->postJson(route('best-reply.store', $replies[1]->id));

        $this->assertTrue($replies[1]->fresh()->isBest());
    }

    /** @test */
    public function only_a_thread_creator_may_mark_any_reply_as_the_best_reply()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $thread = create(Thread::class, ['user_id' => auth()->id()]);

        $replies = create(Reply::class, ['thread_id' => $thread->id], 2);

        $this->signIn(create(User::class));

        $this->postJson(route('best-reply.store', $replies[1]->id))->assertStatus(403);

        $this->assertFalse($replies[1]->fresh()->isBest());
    }

    /** @test */
    public function if_a_best_reply_is_deleted_then_thread_is_properly_updated_to_reflect_that()
    {
        $this->signIn();

        $reply = create(Reply::class, ['user_id' => auth()->id()]);

        $reply->thread->markBestReply($reply);

        $this->deleteJson(route('replies.destroy', $reply));

        $this->assertNull($reply->thread->fresh()->best_reply_id);
    }

    /** @test */
    public function admin_may_mark_any_reply_as_the_best_reply()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $admin = create(User::class);

        $admin->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->signIn($admin);

        $user = create(User::class);

        $thread = create(Thread::class, ['user_id' => $user->id]);

        $replies = create(Reply::class, ['thread_id' => $thread->id], 2);

        $this->postJson(route('best-reply.store', $replies[1]->id));

        $this->assertTrue($replies[1]->fresh()->isBest());
    }
}
