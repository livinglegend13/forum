<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Channel;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ChannelsRoutesTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $this->signIn($this->user);
    }

    /** @test */
    public function normal_user_may_not_access_channels_store()
    {
        $this->withExceptionHandling()
            ->post('/channels')
            ->assertStatus(401);
    }

    /** @test */
    public function normal_user_may_not_access_channels_index()
    {
        $this->withExceptionHandling()
            ->get('/channels')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_channel_index()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get('/channels')
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_channels_create()
    {
        $this->withExceptionHandling()
            ->get('/channels/create')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_channel_create()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get('/channels/create')
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_channels_destroy()
    {
        $channel = create(Channel::class);

        $this->withExceptionHandling()
            ->delete('/channels/' . $channel->slug)
            ->assertStatus(401);
    }

    /** @test */
    public function normal_user_may_not_access_channels_update()
    {
        $channel = create(Channel::class);

        $this->withExceptionHandling()
            ->put('/channels/' . $channel->slug)
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_channel_update()
    {
        $channel = create(Channel::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get(route('admin.channels.update', $channel->slug))
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_channels_show()
    {
        $channel = create(Channel::class);

        $this->withExceptionHandling()
            ->get('/channels/' . $channel->slug)
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_channel_show()
    {
        $channel = create(Channel::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get('/channels/' . $channel->slug)
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_channels_edit()
    {
        $channel = create(Channel::class);

        $this->withExceptionHandling()
            ->get('/channels/' . $channel->slug . '/edit')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_channel_edit()
    {
        $channel = create(Channel::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get('/channels/' . $channel->slug . '/edit')
            ->assertStatus(200);
    }
}
