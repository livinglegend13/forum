<?php

declare(strict_types=1);

namespace Tests\Feature;

use Carbon\Carbon;
use Tests\TestCase;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use App\Rules\Recaptcha;
use App\Models\CountReport;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CountsReportTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_records_counts_of_new_user_registered_on_daily_basis()
    {
        $user = [
            'name' => 'Joe',
            'username' => 'joe',
            'email' => 'testemail@test.com',
            'password' => 'passwordtest',
            'password_confirmation' => 'passwordtest',
        ];

        $this->post(route('register', $user));

        $this->assertDatabaseHas('users', ['name' => $user['name']]);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->fresh()->users_count);
    }

    /** @test */
    public function it_records_counts_of_threads_created_on_daily_basis()
    {
        app()->singleton(Recaptcha::class, function () {
            return \Mockery::mock(Recaptcha::class, function ($m) {
                $m->shouldReceive('passes')->andReturn(true);
            });
        });

        $this->signIn();

        $thread = make(Thread::class);

        $this->post('/threads', $thread->toArray() + ['recaptcha_response' => 'token']);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->fresh()->threads_count);
    }

    /** @test */
    public function it_records_counts_of_replies_created_on_daily_basis()
    {
        $user = create(User::class);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->users_count);

        $this->signIn($user);

        $thread = create(Thread::class, ['user_id' => $user->id]);

        $this->post($thread->path() . '/replies', ['body' => 'some body']);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->replies_count);
    }

    /** @test */
    public function it_decrements_counts_of_reply_if_reply_is_deleted()
    {
        $reply = create(Reply::class);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->replies_count);

        $reply->delete();

        $this->assertEquals(0, $countReport->fresh()->replies_count);
    }

    /** @test */
    public function it_decrements_counts_of_thread_if_thread_is_deleted()
    {
        $thread = create(Thread::class);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->threads_count);

        $thread->delete();

        $this->assertEquals(0, $countReport->fresh()->threads_count);
    }

    /** @test */
    public function it_decrements_replies_and_thread_if_thread_is_deleted()
    {
        $reply = create(Reply::class);

        $countReport = CountReport::whereDate('created_at', Carbon::today())
            ->first();

        $this->assertEquals(1, $countReport->threads_count);
        $this->assertEquals(1, $countReport->replies_count);

        $reply->thread->delete();

        $this->assertEquals(0, $countReport->fresh()->replies_count);
        $this->assertEquals(0, $countReport->fresh()->threads_count);
    }
}
