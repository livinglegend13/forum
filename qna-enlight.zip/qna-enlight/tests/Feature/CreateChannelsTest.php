<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Channel;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CreateChannelsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user = create(User::class);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->signIn($this->user);
    }

    /** @test */
    public function a_channel_requires_a_name()
    {
        $channel = make(Channel::class, ['name' => null]);

        $this->post(route('admin.channels.store', $channel->toArray()))
                ->assertSessionHasErrors('name');
    }

    /** @test */
    public function a_channel_requires_a_unique_name()
    {
        create(Channel::class, ['name' => 'john']);

        $channel = make(Channel::class, ['name' => 'john']);

        $this->post(route('admin.channels.store', $channel->toArray()))
                ->assertSessionHasErrors('name');
    }

    /** @test */
    public function a_channel_requires_a_font_awesome_classes()
    {
        $channel = make(Channel::class, ['font_awesome_classes' => null]);

        $this->post(route('admin.channels.store', $channel->toArray()))
                ->assertSessionHasErrors('font_awesome_classes');
    }

    /** @test */
    public function an_admin_can_create_channel()
    {
        $this->withoutExceptionHandling();

        $channel = make(Channel::class);

        $response = $this->postJson(route('admin.channels.store', $channel->toArray()));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Channel Created Successfully');

        $this->assertDatabaseHas('channels', [
            'name' => $channel->name,
            'font_awesome_classes' => $channel->font_awesome_classes,
        ]);
    }

    /** @test */
    public function an_admin_can_delete_channel_ie_automatically_deletes_threads_and_replies_associated_too()
    {
        $channel = create(Channel::class);

        $this->delete(route('admin.channels.destroy', $channel))
        ->assertStatus(302)
        ->assertSessionHas('flash', 'Channel Deleted Successfully');

        $this->assertDatabaseMissing('channels', [
            'id' => $channel->id,
        ]);
    }
}
