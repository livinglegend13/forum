<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use App\Models\Channel;
use App\Models\Activity;
use App\Rules\Recaptcha;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CreateThreadsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        app()->singleton(Recaptcha::class, function () {
            return  \Mockery::mock(Recaptcha::class, function ($m) {
                $m->shouldReceive('passes')->andReturn(true);
            });
        });
    }

    /** @test */
    public function guest_may_not_create_thread()
    {
        $this->withExceptionHandling()
            ->get('/threads/create')
            ->assertRedirect('/login');

        $this->post('/threads')
            ->assertRedirect('/login');
    }

    /** @test */
    public function an_authenticated_user_can_create_new_forum_thread()
    {
        $this->signIn();

        $thread = make(Thread::class);

        $response = $this->post('/threads', $thread->toArray() + ['recaptcha_response' => 'token']);

        $this->get($response->headers->get('Location'))
            ->assertSee($thread->title)
            ->assertSee($thread->body);
    }

    /** @test */
    public function a_thread_requires_a_title()
    {
        $this->publishThread(['title' => null])
        ->assertSessionHasErrors('title');
    }

    /** @test */
    public function a_thread_requires_a_body()
    {
        $this->publishThread(['body' => null])
        ->assertSessionHasErrors('body');
    }

    /** @test */
    public function a_thread_requires_a_recaptcha_verification_still_if_no_recaptcha_secret_is_provided()
    {
        unset(app()[Recaptcha::class]);

        $this->publishThread(['recaptcha_response' => 'test'])
        ->assertSessionHasErrors('recaptcha_response');
    }

    /** @test */
    public function a_thread_requires_a_recaptcha_verification_with_recaptcha_secret_provided()
    {
        $this->seed(\Database\Seeders\RecaptchaKeySeeder::class);

        unset(app()[Recaptcha::class]);

        $this->publishThread(['recaptcha_response' => 'test'])
        ->assertSessionHasErrors('recaptcha_response');
    }

    /** @test */
    public function a_thread_requires_a_unique_slug()
    {
        $this->signIn();

        $thread = create(Thread::class, ['title' => 'Foo Title']);

        $responseThread = $this->postJson(route('threads.store'), $thread->toArray() + ['recaptcha_response' => 'token'])->json();

        $this->assertEquals('foo-title-' . $responseThread['id'], $responseThread['slug']);
    }

    /** @test */
    public function a_thread_title_ending_with_number_should_have_proper_slug()
    {
        $this->signIn();

        $thread = create(Thread::class, ['title' => 'Foo Title 24']);

        $responseThread = $this->postJson(route('threads.store'), $thread->toArray() + ['recaptcha_response' => 'token'])->json();

        $this->assertEquals('foo-title-24-' . $responseThread['id'], $responseThread['slug']);
    }

    /** @test */
    public function a_thread_requires_a_valid_channel()
    {
        create(Channel::class, [], 2);

        $this->publishThread(['channel_id' => null])
        ->assertSessionHasErrors('channel_id');

        $this->publishThread(['channel_id' => 999])
        ->assertSessionHasErrors('channel_id');
    }

    /** @test */
    public function unauthorized_users_may_not_delete_threads()
    {
        $this->withExceptionHandling();

        $thread = create(Thread::class);

        $this->delete($thread->path())
        ->assertRedirect('/login');

        $this->signIn();

        $this->delete($thread->path())
        ->assertStatus(403);
    }

    /** @test */
    public function authorized_users_can_delete_threads()
    {
        $this->signIn();

        $thread = create(Thread::class, ['user_id' => auth()->id()]);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $this->json('DELETE', $thread->path())
        ->assertStatus(204);

        $this->assertDatabaseMissing('threads', ['id' => $thread->id]);

        $this->assertDatabaseMissing('replies', ['id' => $reply->id]);

        $this->assertEquals(0, Activity::count());
    }

    /** @test */
    public function admin_users_can_delete_any_thread()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $admin = create(User::class, ['username' => 'admin']);

        $admin->roles()->attach($admin_role);

        $this->signIn($admin);

        $user = create(User::class);

        $thread = create(Thread::class, ['user_id' => $user->id]);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $this->json('DELETE', $thread->path())
        ->assertStatus(204);

        $this->assertDatabaseMissing('threads', ['id' => $thread->id]);

        $this->assertDatabaseMissing('replies', ['id' => $reply->id]);

        $this->assertEquals(0, Activity::count());
    }

    public function publishThread($overrides = [])
    {
        $this->withExceptionHandling()->signIn();

        $thread = make(Thread::class, $overrides);

        return $this->post('/threads', $thread->toArray());
    }
}
