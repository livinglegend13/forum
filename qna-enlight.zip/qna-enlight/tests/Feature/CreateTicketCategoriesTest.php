<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CreateTicketCategoriesTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->withExceptionHandling()
            ->signInAsAdmin();
    }

    /** @test */
    public function a_category_requires_a_name()
    {
        $this->post(route('admin.ticket.categories.store', ['name' => null]))
                ->assertSessionHasErrors('name');
    }

    /** @test */
    public function an_admin_can_create_category()
    {
        $category = make(Category::class);

        $response = $this->postJson(route('admin.ticket.categories.store', $category->toArray()));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Ticket category saved successfully');

        $this->assertDatabaseHas('categories', [
            'name' => $category->name,
        ]);
    }

    /** @test */
    public function an_admin_can_delete_category()
    {
        $category = create(Category::class);

        $this->delete(route('admin.ticket.categories.destroy', $category))
        ->assertStatus(302)
        ->assertSessionHas('flash', 'Ticket category deleted successfully');

        $this->assertDatabaseMissing('categories', [
            'id' => $category->id,
        ]);
    }
}
