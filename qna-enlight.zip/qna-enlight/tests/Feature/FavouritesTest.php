<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Reply;
use Illuminate\Foundation\Testing\RefreshDatabase;

class FavouritesTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function guest_can_not_favourite_reply()
    {
        $reply = create(Reply::class);

        $this->withExceptionHandling()
            ->post('replies/' . $reply->id . '/favourites')
            ->assertRedirect('/login');
    }

    /** @test */
    public function an_authenticated_user_can_favourite_any_reply()
    {
        $this->signIn();

        $reply = create(Reply::class);

        $this->post('replies/' . $reply->id . '/favourites');

        $this->assertCount(1, $reply->favourites);
    }

    /** @test */
    public function an_authenticated_user_can_unfavourite_any_reply()
    {
        $this->signIn();

        $reply = create(Reply::class);

        $reply->favourite();

        $this->delete('replies/' . $reply->id . '/favourites');

        $this->assertCount(0, $reply->favourites);
    }

    /** @test */
    public function an_authenticated_user_can_favourite_any_reply_once()
    {
        $this->signIn();

        $reply = create(Reply::class);

        try {
            $this->post('replies/' . $reply->id . '/favourites');

            $this->post('replies/' . $reply->id . '/favourites');
        } catch (\Exception $e) {
            $this->fail('Did not expect to insert the same record twice.');
        }

        $this->assertCount(1, $reply->favourites);
    }
}
