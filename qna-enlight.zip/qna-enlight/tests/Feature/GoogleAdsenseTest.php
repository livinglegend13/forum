<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class GoogleAdsenseTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->withExceptionHandling();

        $this->signInAsAdmin();
    }

    /** @test */
    public function it_requires_square_ads_code()
    {
        $this->post(route('admin.google-adsense.postGoogleAdsenseSquare'), ['square' => null])
                ->assertSessionHasErrors('square');
    }

    /** @test */
    public function it_stores_google_square_ads()
    {
        $response = $this->post(route('admin.google-adsense.postGoogleAdsenseSquare', [
            'square' => 'sdf',
        ]));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Square ads Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'square-ads',
            'value' => 'sdf',
        ]);
    }

    /** @test */
    public function it_requires_horizontal_ads_code()
    {
        $this->post(route('admin.google-adsense.postGoogleAdsenseHorizontal'), ['horizontal' => null])
                ->assertSessionHasErrors('horizontal');
    }

    /** @test */
    public function it_stores_google_horizontal_ads()
    {
        $response = $this->post(route('admin.google-adsense.postGoogleAdsenseHorizontal', [
            'horizontal' => 'sdf',
        ]));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Horizontal ads Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'horizontal-ads',
            'value' => 'sdf',
        ]);
    }

    /** @test */
    public function it_requires_vertical_ads_code()
    {
        $this->post(route('admin.google-adsense.postGoogleAdsenseVertical'), ['vertical' => null])
                ->assertSessionHasErrors('vertical');
    }

    /** @test */
    public function it_stores_google_vertical_ads()
    {
        $response = $this->post(route('admin.google-adsense.postGoogleAdsenseVertical', [
            'vertical' => 'sdf',
        ]));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Vertical ads Updated Successfully');

        $this->assertDatabaseHas('settings', [
            'key' => 'vertical-ads',
            'value' => 'sdf',
        ]);
    }
}
