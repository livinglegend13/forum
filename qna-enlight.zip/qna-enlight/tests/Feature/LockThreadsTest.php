<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Thread;
use Illuminate\Foundation\Testing\RefreshDatabase;

class LockThreadsTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function non_administrator_can_not_lock_threads()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $thread = create(Thread::class, ['user_id' => auth()->id()]);

        $this->post(route('admin.lock-threads.store', $thread))->assertStatus(401);

        $this->assertFalse($thread->fresh()->locked);
    }

    /** @test */
    public function non_administrator_can_not_unlock_threads()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $thread = create(Thread::class, ['user_id' => auth()->id()]);

        $this->delete(route('admin.lock-threads.destroy', $thread))->assertStatus(401);

        $this->assertFalse($thread->fresh()->locked);
    }

    /** @test */
    public function an_administrator_can_lock_thread()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $user = create(User::class);

        $user->roles()->attach($admin_role);

        $this->signIn($user);

        $thread = create(Thread::class);

        $this->post(route('admin.lock-threads.store', $thread));

        $this->assertTrue($thread->fresh()->locked);
    }

    /** @test */
    public function an_administrator_can_unlock_thread()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $user = create(User::class);

        $user->roles()->attach($admin_role);

        $this->signIn($user);

        $thread = create(Thread::class);

        $thread->lock();

        $this->delete(route('admin.lock-threads.destroy', $thread));

        $this->assertFalse($thread->fresh()->locked);
    }

    /** @test */
    public function once_locked_a_thread_may_not_receive_new_replies()
    {
        $this->signIn();

        $thread = create(Thread::class);

        $thread->lock();

        $this->post($thread->path() . '/replies', [
            'body' => 'Foobar',
            'user_id' => auth()->id(),
        ])->assertStatus(403);
    }
}
