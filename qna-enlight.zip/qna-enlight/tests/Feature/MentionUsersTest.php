<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use Illuminate\Foundation\Testing\RefreshDatabase;

class MentionUsersTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function mentioned_users_in_a_reply_are_notified()
    {
        $john = create(User::class, ['username' => 'JohnDoe']);

        $this->signIn($john);

        $jane = create(User::class, ['username' => 'JaneDoe']);

        $thread = create(Thread::class);

        $reply = make(Reply::class, [
            'body' => 'hello @JaneDoe and @frankDoe',
        ]);

        $this->json('post', $thread->path() . '/replies', $reply->toArray());

        $this->assertCount(1, $jane->notifications);
    }

    /** @test */
    public function it_can_fetch_all_metionable_users_starting_with_given_characters()
    {
        create(User::class, ['username' => 'johndoe']);

        create(User::class, ['username' => 'johndoe1']);

        create(User::class, ['username' => 'janedoe']);

        $response = $this->json('GET', '/api/users', ['username' => 'john']);

        $this->assertCount(2, $response->json('data'));
    }
}
