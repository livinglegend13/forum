<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ParticipateInThreadTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function an_authenticated_user_may_participate_in_forum_threads()
    {
        $this->signIn();

        $thread = create(Thread::class);

        $reply = create(Reply::class);

        $this->post($thread->path() . '/replies', $reply->toArray());

        $this->assertDatabaseHas('replies', ['body' => $reply->body]);

        $this->assertEquals(1, $thread->fresh()->replies_count);
    }

    /** @test */
    public function unauthenticated_users_may_not_add_replies()
    {
        $this->withExceptionHandling()
            ->post('threads/channel/1/replies', [])
            ->assertRedirect('/login');
    }

    /** @test */
    public function a_reply_requires_body()
    {
        $this->withExceptionHandling()->signIn();

        $thread = create(Thread::class);
        $reply = make(Reply::class, ['body' => null]);

        $this->post($thread->path() . '/replies', $reply->toArray())
            ->assertSessionHasErrors('body');
    }

    /** @test */
    public function unauthorised_users_cannot_delete_replies()
    {
        $this->withExceptionHandling();

        $reply = create(Reply::class);

        $this->delete("/replies/{$reply->id}")
            ->assertRedirect('/login');

        $this->signIn()
            ->delete("/replies/{$reply->id}")
            ->assertStatus(403);
    }

    /** @test */
    public function authorised_users_can_only_delete_threir_own_replies()
    {
        $this->withExceptionHandling()
            ->signIn();

        $reply = create(Reply::class, ['user_id' => auth()->id()]);

        $another_user = create(User::class);

        $reply_of_another_user = create(Reply::class, ['user_id' => $another_user->id]);

        $this->delete("/replies/{$reply->id}")->assertStatus(200);

        $this->delete("/replies/{$reply_of_another_user->id}")->assertStatus(403);

        $this->assertDatabaseMissing('replies', ['id' => $reply->id]);

        $this->assertEquals(0, $reply->thread->fresh()->replies_count);
    }

    /** @test */
    public function admin_users_can_delete_any_reply()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $admin = create(User::class);

        $admin->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->signIn($admin);

        $user = create(User::class);

        $reply = create(Reply::class, ['user_id' => $user->id]);

        $this->delete("/replies/{$reply->id}")->assertStatus(200);

        $this->assertDatabaseMissing('replies', ['id' => $reply->id]);

        $this->assertEquals(0, $reply->thread->fresh()->replies_count);
    }

    /** @test */
    public function unauthorised_users_cannot_update_replies()
    {
        $this->withExceptionHandling();

        $reply = create(Reply::class);

        $this->patch("/replies/{$reply->id}")
            ->assertRedirect('/login');

        $this->signIn()
            ->patch("/replies/{$reply->id}")
            ->assertStatus(403);
    }

    /** @test */
    public function authorised_users_can_only_update_their_own_replies()
    {
        $this->withExceptionHandling()
            ->signIn();

        $reply = create(Reply::class, ['user_id' => auth()->id()]);

        $updatedReply = 'You have been changed, Fool !!';

        $this->patch("/replies/{$reply->id}", ['body' => $updatedReply]);

        $this->assertDatabaseHas('replies', ['body' => $updatedReply]);

        $another_user = create(User::class);

        $reply_of_another_user = create(Reply::class, ['user_id' => $another_user->id]);

        $this->patch("/replies/{$reply_of_another_user->id}", ['body' => $updatedReply])
            ->assertStatus(403);
    }

    /** @test */
    public function admin_users_can_update_any_reply()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $admin = create(User::class);

        $admin->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->signIn($admin);

        $user = create(User::class);

        $reply = create(Reply::class, ['user_id' => $user->id]);

        $updatedReply = 'You have been changed, Fool !!';

        $this->patch("/replies/{$reply->id}", ['body' => $updatedReply]);

        $this->assertDatabaseHas('replies', ['body' => $updatedReply]);
    }

    /** @test */
    public function a_user_may_reply_maximum_of_once_per_minute()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $thread = create(Thread::class);

        $reply = [
            'body' => 'some-body',
        ];

        $this->json('post', $thread->path() . '/replies', $reply)
            ->assertStatus(201);

        $this->json('post', $thread->path() . '/replies', $reply)
            ->assertStatus(429);
    }
}
