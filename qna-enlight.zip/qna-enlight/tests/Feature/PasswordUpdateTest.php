<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class PasswordUpdateTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_requires_current_password_for_updating_new_password()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->patch(route('profiles.password', auth()->user()), [
            'current_password' => null,
            'password' => 'johndoe',
        ])
            ->assertSessionHasErrors('current_password');
    }

    /** @test */
    public function it_requires_new_password_for_updating_new_password()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->patch(route('profiles.password', auth()->user()), [
            'current_password' => 'sdf',
            'password' => null,
        ])
            ->assertSessionHasErrors('password');
    }

    /** @test */
    public function it_requires_validate_current_password_authenticity()
    {
        $this->withExceptionHandling();

        $current_password = bcrypt('password');

        $user = create(User::class, [
            'password' => $current_password,
        ]);

        $this->signIn($user);

        $this->patch(route('profiles.password', auth()->user()), [
            'current_password' => 'wrongPassword',
            'password' => 'newpassword',
            'password_confirmation' => 'newpassword',
        ])
            ->assertSessionHasErrors('current_password');
    }

    /** @test */
    public function unauthorised_user_cannot_update_user_password()
    {
        $this->withExceptionHandling();

        $user = create(User::class);

        $this->signIn();

        $this->patch(route('profiles.password', $user), [])->assertStatus(403);
    }

    /** @test */
    public function authorised_user_can_update_its_password()
    {
        $current_password = bcrypt('password');

        $user = create(User::class, [
            'password' => $current_password,
        ]);

        $this->signIn($user);

        $response = $this->patch(route('profiles.password', $user), [
            'current_password' => 'password',
            'password' => 'newpassword',
            'password_confirmation' => 'newpassword',
        ]);

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Password Updated Successfully');

        $this->assertTrue(\Hash::check('newpassword', $user->fresh()->password));
    }
}
