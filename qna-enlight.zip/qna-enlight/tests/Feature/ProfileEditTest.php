<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ProfileEditTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_requires_name_to_update()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->patch(route('profiles.update', auth()->user()), [
            'name' => null,
            'email' => 'john@test.com',
        ])
            ->assertSessionHasErrors('name');
    }

    /** @test */
    public function it_requires_email_to_update()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->patch(route('profiles.update', auth()->user()), [
            'name' => 'johndoe',
            'email' => null,
        ])
            ->assertSessionHasErrors('email');
    }

    /** @test */
    public function unauthorised_user_cannot_update_user_profile_info()
    {
        $this->withExceptionHandling();

        $user = create(User::class);

        $this->signIn();

        $this->patch(route('profiles.update', $user), [])->assertStatus(403);
    }

    /** @test */
    public function authorised_user_can_update_its_user_profile_info()
    {
        $user = create(User::class);

        $this->signIn($user);

        $response = $this->patch(route('profiles.update', $user), [
            'name' => 'johndoe',
            'email' => 'john@test.com',
        ]);

        $response->assertStatus(302)
            ->assertSessionHas('flash', 'User Profile Updated Successfully');

        $this->assertDatabaseHas('users', [
            'name' => 'johndoe',
            'email' => 'john@test.com',
        ]);
    }
}
