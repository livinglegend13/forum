<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Thread;
use Illuminate\Support\Str;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ProfilesTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function user_has_a_profile()
    {
        $user = create(User::class);

        $this->get('/profiles/' . $user->username)
            ->assertSee($user->name);
    }

    /** @test */
    public function profiles_display_all_threads_created_by_the_associated_user()
    {
        $this->signIn();

        $thread = create(Thread::class, [
            'title' => 'some-title',
            'user_id' => auth()->id(),
        ]);

        $this->get('/profiles/' . auth()->user()->username)
            ->assertSee(Str::limit(strip_tags($thread->title), 50));
    }

    /** @test */
    public function it_shows_top_fifty_profiles_according_to_the_reputation_points_earned()
    {
        create(User::class, [], 70);

        $sortUsers = User::orderBy('reputation', 'desc')->pluck('username')->take(50)->toArray();

        $this->get(route('profiles.index'))
            ->assertSeeTextInOrder($sortUsers);
    }
}
