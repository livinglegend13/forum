<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use App\Models\Channel;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ReadThreadsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->thread = create(Thread::class);
    }

    /** @test */
    public function a_user_can_browse_all_threads()
    {
        $this->get('/threads')
        ->assertSee($this->thread->title);
    }

    /** @test */
    public function a_user_can_read_a_single_threads()
    {
        $this->get($this->thread->path())
        ->assertSee($this->thread->title);
    }

    /** @test */
    public function a_user_can_read_replies_that_are_associated_with_the_thread()
    {
        $reply = Reply::factory()->create(['thread_id' => $this->thread->id]);

        $this->assertDatabaseHas('replies', ['body' => $reply->body]);
    }

    /** @test */
    public function a_user_can_filter_threads_according_to_a_channel()
    {
        $channel = create(Channel::class);

        $threadInChannel = create(Thread::class, ['channel_id' => $channel->id]);

        $threadNotInChannel = create(Thread::class);

        $this->get('/threads/' . $channel->slug)
        ->assertSee($threadInChannel->title)
        ->assertDontSee($threadNotInChannel);
    }

    /** @test */
    public function a_user_can_filter_threads_by_any_username()
    {
        $this->signIn(create(User::class, ['username' => 'JohnDoe']));

        $threadsByJohn = create(Thread::class, ['user_id' => auth()->id()]);

        $this->get('/threads?by=JohnDoe')
        ->assertSee($threadsByJohn->title);
    }

    /** @test */
    public function a_user_can_filter_threads_by_popularity()
    {
        $threadWithTwoReplies = create(Thread::class);
        create(Reply::class, ['thread_id' => $threadWithTwoReplies->id], 2);

        $threadWithThreeReplies = create(Thread::class);
        create(Reply::class, ['thread_id' => $threadWithThreeReplies->id], 3);

        $threadWithNoReplies = $this->thread;

        $response = $this->getJson('threads?popular=1')->json();

        $this->assertEquals([3, 2, 0], array_column($response, 'replies_count'));
    }

    /** @test */
    public function a_user_can_filter_threads_by_those_which_are_unanswered()
    {
        $thread = create(Thread::class);

        create(Reply::class, ['thread_id' => $thread->id]);

        $response = $this->getJson('threads?unanswered=1')->json();

        $this->assertCount(1, $response);
    }

    /** @test */
    public function a_user_can_filter_threads_by_those_which_are_solved()
    {
        $thread = create(Thread::class);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $thread->markBestReply($reply);

        $response = $this->getJson('threads?solved=1')->json();

        $this->assertCount(1, $response);
    }

    /** @test */
    public function a_user_can_filter_threads_by_those_which_are_unsolved()
    {
        create(Thread::class, [], 2);

        $reply = create(Reply::class, ['thread_id' => $this->thread->id]);

        $this->thread->markBestReply($reply);

        $response = $this->getJson('threads?unsolved=1')->json();

        $this->assertCount(2, $response);
    }

    /** @test */
    public function a_user_can_request_all_replies_for_a_given_thread()
    {
        $thread = create(Thread::class);

        create(Reply::class, ['thread_id' => $thread->id], 2);

        $response = $this->getJson($thread->path() . '/replies')->json();

        $this->assertEquals(2, $response['total']);
    }

    /** @test */
    public function a_visit_is_recorded_when_thread_is_read()
    {
        $thread = create(Thread::class);

        $this->assertEquals(0, $thread->visits);

        $this->call('GET', $thread->path());

        $this->assertEquals(1, $thread->fresh()->visits);
    }
}
