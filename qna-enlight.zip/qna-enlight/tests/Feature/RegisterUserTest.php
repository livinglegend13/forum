<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RegisterUserTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function new_user_cannot_create_account_with_already_present_username()
    {
        $this->withExceptionHandling();

        $userOne = create(User::class, ['username' => 'johndoe']);

        $userTwo = make(User::class, ['username' => 'johndoe']);

        $this->post('/register', $userTwo->toArray())
            ->assertSessionHasErrors('username');
    }

    /** @test */
    public function new_user_cannot_create_account_with_already_present_email()
    {
        $this->withExceptionHandling();

        $userOne = create(User::class, ['email' => 'johndoe@test.com']);

        $userTwo = make(User::class, ['email' => 'johndoe@test.com']);

        $this->post('/register', $userTwo->toArray())
            ->assertSessionHasErrors('email');
    }
}
