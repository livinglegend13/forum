<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Reply;
use App\Models\Thread;
use App\Achievements\Points\ReplyCreated;
use App\Achievements\Points\MarkBestReply;
use App\Achievements\Points\ThreadCreated;
use App\Achievements\Points\ReplyFavourited;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ReputationTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function user_earns_points_when_it_creates_thread()
    {
        $thread = create(Thread::class);

        $thread_created_points = (new ThreadCreated($thread))->getPoints();

        $this->assertEquals($thread_created_points, $thread->creator->reputation);
    }

    /** @test */
    public function user_looses_points_when_it_deletes_thread()
    {
        $thread = create(Thread::class);

        $thread->delete();

        $this->assertEquals(0, $thread->creator->fresh()->reputation);
    }

    /** @test */
    public function user_earns_points_when_it_creates_reply()
    {
        $reply = create(Reply::class);

        $reply_created_points = (new ReplyCreated($reply))->getPoints();

        $this->assertEquals($reply_created_points, $reply->owner->reputation);
    }

    /** @test */
    public function user_looses_points_when_it_deletes_reply()
    {
        $reply = create(Reply::class);

        $reply->delete();

        $this->assertEquals(0, $reply->owner->fresh()->reputation);
    }

    /** @test */
    public function user_looses_points_when_it_deletes_deletes_threads_that_has_replies()
    {
        $john = create(User::class);

        $thread = create(Thread::class, ['user_id' => $john->id]);

        $jane = create(User::class);

        create(Reply::class, [
            'thread_id' => $thread->id,
            'user_id' => $jane->id,
        ]);

        create(Reply::class, [
            'thread_id' => $thread->id,
            'user_id' => $john->id,
        ]);

        $thread->delete();

        $this->assertEquals(0, $john->fresh()->reputation);

        $this->assertEquals(0, $jane->fresh()->reputation);
    }

    /** @test */
    public function user_earns_points_when_its_reply_gets_marked_as_best()
    {
        $thread = create(Thread::class);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $reply_created_points = (new ReplyCreated($reply))->getPoints();

        $this->assertEquals($reply_created_points, $reply->owner->fresh()->reputation);

        $thread->markBestReply($reply);

        $mark_best_reply_points = (new MarkBestReply($reply))->getPoints();

        $this->assertEquals(
            $reply_created_points + $mark_best_reply_points,
            $reply->owner->fresh()->reputation
        );
    }

    /** @test */
    public function user_looses_points_when_its_best_reply_gets_unmarked_as_best()
    {
        $thread = create(Thread::class);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $reply_created_points = (new ReplyCreated($reply))->getPoints();

        $thread->markBestReply($reply);

        $another_reply = create(Reply::class, ['thread_id' => $thread->id]);

        $thread->markBestReply($another_reply);

        $mark_best_reply_points = (new MarkBestReply($reply))->getPoints();

        $this->assertEquals(
            $reply_created_points,
            $reply->owner->fresh()->reputation
        );

        $this->assertEquals(
            $reply_created_points + $mark_best_reply_points,
            $another_reply->owner->fresh()->reputation
        );
    }

    /** @test */
    public function user_looses_points_when_its_best_reply_got_deleted()
    {
        $thread = create(Thread::class, ['title' => 'test']);

        $reply = create(Reply::class, ['thread_id' => $thread->id]);

        $thread->markBestReply($reply);

        $reply->delete();

        $this->assertEquals(0, $reply->owner->fresh()->reputation);
    }

    /** @test */
    public function user_earns_points_when_its_reply_got_favourited()
    {
        $reply = create(Reply::class);

        $this->signIn();

        $reply_created_points = (new ReplyCreated($reply))->getPoints();

        $reply_favourited_points = (new ReplyFavourited($reply))->getPoints();

        $reply->favourite();

        $this->assertEquals(
            $reply_created_points + $reply_favourited_points,
            $reply->owner->fresh()->reputation
        );
    }

    /** @test */
    public function user_looses_points_when_its_reply_got_unfavourited()
    {
        $reply = create(Reply::class);

        $this->signIn();

        $reply_created_points = (new ReplyCreated($reply))->getPoints();

        $reply->favourite();

        $reply->unfavourite();

        $this->assertEquals(
            $reply_created_points,
            $reply->owner->fresh()->reputation
        );
    }

    /** @test */
    public function user_looses_points_when_its_favourited_reply_gets_deleted()
    {
        $reply = create(Reply::class);

        $this->signIn();

        $reply->favourite();

        $reply->delete();

        $this->assertEquals(
            0,
            $reply->owner->fresh()->reputation
        );
    }

    /** @test */
    public function all_user_looses_points_when_its_favourited_reply_gets_deleted()
    {
        $reply = create(Reply::class);

        $john = create(User::class);
        $jane = create(User::class);

        $this->signIn($john);
        $reply->favourite();

        $this->signIn($jane);
        $reply->favourite();

        $reply->delete();

        $this->assertEquals(
            0,
            $reply->owner->fresh()->reputation
        );
    }
}
