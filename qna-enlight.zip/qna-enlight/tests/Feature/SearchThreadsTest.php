<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Thread;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SearchThreadsTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_user_can_filter_threads_by_any_search_query_in_title()
    {
        $thread = create(Thread::class, ['title' => 'i have something to say']);

        $this->get(route('threads.search.index', ['q' => 'something']))
        ->assertSee($thread->title);
    }

    /** @test */
    public function a_user_can_filter_threads_by_any_search_query_in_body()
    {
        $thread = create(Thread::class, ['body' => 'i have something to say']);

        $this->get('/threads/search?q=something')
        ->assertSee($thread->title);
    }
}
