<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SettingsRoutesTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $this->signIn($this->user);
    }

    /** @test */
    public function normal_user_may_not_access_settings_index()
    {
        $this->withExceptionHandling()
            ->get(route('admin.settings.index'))
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_settings_index()
    {
        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->get(route('admin.settings.index'))
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_api_settings_index()
    {
        $this->withExceptionHandling()
            ->get(route('admin.api-settings.index'))
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_api_settings_index()
    {
        $this->withoutExceptionHandling();

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->get(route('admin.api-settings.index'))
            ->assertStatus(200);
    }
}
