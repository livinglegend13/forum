<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SettingsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->signIn($this->user);
    }

    /** @test */
    public function it_requires_sitename_description_company_and_siteurl()
    {
        $this->withExceptionHandling();

        $this->post(route('admin.settings.postSite', [
            'description' => 'QNA-Enlight Description',
            'siteurl' => 'test.com',
        ]))
        ->assertSessionHasErrors('sitename');

        $this->post(route('admin.settings.postSite', [
            'sitename' => 'QNA-Enlight',
            'siteurl' => 'test.com',
        ]))
        ->assertSessionHasErrors('description');

        $this->post(route('admin.settings.postSite', [
            'sitename' => 'QNA-Enlight',
            'description' => 'some description',
        ]))
        ->assertSessionHasErrors('siteurl');

        $this->post(route('admin.settings.postSite', [
            'sitename' => 'QNA-Enlight',
            'description' => 'some description',
            'siteurl' => 'sometest.com',
        ]))
        ->assertSessionHasErrors('company');
    }

    /** @test */
    public function it_store_sitename_description_company_and_siteurl()
    {
        $response = $this->post(route('admin.settings.postSite', [
            'sitename' => 'QNA-Enlight',
            'description' => 'some description',
            'company' => 'Enlight Technologies',
            'siteurl' => 'https://qna-enlight.test',
        ]));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Site Settings Updated Successfully');

        // it should change config(app_name) and save description

        $this->assertDatabaseHas('settings', [
            'key' => 'sitename',
            'value' => 'QNA-Enlight',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'description',
            'value' => 'some description',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'company',
            'value' => 'Enlight Technologies',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'siteurl',
            'value' => 'https://qna-enlight.test',
        ]);
    }
}
