<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Thread;
use App\Models\Channel;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SitemapTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_generates_sitemap_automatically()
    {
        $user = create(User::class);

        $channel = create(Channel::class);

        create(Thread::class, [
            'channel_id' => $channel->id,
            'user_id' => $user->id,
        ]);

        $staticPaths = $this->getAllStaticRoutes();

        $channelsPaths = $this->getAllChannelsRoutes();

        $threadsPaths = $this->getAllThreadsRoutes();

        $usersPaths = $this->getAllUsersRoutes();

        $allPaths = array_merge($staticPaths, $channelsPaths, $threadsPaths, $usersPaths);

        $response = $this->get('/sitemap.xml');

        $response->assertSeeTextInOrder($allPaths);
    }

    protected function getAllStaticRoutes()
    {
        return ['https://qna-enlight.test',
            'https://qna-enlight.test/login',
            'https://qna-enlight.test/register',
            'https://qna-enlight.test/password/reset',
            'https://qna-enlight.test/threads',
            'https://qna-enlight.test/threads/search?q=',
            'https://qna-enlight.test/threads?popular=1',
            'https://qna-enlight.test/threads?unanswered=1',
            'https://qna-enlight.test/cookie-policy',
            'https://qna-enlight.test/privacy-policy',
            'https://qna-enlight.test/profiles',
        ];
    }

    protected function getAllChannelsRoutes()
    {
        $paths = [];
        foreach (Channel::orderBy('id', 'desc') as $channel) {
            array_push($paths, asset($channel->slug));
        }

        return $paths;
    }

    protected function getAllThreadsRoutes()
    {
        $paths = [];
        foreach (Thread::all() as $thread) {
            array_push($paths, asset($thread->path()));
        }

        return $paths;
    }

    protected function getAllUsersRoutes()
    {
        $paths = [];

        foreach (User::all() as $user) {
            array_push($paths, 'https://qna-enlight.test/profiles/' . $user->username);

            array_push($paths, 'https://qna-enlight.test/threads?by=' . $user->username);
        }

        return $paths;
    }
}
