<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SocialLinksSettingsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->signIn($this->user);
    }

    /** @test */
    public function it_updates_social_links_in_footer()
    {
        $response = $this->post(route('admin.settings.postSocial', [
            'facebook_link' => 'https://www.facebook.com/brand',
            'whatsapp_link' => 'https://api.whatsapp.com/send?phone=919325211119',
            'instagram_link' => 'https://www.instagram.com/brand',
            'twitter_link' => 'https://www.twitter.com/brand',
        ]));

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Social Link Settings Updated Successfully');

        // it should change config(app_name) and save description

        $this->assertDatabaseHas('settings', [
            'key' => 'facebook_link',
            'value' => 'https://www.facebook.com/brand',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'whatsapp_link',
            'value' => 'https://api.whatsapp.com/send?phone=919325211119',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'instagram_link',
            'value' => 'https://www.instagram.com/brand',
        ]);

        $this->assertDatabaseHas('settings', [
            'key' => 'twitter_link',
            'value' => 'https://www.twitter.com/brand',
        ]);
    }
}
