<?php

declare(strict_types=1);

namespace Tests\Feature\Ticket;

use Tests\TestCase;
use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;

class CategoryTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_requires_name_for_ticket_category()
    {
        $this->withExceptionHandling();

        $this->signInAsAdmin();

        $this->post(route('admin.ticket.categories.store', ['name' => null]))
            ->assertSessionHasErrors('name');
    }

    /** @test */
    public function it_stores_ticket_category()
    {
        $this->signInAsAdmin();

        $this->post(route('admin.ticket.categories.store', [
            'name' => 'title',
        ]))
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Ticket category saved successfully');

        $this->assertDatabaseHas('categories', [
            'name' => 'title',
        ]);
    }

    /** @test */
    public function to_update_it_requires_name_for_ticket_category()
    {
        $this->withExceptionHandling();

        $this->signInAsAdmin();

        $category = create(Category::class);

        $this->patch(route('admin.ticket.categories.update', $category), ['name' => null])
            ->assertSessionHasErrors('name');
    }

    /** @test */
    public function it_can_update_ticket_category()
    {
        $this->signInAsAdmin();

        $category = create(Category::class);

        $this->patch(route('admin.ticket.categories.update', $category), [
            'name' => 'Changed',
        ])
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Ticket category updated successfully');

        tap($category->fresh(), function ($c) {
            $this->assertEquals('Changed', $c->name);
        });
    }

    /** @test */
    public function unauthorised_users_cant_delete_ticket_categories()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $category = create(Category::class);

        $this->delete(route('admin.ticket.categories.destroy', $category))
            ->assertStatus(401);
    }

    /** @test */
    public function admins_users_can_delete_category()
    {
        $this->signInAsAdmin();

        $category = create(Category::class);

        $this->delete(route('admin.ticket.categories.destroy', $category))
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Ticket category deleted successfully');

        $this->assertDatabaseMissing('categories', [
            'id' => $category->id,
        ]);
    }
}
