<?php

declare(strict_types=1);

namespace Tests\Feature\Ticket;

use Tests\TestCase;
use App\Models\Ticket;
use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;

class OpenTicketTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function unauthorised_users_cant_access_tickets_route()
    {
        $this->withExceptionHandling();

        $this->json('get', route('tickets.index'))
            ->assertStatus(401);
    }

    /** @test */
    public function authorised_users_can_access_tickets_route()
    {
        $this->signIn();

        $this->json('get', route('tickets.index'))
            ->assertStatus(200);
    }

    /** @test */
    public function users_can_see_their_own_tickets_only()
    {
        $this->signIn();

        $ticket = create(Ticket::class, ['user_id' => auth()->id()]);

        $this->json('get', route('tickets.show', $ticket))
            ->assertStatus(200);
    }

    /** @test */
    public function admin_users_can_access_tickets_route()
    {
        $this->signInAsAdmin();

        $this->json('get', route('tickets.index'))
            ->assertStatus(200);
    }

    /** @test */
    public function category_id_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['category_id' => null]))
            ->assertSessionHasErrors('category_id');
    }

    /** @test */
    public function valid_category_id_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['category_id' => 999]))
            ->assertSessionHasErrors('category_id');
    }

    /** @test */
    public function title_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['title' => null]))
            ->assertSessionHasErrors('title');
    }

    /** @test */
    public function message_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['message' => null]))
            ->assertSessionHasErrors('message');
    }

    /** @test */
    public function priority_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['priority' => null]))
            ->assertSessionHasErrors('priority');
    }

    /** @test */
    public function valid_priority_is_required_to_create_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->post(route('tickets.store', ['priority' => 'not-a-priority']))
            ->assertSessionHasErrors('priority');
    }

    /** @test */
    public function it_opens_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $category = create(Category::class);

        $this->post(route('tickets.store', [
            'category_id' => $category->id,
            'title' => 'title',
            'message' => 'message',
            'priority' => 'HIGH',
        ]))
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Ticket opened successfully');

        $this->assertDatabaseHas('tickets', [
            'user_id' => auth()->id(),
            'category_id' => $category->id,
            'title' => 'title',
            'message' => 'message',
            'priority' => 'HIGH',
            'status' => 'OPENED',
        ]);
    }
}
