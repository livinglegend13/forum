<?php

declare(strict_types=1);

namespace Tests\Feature\Ticket;

use Tests\TestCase;
use App\Models\User;
use App\Models\Ticket;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ParticipateInOpenedTicketTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_requires_comment_body()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $ticket = create(Ticket::class);

        $this->post(route('comments.store', $ticket), ['body' => null])
            ->assertSessionHasErrors('body');
    }

    /** @test */
    public function user_can_comment_on_his_ticket()
    {
        $this->signIn();

        $ticket = create(Ticket::class);

        $this->post(route('comments.store', $ticket), ['body' => 'some comment'])
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Your comment saved successfully');

        $this->assertDatabaseHas('comments', [
            'user_id' => auth()->id(),
            'ticket_id' => $ticket->id,
            'body' => 'some comment',
        ]);
    }

    /** @test */
    public function non_ticket_owners_cant_close_ticket()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $user = create(User::class);

        $ticket = create(Ticket::class, ['user_id' => $user->id]);

        $this->post(route('tickets.close', $ticket))
            ->assertStatus(403);
    }

    /** @test */
    public function ticket_owner_can_close_ticket()
    {
        $this->signIn();

        $ticket = create(Ticket::class);

        $this->post(route('tickets.close', $ticket))
            ->assertStatus(302)
            ->assertSessionHas('flash', 'Ticket closed successfully');

        $this->assertEquals('CLOSED', $ticket->fresh()->status);
    }
}
