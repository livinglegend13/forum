<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;

class TicketCategoryRoutesTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function normal_user_may_not_access_categories_store()
    {
        $this->withExceptionHandling()
            ->post('/categories')
            ->assertStatus(401);
    }

    /** @test */
    public function normal_user_may_not_access_categories_index()
    {
        $this->signIn();

        $this->withExceptionHandling()
            ->get('/categories')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_category_index()
    {
        $this->signInAsAdmin();

        $this->withExceptionHandling()
            ->get('/categories')
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_categories_create()
    {
        $this->signIn();

        $this->withExceptionHandling()
            ->get('/categories/create')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_category_create()
    {
        $this->signInAsAdmin();

        $this->withExceptionHandling()
            ->get('/categories/create')
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_categories_destroy()
    {
        $this->signIn();

        $category = create(Category::class);

        $this->withExceptionHandling()
            ->delete('/categories/' . $category->id)
            ->assertStatus(401);
    }

    /** @test */
    public function normal_user_may_not_access_categories_update()
    {
        $this->signIn();

        $category = create(Category::class);

        $this->withExceptionHandling()
            ->put('/categories/' . $category->id)
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_category_update()
    {
        $category = create(Category::class);

        $this->signInAsAdmin();

        $this->withExceptionHandling()
            ->get(route('admin.ticket.categories.update', $category->id))
            ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_categories_show()
    {
        $this->signIn();

        $category = create(Category::class);

        $this->withExceptionHandling()
            ->get('/categories/' . $category->id)
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_category_show()
    {
        $category = create(Category::class);

        $this->signInAsAdmin();

        $this->withExceptionHandling()
        ->get('/categories/' . $category->id)
        ->assertStatus(200);
    }

    /** @test */
    public function normal_user_may_not_access_categories_edit()
    {
        $this->signIn();

        $category = create(Category::class);

        $this->withExceptionHandling()
            ->get('/categories/' . $category->id . '/edit')
            ->assertStatus(401);
    }

    /** @test */
    public function admin_can_access_category_edit()
    {
        $category = create(Category::class);

        $this->signInAsAdmin();

        $this->withExceptionHandling()
        ->get('/categories/' . $category->id . '/edit')
        ->assertStatus(200);
    }
}
