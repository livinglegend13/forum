<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use App\Models\Channel;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UpdateChannelsTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user = create(User::class);

        $this->user->roles()->attach($admin_role);

        $this->withExceptionHandling()
            ->signIn($this->user);

        $this->channel = create(Channel::class);
    }

    /** @test */
    public function a_channel_requires_a_name_when_updating()
    {
        $this->put(route('admin.channels.update', $this->channel))
        ->assertSessionHasErrors('name');
    }

    /** @test */
    public function a_channel_requires_a_font_awesome_classes_when_updating()
    {
        $this->put(route('admin.channels.update', $this->channel))
                ->assertSessionHasErrors('font_awesome_classes');
    }

    /** @test */
    public function an_admin_can_update_channel_with_same_name()
    {
        $channel = create(Channel::class, ['name' => 'somename']);

        $response = $this->put(route('admin.channels.update', $channel->slug), [
            'name' => 'somename',
            'font_awesome_classes' => 'someclass',
        ]);

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Channel Updated Successfully');

        $this->assertDatabaseHas('channels', [
            'name' => 'somename',
            'font_awesome_classes' => 'someclass',
        ]);
    }

    /** @test */
    public function an_admin_can_update_channel_with_new_data()
    {
        $response = $this->put(route('admin.channels.update', $this->channel->slug), [
            'name' => 'somename2',
            'font_awesome_classes' => 'someclass2',
        ]);

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Channel Updated Successfully');

        $this->assertDatabaseHas('channels', [
            'name' => 'somename2',
            'font_awesome_classes' => 'someclass2',
        ]);
    }
}
