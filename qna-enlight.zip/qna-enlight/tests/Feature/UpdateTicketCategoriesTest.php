<?php declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Category;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UpdateTicketCategoriesTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->withExceptionHandling()
            ->signInAsAdmin();

        $this->category = create(Category::class);
    }

    /** @test */
    public function a_category_requires_a_name_when_updating()
    {
        $this->put(route('admin.ticket.categories.update', $this->category))
        ->assertSessionHasErrors('name');
    }

    /** @test */
    public function an_admin_can_update_category_with_new_data()
    {
        $response = $this->put(route('admin.ticket.categories.update', $this->category->id), [
            'name' => 'somename2',
        ]);

        $response->assertStatus(302)
        ->assertSessionHas('flash', 'Ticket category updated successfully');

        $this->assertDatabaseHas('categories', [
            'name' => 'somename2',
        ]);
    }
}
