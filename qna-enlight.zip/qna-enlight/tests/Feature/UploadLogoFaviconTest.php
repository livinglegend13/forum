<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UploadLogoFaviconTest extends TestCase
{
    use RefreshDatabase;

    public function setUp(): void
    {
        parent::setUp();

        $this->user = create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $this->user->roles()->attach($admin_role);

        $this->signIn($this->user);
    }

    /** @test */
    public function only_admins_can_add_logo()
    {
        $this->withExceptionHandling();

        $this->signIn();

        $this->json('post', route('admin.settings.postLogo'))
                ->assertStatus(401);
    }

    /** @test */
    public function an_admin_may_change_logo()
    {
        File::delete(
            [
                public_path('logo.png'),
                public_path('apple-touch-icon.png'),
                public_path('favicon-48x48.png'),
                public_path('favicon-32x32.png'),
                public_path('favicon-16x16.png'),
            ]
        );

        $this->json('POST', route('admin.settings.postLogo'), [
            'logo' => UploadedFile::fake()->image('logoImage.png'),
        ]);

        Storage::disk('test')->assertExists('logo.png');
        Storage::disk('test')->assertExists('apple-touch-icon.png');
        Storage::disk('test')->assertExists('favicon-48x48.png');
        Storage::disk('test')->assertExists('favicon-32x32.png');
        Storage::disk('test')->assertExists('favicon-16x16.png');
    }
}
