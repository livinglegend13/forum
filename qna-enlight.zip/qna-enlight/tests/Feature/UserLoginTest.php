<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UserLoginTest extends TestCase
{
    use RefreshDatabase;

    /*
        |--------------------------------------------------------------------------
        | Model Factories
        |--------------------------------------------------------------------------
        |
        | This directory should contain each of the model factory definitions for
        | your application. Factories provide a convenient way to generate new
        | model instances for testing / seeding your application's database.
        |
    */
    public function unauthenticated_users_can_view_login_page()
    {
        $this->get('/login')
                ->assertSee('Login')
                ->assertOk();
    }

    /** @test */
    public function when_user_login_with_email_it_gets_redirected_to_profile_page()
    {
        $user = create(User::class);

        $this->post('/login', [
            'email' => $user->email,
            'password' => 'password',
        ])
        ->assertStatus(302)
        ->assertRedirect(route('profiles.show', $user));
    }

    /** @test */
    public function when_user_login_with_wrong_email_it_gets_redirected_with_errors()
    {
        $this->withExceptionHandling();

        $user = create(User::class);

        $this->post('/login', [
            'email' => 'dummy@email.com',
            'password' => 'password',
        ])
        ->assertStatus(302)
        ->assertSessionHasErrors('email');
    }

    /** @test */
    public function when_user_login_with_username_it_gets_redirected_to_profile_page()
    {
        $user = create(User::class);

        $this->post('/login', [
            'email' => $user->username,
            'password' => 'password',
        ])
        ->assertStatus(302)
        ->assertRedirect(route('profiles.show', $user));
    }

    /** @test */
    public function when_user_login_with_wrong_username_it_gets_redirected_with_errors()
    {
        $this->withExceptionHandling();

        $user = create(User::class);

        $this->post('/login', [
            'email' => 'dummy_username',
            'password' => 'password',
        ])
        ->assertStatus(302)
        ->assertSessionHasErrors('email');
    }
}
