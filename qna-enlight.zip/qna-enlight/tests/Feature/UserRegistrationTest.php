<?php

declare(strict_types=1);

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UserRegistrationTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function unauthenticated_users_can_view_register_page()
    {
        $this->get('/register')
                ->assertSee('Register')
                ->assertOk();
    }

    /** @test */
    public function when_user_registers_then_it_redirects_to_their_profile_page()
    {
        $user = [
            'name' => 'John Doe',
            'username' => 'john_doe',
            'email' => 'a@b.com',
            'password' => 'password',
            'password_confirmation' => 'password',
        ];

        $response = $this->post('/register', $user);

        $response->assertStatus(302);

        $response->assertRedirect(route('profiles.show', $user['username']));
    }
}
