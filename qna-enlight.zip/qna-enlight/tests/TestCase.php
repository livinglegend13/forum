<?php

declare(strict_types=1);

namespace Tests;

use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    use CreatesApplication;

    public function setUp(): void
    {
        parent::setUp();

        $this->withoutExceptionHandling();
    }

    protected function signIn($user = null)
    {
        $user = $user ?: create(User::class);

        $this->actingAs($user);

        return $this;
    }

    protected function signInAsAdmin($user = null)
    {
        $user = $user ?: create(User::class);

        $admin_role = create(Role::class, ['name' => 'admin']);

        $user->roles()->attach($admin_role);

        $this->actingAs($user);

        return $this;
    }
}
