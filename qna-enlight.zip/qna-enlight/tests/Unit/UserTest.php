<?php

declare(strict_types=1);

namespace Tests\Unit;

use Tests\TestCase;
use App\Models\User;
use App\Models\Reply;
use App\Achievements\Badge;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UserTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_user_can_fetch_their_most_recent_reply()
    {
        $user = create(User::class);

        $reply = create(Reply::class, ['user_id' => $user->id]);

        $this->assertEquals($reply->id, $user->lastReply->id);
    }

    /** @test */
    public function a_user_can_determine_their_avatar_path()
    {
        $user = create(User::class);

        $this->assertEquals(asset('avatars/default.png'), $user->avatar);

        $user->avatar_path = 'avatars/me.jpg';

        $this->assertEquals(asset('avatars/me.jpg'), $user->avatar);
    }

    /** @test */
    public function a_user_can_determine_if_it_has_badge()
    {
        $user = create(User::class);

        $badge = create(Badge::class);

        $this->assertFalse($user->hasBadge($badge));

        $badge->awardTo($user);

        $this->assertTrue($user->fresh()->hasBadge($badge));
    }

    /** @test */
    public function it_can_unverify_user_email()
    {
        $user = create(User::class);

        $this->assertNotNull($user->email_verified_at);

        $user->unverify();

        $this->assertNull($user->fresh()->email_verified_at);
    }
}
