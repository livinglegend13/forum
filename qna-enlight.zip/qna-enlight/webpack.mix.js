let mix = require('laravel-mix');

// require('laravel-mix-purgecss');

mix.sourceMaps()
    .js('resources/js/app.js', 'js')
    .extract([
        'vue',
        'chart.js',
        'highlightjs',
        'pluralize',
        'tributejs',
        'trix',
        'portal-vue',
        'sweetalert2',
        'smoothscroll-polyfill',
        'vue-js-modal'
    ])
    .sass('resources/sass/app.scss', 'css')
    // .purgeCss({
    //     extensions: ['html', 'js', 'php', 'vue'],
    // })
    ;

if (mix.inProduction()) {
    mix.version();
}